﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PIM_2024_2_WEB_V1._0.Migrations
{
    /// <inheritdoc />
    public partial class initialmigrationV2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Fazenda",
                columns: table => new
                {
                    ID_fazenda_PK = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nome = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    CNPJ = table.Column<string>(type: "nvarchar(18)", maxLength: 18, nullable: false),
                    Razao_Social = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    CEP = table.Column<string>(type: "nvarchar(9)", maxLength: 9, nullable: false),
                    UF = table.Column<string>(type: "nvarchar(2)", maxLength: 2, nullable: false),
                    Rua = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Municipio = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Bairro = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Numero = table.Column<int>(type: "int", nullable: false),
                    Telefone_1 = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Telefone_2 = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    E_mail = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Fazenda", x => x.ID_fazenda_PK);
                });

            migrationBuilder.CreateTable(
                name: "Plantacao",
                columns: table => new
                {
                    ID_plantacao_PK = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Data_plantio = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Tipo_plantio = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Tipo_cultivo = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Qtd_sacos_semente = table.Column<int>(type: "int", nullable: false),
                    Qtd_sacos_adubo = table.Column<int>(type: "int", nullable: false),
                    ID_produto_FK = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Plantacao", x => x.ID_plantacao_PK);
                });

            migrationBuilder.CreateTable(
                name: "Produto",
                columns: table => new
                {
                    ID_produto_PK = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Tipo_armazenagem = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Preco_produto = table.Column<decimal>(type: "decimal(20,2)", nullable: false),
                    Nome_produto = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Unidade_medida = table.Column<int>(type: "int", nullable: false),
                    ID_fazenda_PK = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Produto", x => x.ID_produto_PK);
                    table.ForeignKey(
                        name: "FK_Produto_Fazenda_ID_fazenda_PK",
                        column: x => x.ID_fazenda_PK,
                        principalTable: "Fazenda",
                        principalColumn: "ID_fazenda_PK",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Produto_ID_fazenda_PK",
                table: "Produto",
                column: "ID_fazenda_PK");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Plantacao");

            migrationBuilder.DropTable(
                name: "Produto");

            migrationBuilder.DropTable(
                name: "Fazenda");
        }
    }
}
