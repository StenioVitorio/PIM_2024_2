﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PIM_2024_2_WEB_V1._0.Migrations
{
    /// <inheritdoc />
    public partial class initialMigrationV1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Funcionario_Gerencia_gerenciaID_gerencia_PK",
                table: "Funcionario");

            migrationBuilder.DropIndex(
                name: "IX_Funcionario_gerenciaID_gerencia_PK",
                table: "Funcionario");

            migrationBuilder.DropColumn(
                name: "gerenciaID_gerencia_PK",
                table: "Funcionario");

            migrationBuilder.AlterColumn<int>(
                name: "ID_gerencia_PK",
                table: "Gerencia",
                type: "int",
                nullable: false,
                oldClrType: typeof(Guid),
                oldType: "uniqueidentifier")
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AlterColumn<int>(
                name: "ID_funcionario_PK",
                table: "Funcionario",
                type: "int",
                nullable: false,
                oldClrType: typeof(Guid),
                oldType: "uniqueidentifier")
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AlterColumn<int>(
                name: "ID_cliente_PK",
                table: "Cliente",
                type: "int",
                nullable: false,
                oldClrType: typeof(Guid),
                oldType: "uniqueidentifier")
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.CreateIndex(
                name: "IX_Funcionario_ID_gerencia_PK",
                table: "Funcionario",
                column: "ID_gerencia_PK");

            migrationBuilder.AddForeignKey(
                name: "FK_Funcionario_Gerencia_ID_gerencia_PK",
                table: "Funcionario",
                column: "ID_gerencia_PK",
                principalTable: "Gerencia",
                principalColumn: "ID_gerencia_PK",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Funcionario_Gerencia_ID_gerencia_PK",
                table: "Funcionario");

            migrationBuilder.DropIndex(
                name: "IX_Funcionario_ID_gerencia_PK",
                table: "Funcionario");

            migrationBuilder.AlterColumn<Guid>(
                name: "ID_gerencia_PK",
                table: "Gerencia",
                type: "uniqueidentifier",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int")
                .OldAnnotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AlterColumn<Guid>(
                name: "ID_funcionario_PK",
                table: "Funcionario",
                type: "uniqueidentifier",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int")
                .OldAnnotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddColumn<Guid>(
                name: "gerenciaID_gerencia_PK",
                table: "Funcionario",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AlterColumn<Guid>(
                name: "ID_cliente_PK",
                table: "Cliente",
                type: "uniqueidentifier",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int")
                .OldAnnotation("SqlServer:Identity", "1, 1");

            migrationBuilder.CreateIndex(
                name: "IX_Funcionario_gerenciaID_gerencia_PK",
                table: "Funcionario",
                column: "gerenciaID_gerencia_PK");

            migrationBuilder.AddForeignKey(
                name: "FK_Funcionario_Gerencia_gerenciaID_gerencia_PK",
                table: "Funcionario",
                column: "gerenciaID_gerencia_PK",
                principalTable: "Gerencia",
                principalColumn: "ID_gerencia_PK",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
