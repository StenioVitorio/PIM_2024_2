﻿namespace PIMTESTE_
{
    partial class frmTelaCompras
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblOpcCompraTelaCompras = new Label();
            flowLayoutPanel2 = new FlowLayoutPanel();
            cmbNomeProdTelaCompras = new ComboBox();
            txtbQuantProdTelaCompras = new TextBox();
            txtbPrecoProdTelaCompras = new TextBox();
            txtbArmazenTelaCompras = new TextBox();
            lblSelecioneTelaCompras = new Label();
            btnProximoTelaCompras = new Button();
            flowLayoutPanel2.SuspendLayout();
            SuspendLayout();
            // 
            // lblOpcCompraTelaCompras
            // 
            lblOpcCompraTelaCompras.AutoSize = true;
            lblOpcCompraTelaCompras.Dock = DockStyle.Top;
            lblOpcCompraTelaCompras.Font = new Font("Arial Black", 19.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblOpcCompraTelaCompras.ForeColor = Color.FromArgb(57, 62, 40);
            lblOpcCompraTelaCompras.Location = new Point(0, 0);
            lblOpcCompraTelaCompras.Name = "lblOpcCompraTelaCompras";
            lblOpcCompraTelaCompras.Size = new Size(305, 38);
            lblOpcCompraTelaCompras.TabIndex = 0;
            lblOpcCompraTelaCompras.Text = "Opções de Compra:";
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.Controls.Add(cmbNomeProdTelaCompras);
            flowLayoutPanel2.Controls.Add(txtbQuantProdTelaCompras);
            flowLayoutPanel2.Controls.Add(txtbPrecoProdTelaCompras);
            flowLayoutPanel2.Controls.Add(txtbArmazenTelaCompras);
            flowLayoutPanel2.Location = new Point(56, 126);
            flowLayoutPanel2.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(452, 171);
            flowLayoutPanel2.TabIndex = 56;
            // 
            // cmbNomeProdTelaCompras
            // 
            cmbNomeProdTelaCompras.BackColor = SystemColors.Window;
            cmbNomeProdTelaCompras.Dock = DockStyle.Top;
            cmbNomeProdTelaCompras.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cmbNomeProdTelaCompras.ForeColor = SystemColors.WindowText;
            cmbNomeProdTelaCompras.FormattingEnabled = true;
            cmbNomeProdTelaCompras.Items.AddRange(new object[] { "Tomate", "Salsa", "Cebolinha" });
            cmbNomeProdTelaCompras.Location = new Point(3, 2);
            cmbNomeProdTelaCompras.Margin = new Padding(3, 2, 3, 2);
            cmbNomeProdTelaCompras.Name = "cmbNomeProdTelaCompras";
            cmbNomeProdTelaCompras.Size = new Size(447, 38);
            cmbNomeProdTelaCompras.TabIndex = 26;
            cmbNomeProdTelaCompras.SelectedIndexChanged += cmbSelecPlantFuncio_SelectedIndexChanged;
            // 
            // txtbQuantProdTelaCompras
            // 
            txtbQuantProdTelaCompras.BackColor = SystemColors.Window;
            txtbQuantProdTelaCompras.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbQuantProdTelaCompras.ForeColor = SystemColors.WindowText;
            txtbQuantProdTelaCompras.Location = new Point(3, 45);
            txtbQuantProdTelaCompras.Name = "txtbQuantProdTelaCompras";
            txtbQuantProdTelaCompras.PlaceholderText = "Quantidade";
            txtbQuantProdTelaCompras.Size = new Size(447, 36);
            txtbQuantProdTelaCompras.TabIndex = 28;
            // 
            // txtbPrecoProdTelaCompras
            // 
            txtbPrecoProdTelaCompras.BackColor = SystemColors.Window;
            txtbPrecoProdTelaCompras.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbPrecoProdTelaCompras.ForeColor = SystemColors.WindowText;
            txtbPrecoProdTelaCompras.Location = new Point(3, 87);
            txtbPrecoProdTelaCompras.Name = "txtbPrecoProdTelaCompras";
            txtbPrecoProdTelaCompras.PlaceholderText = "Preço";
            txtbPrecoProdTelaCompras.ReadOnly = true;
            txtbPrecoProdTelaCompras.Size = new Size(447, 36);
            txtbPrecoProdTelaCompras.TabIndex = 27;
            txtbPrecoProdTelaCompras.TextChanged += txtbPrecoProdTelaCompras_TextChanged;
            // 
            // txtbArmazenTelaCompras
            // 
            txtbArmazenTelaCompras.BackColor = SystemColors.Window;
            txtbArmazenTelaCompras.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbArmazenTelaCompras.ForeColor = SystemColors.WindowText;
            txtbArmazenTelaCompras.Location = new Point(3, 129);
            txtbArmazenTelaCompras.Name = "txtbArmazenTelaCompras";
            txtbArmazenTelaCompras.PlaceholderText = "Como Armazenar";
            txtbArmazenTelaCompras.ReadOnly = true;
            txtbArmazenTelaCompras.Size = new Size(447, 36);
            txtbArmazenTelaCompras.TabIndex = 11;
            txtbArmazenTelaCompras.TextChanged += txtbArmazenTelaCompras_TextChanged;
            // 
            // lblSelecioneTelaCompras
            // 
            lblSelecioneTelaCompras.AutoSize = true;
            lblSelecioneTelaCompras.BackColor = Color.Transparent;
            lblSelecioneTelaCompras.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblSelecioneTelaCompras.ForeColor = SystemColors.WindowText;
            lblSelecioneTelaCompras.Location = new Point(56, 75);
            lblSelecioneTelaCompras.Name = "lblSelecioneTelaCompras";
            lblSelecioneTelaCompras.Size = new Size(309, 30);
            lblSelecioneTelaCompras.TabIndex = 57;
            lblSelecioneTelaCompras.Text = "Selecione o produto desejado:";
            // 
            // btnProximoTelaCompras
            // 
            btnProximoTelaCompras.BackColor = Color.YellowGreen;
            btnProximoTelaCompras.FlatAppearance.BorderSize = 0;
            btnProximoTelaCompras.FlatStyle = FlatStyle.Flat;
            btnProximoTelaCompras.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnProximoTelaCompras.ForeColor = Color.FromArgb(57, 62, 40);
            btnProximoTelaCompras.Location = new Point(390, 334);
            btnProximoTelaCompras.Name = "btnProximoTelaCompras";
            btnProximoTelaCompras.Size = new Size(115, 34);
            btnProximoTelaCompras.TabIndex = 58;
            btnProximoTelaCompras.Text = "Próximo";
            btnProximoTelaCompras.UseVisualStyleBackColor = false;
            btnProximoTelaCompras.Click += btnProximoTelaCompras_Click;
            // 
            // frmTelaCompras
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(126, 211, 109);
            ClientSize = new Size(584, 406);
            Controls.Add(btnProximoTelaCompras);
            Controls.Add(lblSelecioneTelaCompras);
            Controls.Add(flowLayoutPanel2);
            Controls.Add(lblOpcCompraTelaCompras);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmTelaCompras";
            StartPosition = FormStartPosition.WindowsDefaultBounds;
            Text = "Tela3_Cliente";
            flowLayoutPanel2.ResumeLayout(false);
            flowLayoutPanel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.Windows.Forms.Label lblOpcCompraTelaCompras;
        private FlowLayoutPanel flowLayoutPanel2;
        private TextBox txtbArmazenTelaCompras;
        private TextBox txtbPrecoProdTelaCompras;
        private Label lblSelecioneTelaCompras;
        private ComboBox cmbNomeProdTelaCompras;
        private Button btnProximoTelaCompras;
        private TextBox txtbQuantProdTelaCompras;
    }
}