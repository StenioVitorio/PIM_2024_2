﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMTESTE_
{
    public partial class TelaDosClientes : Form
    {
        public TelaDosClientes()
        {
            InitializeComponent();
        }

        private void btnComprarTelaClien_Click(object sender, EventArgs e)
        {
            this.panTelaClien.Controls.Clear();
            frmTelaCompras frmTelaComprasView = new frmTelaCompras() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frmTelaComprasView.FormBorderStyle = FormBorderStyle.None;
            this.panTelaClien.Controls.Add(frmTelaComprasView);
            frmTelaComprasView.Show();
        }
    }
}
