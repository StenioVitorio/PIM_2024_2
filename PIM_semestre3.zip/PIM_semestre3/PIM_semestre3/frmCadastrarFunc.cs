﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMTESTE_
{
    public partial class frmCadastrarFunc : Form
    {
        public frmCadastrarFunc()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblVendas_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnProximoCadastFunc_Click(object sender, EventArgs e)
        {
            if (this.txtbNomeCadastFunc.Text == string.Empty || this.txtbCPFCadastFunc.Text == string.Empty
                || this.txtbMunicCadastFunc.Text == string.Empty || this.txtbBairroCadastFunc.Text == string.Empty
                || this.txtbRuaCadastFunc.Text == string.Empty || this.txtbNumCadastFunc.Text == string.Empty
                || this.txtbUFCadastFunc.Text == string.Empty || this.txtbCEPCadastFunc.Text == string.Empty
                || this.txtbTelCadastFunc.Text == string.Empty || this.txtbEmailCadastFunc.Text == string.Empty
                || this.txtbCargoCadastFunc.Text == string.Empty)
            {
                MessageBox.Show("Existe um campo em branco!");
            }
            else
            {
                var strConexao = "server=localhost;uid=root;pwd=439360;database=db_fazenda_urbana";

                var nomefunccad = txtbNomeCadastFunc.Text;
                var cpffunccad = txtbCPFCadastFunc.Text;
                var municfunccad = txtbMunicCadastFunc.Text;
                var bairrofunccad = txtbBairroCadastFunc.Text;
                var ruafunccad = txtbRuaCadastFunc.Text;
                var numcasafunccad = txtbNumCadastFunc.Text;
                var uffunccad = txtbUFCadastFunc.Text;
                var cepfunccad = txtbCEPCadastFunc.Text;
                var telfunccad = txtbTelCadastFunc.Text;
                var telemerfunccad = txtbTelEmergCadastFunc.Text;
                var emailfunccad = txtbEmailCadastFunc.Text;
                var cargofunccad = txtbCargoCadastFunc.Text;


                using (var conexao = new MySqlConnection(strConexao))
                {
                    try
                    {
                        conexao.Open();
                        var comando = new MySqlCommand("INSERT INTO funcionario (Nome, CPF, Cargo, Bairro, Municipio, UF, Rua, Numero, CEP, E_mail, Telefone, Tel_emergencial, Usuario, Senha) VALUES (@Nome, @CPF, @Cargo, @Bairro, @Municipio, @UF, @Rua, @Numero, @CEP, @E_mail, @Telefone, @Tel_emergencial, @Usuario, @Senha)", conexao);
                        comando.Parameters.AddWithValue("@Nome", nomefunccad);
                        comando.Parameters.AddWithValue("@CPF", cpffunccad);
                        comando.Parameters.AddWithValue("@Cargo", cargofunccad);
                        comando.Parameters.AddWithValue("@Bairro", bairrofunccad);
                        comando.Parameters.AddWithValue("@Municipio", municfunccad);
                        comando.Parameters.AddWithValue("@UF", uffunccad);
                        comando.Parameters.AddWithValue("@Rua", ruafunccad);
                        comando.Parameters.AddWithValue("@Numero", numcasafunccad);
                        comando.Parameters.AddWithValue("@CEP", cepfunccad);
                        comando.Parameters.AddWithValue("@E_mail", emailfunccad);
                        comando.Parameters.AddWithValue("@Telefone", telfunccad);
                        comando.Parameters.AddWithValue("@Tel_emergencial", telemerfunccad);
                        comando.Parameters.AddWithValue("@Usuario", emailfunccad);
                        comando.Parameters.AddWithValue("@Senha", cpffunccad);






                        comando.ExecuteNonQuery();
                        MessageBox.Show("Cadastro realizado com sucesso!");

                        //"Zerando" as txtbox novamente após a inserção no BD
                        txtbNomeCadastFunc.Text = string.Empty;
                        txtbCPFCadastFunc.Text = string.Empty;
                        txtbMunicCadastFunc.Text = string.Empty;
                        txtbBairroCadastFunc.Text = string.Empty;
                        txtbRuaCadastFunc.Text = string.Empty;
                        txtbNumCadastFunc.Text = string.Empty;
                        txtbUFCadastFunc.Text = string.Empty;
                        txtbCEPCadastFunc.Text = string.Empty;
                        txtbTelCadastFunc.Text = string.Empty;
                        txtbEmailCadastFunc.Text = string.Empty;
                        txtbCargoCadastFunc.Text = string.Empty;

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message);
                    }
                }
            }
        }

        private void txtbCPFCadastFunc_TextChanged(object sender, EventArgs e)
        {
            txtbCPFCadastFunc.MaxLength = 11;
        }

        private void txtbUFCadastFunc_TextChanged(object sender, EventArgs e)
        {
            txtbUFCadastFunc.MaxLength = 2;
        }

        private void txtbCargoCadastFunc_TextChanged(object sender, EventArgs e)
        {
            txtbCargoCadastFunc.MaxLength = 255;
        }

        private void frmCadastrarFunc_Load(object sender, EventArgs e)
        {

        }

        private void txtbNomeCadastFunc_TextChanged(object sender, EventArgs e)
        {
            txtbNomeCadastFunc.MaxLength = 255;
        }

        private void txtbMunicCadastFunc_TextChanged(object sender, EventArgs e)
        {
            txtbMunicCadastFunc.MaxLength = 255;
        }

        private void txtbBairroCadastFunc_TextChanged(object sender, EventArgs e)
        {
            txtbBairroCadastFunc.MaxLength = 255;
        }

        private void txtbRuaCadastFunc_TextChanged(object sender, EventArgs e)
        {
            txtbRuaCadastFunc.MaxLength = 255;
        }

        private void txtbNumCadastFunc_TextChanged(object sender, EventArgs e)
        {
            txtbNumCadastFunc.MaxLength = 255;
        }

        private void txtbCEPCadastFunc_TextChanged(object sender, EventArgs e)
        {
            txtbCEPCadastFunc.MaxLength = 9;
        }

        private void txtbTelEmergCadastFunc_TextChanged(object sender, EventArgs e)
        {
            txtbTelEmergCadastFunc.MaxLength = 20;
        }

        private void txtbTelCadastFunc_TextChanged(object sender, EventArgs e)
        {
            txtbTelCadastFunc.MaxLength = 20;
        }

        private void txtbEmailCadastFunc_TextChanged(object sender, EventArgs e)
        {
            txtbEmailCadastFunc.MaxLength = 255;
        }

        private void txtbTelCadastFunc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void txtbTelEmergCadastFunc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void txtbNumCadastFunc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
    }
}
