﻿namespace PIMTESTE_
{
    partial class frmCadastrarFunc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblCadastFunc = new Label();
            button2 = new Button();
            lblPCamposCadastFunc = new Label();
            txtbNomeCadastFunc = new TextBox();
            txtbBairroCadastFunc = new TextBox();
            txtbCPFCadastFunc = new TextBox();
            txtbRuaCadastFunc = new TextBox();
            txtbCargoCadastFunc = new TextBox();
            txtbNumCadastFunc = new TextBox();
            txtbUFCadastFunc = new TextBox();
            txtbEmailCadastFunc = new TextBox();
            txtbMunicCadastFunc = new TextBox();
            txtbTelCadastFunc = new TextBox();
            txtbCEPCadastFunc = new TextBox();
            txtbTelEmergCadastFunc = new TextBox();
            btnProximoCadastFunc = new Button();
            SuspendLayout();
            // 
            // lblCadastFunc
            // 
            lblCadastFunc.AutoSize = true;
            lblCadastFunc.BackColor = Color.Transparent;
            lblCadastFunc.Dock = DockStyle.Top;
            lblCadastFunc.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCadastFunc.ForeColor = Color.FromArgb(57, 62, 40);
            lblCadastFunc.Location = new Point(0, 0);
            lblCadastFunc.Name = "lblCadastFunc";
            lblCadastFunc.Size = new Size(412, 51);
            lblCadastFunc.TabIndex = 4;
            lblCadastFunc.Text = "Cadastrar Funcionário";
            lblCadastFunc.TextAlign = ContentAlignment.MiddleCenter;
            lblCadastFunc.Click += lblVendas_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.GreenYellow;
            button2.Font = new Font("Arial", 10.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
            button2.Location = new Point(696, 414);
            button2.Name = "button2";
            button2.Size = new Size(93, 26);
            button2.TabIndex = 32;
            button2.Text = "Salvar";
            button2.UseVisualStyleBackColor = false;
            // 
            // lblPCamposCadastFunc
            // 
            lblPCamposCadastFunc.AutoSize = true;
            lblPCamposCadastFunc.BackColor = Color.Transparent;
            lblPCamposCadastFunc.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPCamposCadastFunc.ForeColor = SystemColors.WindowText;
            lblPCamposCadastFunc.Location = new Point(45, 94);
            lblPCamposCadastFunc.Name = "lblPCamposCadastFunc";
            lblPCamposCadastFunc.Size = new Size(215, 30);
            lblPCamposCadastFunc.TabIndex = 60;
            lblPCamposCadastFunc.Text = "Preencha os Campos";
            // 
            // txtbNomeCadastFunc
            // 
            txtbNomeCadastFunc.Anchor = AnchorStyles.None;
            txtbNomeCadastFunc.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbNomeCadastFunc.Location = new Point(45, 141);
            txtbNomeCadastFunc.Name = "txtbNomeCadastFunc";
            txtbNomeCadastFunc.PlaceholderText = "Nome completo*";
            txtbNomeCadastFunc.Size = new Size(243, 29);
            txtbNomeCadastFunc.TabIndex = 38;
            txtbNomeCadastFunc.TextChanged += txtbNomeCadastFunc_TextChanged;
            // 
            // txtbBairroCadastFunc
            // 
            txtbBairroCadastFunc.Anchor = AnchorStyles.None;
            txtbBairroCadastFunc.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbBairroCadastFunc.Location = new Point(45, 246);
            txtbBairroCadastFunc.Name = "txtbBairroCadastFunc";
            txtbBairroCadastFunc.PlaceholderText = "Bairro*";
            txtbBairroCadastFunc.Size = new Size(243, 29);
            txtbBairroCadastFunc.TabIndex = 39;
            txtbBairroCadastFunc.TextChanged += txtbBairroCadastFunc_TextChanged;
            // 
            // txtbCPFCadastFunc
            // 
            txtbCPFCadastFunc.Anchor = AnchorStyles.None;
            txtbCPFCadastFunc.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbCPFCadastFunc.Location = new Point(45, 176);
            txtbCPFCadastFunc.Name = "txtbCPFCadastFunc";
            txtbCPFCadastFunc.PlaceholderText = "CPF*";
            txtbCPFCadastFunc.Size = new Size(243, 29);
            txtbCPFCadastFunc.TabIndex = 40;
            txtbCPFCadastFunc.TextChanged += txtbCPFCadastFunc_TextChanged;
            // 
            // txtbRuaCadastFunc
            // 
            txtbRuaCadastFunc.Anchor = AnchorStyles.None;
            txtbRuaCadastFunc.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbRuaCadastFunc.Location = new Point(45, 281);
            txtbRuaCadastFunc.Name = "txtbRuaCadastFunc";
            txtbRuaCadastFunc.PlaceholderText = "Rua*";
            txtbRuaCadastFunc.Size = new Size(243, 29);
            txtbRuaCadastFunc.TabIndex = 41;
            txtbRuaCadastFunc.TextChanged += txtbRuaCadastFunc_TextChanged;
            // 
            // txtbCargoCadastFunc
            // 
            txtbCargoCadastFunc.Anchor = AnchorStyles.None;
            txtbCargoCadastFunc.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbCargoCadastFunc.Location = new Point(309, 316);
            txtbCargoCadastFunc.Name = "txtbCargoCadastFunc";
            txtbCargoCadastFunc.PlaceholderText = "Cargo*";
            txtbCargoCadastFunc.Size = new Size(243, 29);
            txtbCargoCadastFunc.TabIndex = 49;
            txtbCargoCadastFunc.TextChanged += txtbCargoCadastFunc_TextChanged;
            // 
            // txtbNumCadastFunc
            // 
            txtbNumCadastFunc.Anchor = AnchorStyles.None;
            txtbNumCadastFunc.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbNumCadastFunc.Location = new Point(45, 316);
            txtbNumCadastFunc.Name = "txtbNumCadastFunc";
            txtbNumCadastFunc.PlaceholderText = "Número*";
            txtbNumCadastFunc.Size = new Size(243, 29);
            txtbNumCadastFunc.TabIndex = 43;
            txtbNumCadastFunc.TextChanged += txtbNumCadastFunc_TextChanged;
            txtbNumCadastFunc.KeyPress += txtbNumCadastFunc_KeyPress;
            // 
            // txtbUFCadastFunc
            // 
            txtbUFCadastFunc.Anchor = AnchorStyles.None;
            txtbUFCadastFunc.CharacterCasing = CharacterCasing.Upper;
            txtbUFCadastFunc.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbUFCadastFunc.Location = new Point(309, 141);
            txtbUFCadastFunc.Name = "txtbUFCadastFunc";
            txtbUFCadastFunc.PlaceholderText = "UF*";
            txtbUFCadastFunc.Size = new Size(243, 29);
            txtbUFCadastFunc.TabIndex = 44;
            txtbUFCadastFunc.TextChanged += txtbUFCadastFunc_TextChanged;
            // 
            // txtbEmailCadastFunc
            // 
            txtbEmailCadastFunc.Anchor = AnchorStyles.None;
            txtbEmailCadastFunc.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbEmailCadastFunc.Location = new Point(309, 281);
            txtbEmailCadastFunc.Name = "txtbEmailCadastFunc";
            txtbEmailCadastFunc.PlaceholderText = "E-mail*";
            txtbEmailCadastFunc.Size = new Size(243, 29);
            txtbEmailCadastFunc.TabIndex = 45;
            txtbEmailCadastFunc.TextChanged += txtbEmailCadastFunc_TextChanged;
            // 
            // txtbMunicCadastFunc
            // 
            txtbMunicCadastFunc.Anchor = AnchorStyles.None;
            txtbMunicCadastFunc.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbMunicCadastFunc.Location = new Point(45, 211);
            txtbMunicCadastFunc.Name = "txtbMunicCadastFunc";
            txtbMunicCadastFunc.PlaceholderText = "Município*";
            txtbMunicCadastFunc.Size = new Size(243, 29);
            txtbMunicCadastFunc.TabIndex = 46;
            txtbMunicCadastFunc.TextChanged += txtbMunicCadastFunc_TextChanged;
            // 
            // txtbTelCadastFunc
            // 
            txtbTelCadastFunc.Anchor = AnchorStyles.None;
            txtbTelCadastFunc.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbTelCadastFunc.Location = new Point(309, 211);
            txtbTelCadastFunc.Name = "txtbTelCadastFunc";
            txtbTelCadastFunc.PlaceholderText = "Telefone*";
            txtbTelCadastFunc.Size = new Size(243, 29);
            txtbTelCadastFunc.TabIndex = 47;
            txtbTelCadastFunc.TextChanged += txtbTelCadastFunc_TextChanged;
            txtbTelCadastFunc.KeyPress += txtbTelCadastFunc_KeyPress;
            // 
            // txtbCEPCadastFunc
            // 
            txtbCEPCadastFunc.Anchor = AnchorStyles.None;
            txtbCEPCadastFunc.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbCEPCadastFunc.Location = new Point(309, 176);
            txtbCEPCadastFunc.Name = "txtbCEPCadastFunc";
            txtbCEPCadastFunc.PlaceholderText = "CEP*";
            txtbCEPCadastFunc.Size = new Size(243, 29);
            txtbCEPCadastFunc.TabIndex = 48;
            txtbCEPCadastFunc.TextChanged += txtbCEPCadastFunc_TextChanged;
            // 
            // txtbTelEmergCadastFunc
            // 
            txtbTelEmergCadastFunc.Anchor = AnchorStyles.None;
            txtbTelEmergCadastFunc.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbTelEmergCadastFunc.Location = new Point(309, 246);
            txtbTelEmergCadastFunc.Name = "txtbTelEmergCadastFunc";
            txtbTelEmergCadastFunc.PlaceholderText = "Telefone Emergêncial";
            txtbTelEmergCadastFunc.Size = new Size(243, 29);
            txtbTelEmergCadastFunc.TabIndex = 50;
            txtbTelEmergCadastFunc.TextChanged += txtbTelEmergCadastFunc_TextChanged;
            txtbTelEmergCadastFunc.KeyPress += txtbTelEmergCadastFunc_KeyPress;
            // 
            // btnProximoCadastFunc
            // 
            btnProximoCadastFunc.BackColor = Color.YellowGreen;
            btnProximoCadastFunc.FlatAppearance.BorderSize = 0;
            btnProximoCadastFunc.FlatStyle = FlatStyle.Flat;
            btnProximoCadastFunc.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnProximoCadastFunc.ForeColor = Color.FromArgb(57, 62, 40);
            btnProximoCadastFunc.Location = new Point(426, 356);
            btnProximoCadastFunc.Name = "btnProximoCadastFunc";
            btnProximoCadastFunc.Size = new Size(115, 34);
            btnProximoCadastFunc.TabIndex = 61;
            btnProximoCadastFunc.Text = "Próximo";
            btnProximoCadastFunc.UseVisualStyleBackColor = false;
            btnProximoCadastFunc.Click += btnProximoCadastFunc_Click;
            // 
            // frmCadastrarFunc
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(238, 241, 212);
            ClientSize = new Size(584, 409);
            Controls.Add(txtbNomeCadastFunc);
            Controls.Add(txtbCPFCadastFunc);
            Controls.Add(btnProximoCadastFunc);
            Controls.Add(txtbMunicCadastFunc);
            Controls.Add(lblPCamposCadastFunc);
            Controls.Add(txtbBairroCadastFunc);
            Controls.Add(txtbRuaCadastFunc);
            Controls.Add(lblCadastFunc);
            Controls.Add(txtbCargoCadastFunc);
            Controls.Add(button2);
            Controls.Add(txtbNumCadastFunc);
            Controls.Add(txtbEmailCadastFunc);
            Controls.Add(txtbUFCadastFunc);
            Controls.Add(txtbTelEmergCadastFunc);
            Controls.Add(txtbTelCadastFunc);
            Controls.Add(txtbCEPCadastFunc);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmCadastrarFunc";
            Text = "frmCadastrarFunc";
            Load += frmCadastrarFunc_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblCadastFunc;
        private Button button2;
        private Label lblPCamposCadastFunc;
        private TextBox txtbNomeCadastFunc;
        private TextBox txtbBairroCadastFunc;
        private TextBox txtbCPFCadastFunc;
        private TextBox txtbRuaCadastFunc;
        private TextBox txtbNumCadastFunc;
        private TextBox txtbUFCadastFunc;
        private TextBox txtbEmailCadastFunc;
        private TextBox txtbMunicCadastFunc;
        private TextBox txtbTelCadastFunc;
        private TextBox txtbCargoCadastFunc;
        private TextBox txtbCEPCadastFunc;
        private TextBox txtbTelEmergCadastFunc;
        private Button btnProximoCadastFunc;
    }
}