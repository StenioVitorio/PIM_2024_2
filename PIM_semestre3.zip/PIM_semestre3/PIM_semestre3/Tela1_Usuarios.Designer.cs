﻿namespace PIMTESTE_
{
    partial class Tela1_Usuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tela1_Usuarios));
            ptbFundoTela1Usuarios = new PictureBox();
            panTela1Usuarios = new Panel();
            flowLayoutPanel13 = new FlowLayoutPanel();
            ptbStartuTela1Usuarios = new PictureBox();
            lblStartuTela1Usuarios = new Label();
            btnAcessTela1Usuarios = new Button();
            ((System.ComponentModel.ISupportInitialize)ptbFundoTela1Usuarios).BeginInit();
            panTela1Usuarios.SuspendLayout();
            flowLayoutPanel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbStartuTela1Usuarios).BeginInit();
            SuspendLayout();
            // 
            // ptbFundoTela1Usuarios
            // 
            ptbFundoTela1Usuarios.Image = (Image)resources.GetObject("ptbFundoTela1Usuarios.Image");
            ptbFundoTela1Usuarios.Location = new Point(1, -1);
            ptbFundoTela1Usuarios.Name = "ptbFundoTela1Usuarios";
            ptbFundoTela1Usuarios.Size = new Size(799, 454);
            ptbFundoTela1Usuarios.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbFundoTela1Usuarios.TabIndex = 0;
            ptbFundoTela1Usuarios.TabStop = false;
            // 
            // panTela1Usuarios
            // 
            panTela1Usuarios.BackColor = Color.FromArgb(255, 255, 192);
            panTela1Usuarios.Controls.Add(flowLayoutPanel13);
            panTela1Usuarios.Location = new Point(1, -1);
            panTela1Usuarios.Name = "panTela1Usuarios";
            panTela1Usuarios.Size = new Size(799, 43);
            panTela1Usuarios.TabIndex = 3;
            // 
            // flowLayoutPanel13
            // 
            flowLayoutPanel13.Controls.Add(ptbStartuTela1Usuarios);
            flowLayoutPanel13.Controls.Add(lblStartuTela1Usuarios);
            flowLayoutPanel13.Location = new Point(284, 1);
            flowLayoutPanel13.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel13.Name = "flowLayoutPanel13";
            flowLayoutPanel13.Size = new Size(214, 38);
            flowLayoutPanel13.TabIndex = 6;
            // 
            // ptbStartuTela1Usuarios
            // 
            ptbStartuTela1Usuarios.Image = (Image)resources.GetObject("ptbStartuTela1Usuarios.Image");
            ptbStartuTela1Usuarios.Location = new Point(3, 2);
            ptbStartuTela1Usuarios.Margin = new Padding(3, 2, 3, 2);
            ptbStartuTela1Usuarios.Name = "ptbStartuTela1Usuarios";
            ptbStartuTela1Usuarios.Size = new Size(36, 32);
            ptbStartuTela1Usuarios.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbStartuTela1Usuarios.TabIndex = 3;
            ptbStartuTela1Usuarios.TabStop = false;
            // 
            // lblStartuTela1Usuarios
            // 
            lblStartuTela1Usuarios.Anchor = AnchorStyles.Top;
            lblStartuTela1Usuarios.AutoSize = true;
            lblStartuTela1Usuarios.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblStartuTela1Usuarios.ForeColor = Color.Black;
            lblStartuTela1Usuarios.Location = new Point(45, 0);
            lblStartuTela1Usuarios.Name = "lblStartuTela1Usuarios";
            lblStartuTela1Usuarios.Size = new Size(149, 32);
            lblStartuTela1Usuarios.TabIndex = 0;
            lblStartuTela1Usuarios.Text = "STARTUPYX";
            lblStartuTela1Usuarios.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnAcessTela1Usuarios
            // 
            btnAcessTela1Usuarios.BackColor = Color.YellowGreen;
            btnAcessTela1Usuarios.FlatAppearance.BorderSize = 0;
            btnAcessTela1Usuarios.FlatStyle = FlatStyle.Flat;
            btnAcessTela1Usuarios.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnAcessTela1Usuarios.ForeColor = Color.FromArgb(57, 62, 40);
            btnAcessTela1Usuarios.Location = new Point(31, 385);
            btnAcessTela1Usuarios.Name = "btnAcessTela1Usuarios";
            btnAcessTela1Usuarios.Size = new Size(129, 40);
            btnAcessTela1Usuarios.TabIndex = 59;
            btnAcessTela1Usuarios.Text = "Acessar";
            btnAcessTela1Usuarios.UseVisualStyleBackColor = false;
            btnAcessTela1Usuarios.Click += btnAcessTela1Usuarios_Click;
            // 
            // Tela1_Usuarios
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnAcessTela1Usuarios);
            Controls.Add(panTela1Usuarios);
            Controls.Add(ptbFundoTela1Usuarios);
            Name = "Tela1_Usuarios";
            Text = "Introdução";
            ((System.ComponentModel.ISupportInitialize)ptbFundoTela1Usuarios).EndInit();
            panTela1Usuarios.ResumeLayout(false);
            flowLayoutPanel13.ResumeLayout(false);
            flowLayoutPanel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)ptbStartuTela1Usuarios).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.PictureBox ptbFundoTela1Usuarios;
        private Panel panTela1Usuarios;
        private FlowLayoutPanel flowLayoutPanel13;
        private PictureBox ptbStartuTela1Usuarios;
        private Label lblStartuTela1Usuarios;
        private Button btnAcessTela1Usuarios;
    }
}