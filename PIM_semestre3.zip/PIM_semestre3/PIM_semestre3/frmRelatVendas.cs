﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMTESTE_
{
    public partial class frmRelatVendas : Form
    {
        public frmRelatVendas()
        {
            InitializeComponent();
        }

        private void btnGerarRelatVendas_Click(object sender, EventArgs e)
        {
            var strConexao = "server=localhost;uid=root;pwd=BDADIMIN123?;database=db_fazenda_urbana";
            using (var conexao = new MySqlConnection(strConexao))
            {
                try
                {
                    conexao.Open();
                    string query = "SELECT ID_venda_PK, ID_cliente_PK, ID_produto_PK, Quantidade_produto FROM venda"; // Ajuste a consulta conforme necessário

                    MySqlDataAdapter adapter = new MySqlDataAdapter(query, conexao);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgv1RelatVendas.DataSource = dataTable;

                    conexao.Close();
                    MessageBox.Show("Dados atualizados");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void dgv1RelatVendas_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
