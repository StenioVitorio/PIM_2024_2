﻿namespace PIMTESTE_
{
    partial class frmRelatVendas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblRelatVendas = new Label();
            dgv1RelatVendas = new DataGridView();
            btnGerarRelatVendas = new Button();
            ((System.ComponentModel.ISupportInitialize)dgv1RelatVendas).BeginInit();
            SuspendLayout();
            // 
            // lblRelatVendas
            // 
            lblRelatVendas.AutoSize = true;
            lblRelatVendas.Dock = DockStyle.Top;
            lblRelatVendas.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblRelatVendas.Location = new Point(0, 0);
            lblRelatVendas.Name = "lblRelatVendas";
            lblRelatVendas.Size = new Size(378, 51);
            lblRelatVendas.TabIndex = 3;
            lblRelatVendas.Text = "Relatório de Vendas";
            lblRelatVendas.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // dgv1RelatVendas
            // 
            dgv1RelatVendas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv1RelatVendas.Location = new Point(12, 185);
            dgv1RelatVendas.Margin = new Padding(3, 2, 3, 2);
            dgv1RelatVendas.Name = "dgv1RelatVendas";
            dgv1RelatVendas.ReadOnly = true;
            dgv1RelatVendas.RowHeadersWidth = 51;
            dgv1RelatVendas.Size = new Size(560, 120);
            dgv1RelatVendas.TabIndex = 4;
            dgv1RelatVendas.CellContentClick += dgv1RelatVendas_CellContentClick;
            // 
            // btnGerarRelatVendas
            // 
            btnGerarRelatVendas.BackColor = Color.YellowGreen;
            btnGerarRelatVendas.FlatAppearance.BorderSize = 0;
            btnGerarRelatVendas.FlatStyle = FlatStyle.Flat;
            btnGerarRelatVendas.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnGerarRelatVendas.ForeColor = Color.FromArgb(57, 62, 40);
            btnGerarRelatVendas.Location = new Point(421, 346);
            btnGerarRelatVendas.Name = "btnGerarRelatVendas";
            btnGerarRelatVendas.Size = new Size(115, 34);
            btnGerarRelatVendas.TabIndex = 64;
            btnGerarRelatVendas.Text = "Gerar";
            btnGerarRelatVendas.UseVisualStyleBackColor = false;
            btnGerarRelatVendas.Click += btnGerarRelatVendas_Click;
            // 
            // frmRelatVendas
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(238, 241, 212);
            ClientSize = new Size(584, 406);
            Controls.Add(btnGerarRelatVendas);
            Controls.Add(dgv1RelatVendas);
            Controls.Add(lblRelatVendas);
            ForeColor = Color.FromArgb(57, 62, 40);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmRelatVendas";
            Text = "frmRelatVendas";
            ((System.ComponentModel.ISupportInitialize)dgv1RelatVendas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblRelatVendas;
        private DataGridView dgv1RelatVendas;
        private Button btnGerarRelatVendas;
    }
}