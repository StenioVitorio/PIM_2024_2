﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMTESTE_
{
    public partial class TelaDosFuncionarios : Form
    {
        public TelaDosFuncionarios()
        {
            InitializeComponent();
        }

        private void lblStartupyx_Click(object sender, EventArgs e)
        {

        }

        private void Content_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnCriarPlant_Click(object sender, EventArgs e)
        {
            this.panTelaFuncio.Controls.Clear();
            frmCriarPlant frmCriarPlantView = new frmCriarPlant() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frmCriarPlantView.FormBorderStyle = FormBorderStyle.None;
            this.panTelaFuncio.Controls.Add(frmCriarPlantView);
            frmCriarPlantView.Show();
        }

        private void btnAltPlant_Click(object sender, EventArgs e)
        {
            this.panTelaFuncio.Controls.Clear();
            frmAlterarPlant frmAlterarPlantView = new frmAlterarPlant() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frmAlterarPlantView.FormBorderStyle = FormBorderStyle.None;
            this.panTelaFuncio.Controls.Add(frmAlterarPlantView);
            frmAlterarPlantView.Show();
        }

        private void btnFazerRelatorio_Click(object sender, EventArgs e)
        {
            this.panTelaFuncio.Controls.Clear();
            frmFazerRelat frmFazerRelatView = new frmFazerRelat() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frmFazerRelatView.FormBorderStyle = FormBorderStyle.None;
            this.panTelaFuncio.Controls.Add(frmFazerRelatView);
            frmFazerRelatView.Show();
        }

        private void btnVisualizarPlant_Click(object sender, EventArgs e)
        {
            this.panTelaFuncio.Controls.Clear();
            frmVisualizarPlant frmVisualizarPlantView = new frmVisualizarPlant() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frmVisualizarPlantView.FormBorderStyle = FormBorderStyle.None;
            this.panTelaFuncio.Controls.Add(frmVisualizarPlantView);
            frmVisualizarPlantView.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void TelaDosFuncionarios_Load(object sender, EventArgs e)
        {

        }
    }
}
