﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMTESTE_
{
    public partial class frmFazerRelat : Form
    {
        string plantacao = "";
        public frmFazerRelat()
        {
            InitializeComponent();
            BdRelatorio bd = new BdRelatorio();
            //string[] valores = bd.Select();


            this.cmbSelecPlantFazerRelat.Items.Clear();
            foreach (var i in bd.Select())
            {
                this.cmbSelecPlantFazerRelat.Items.Add(i);
            }



        }

        private void btnSalvarFazerRelat_Click(object sender, EventArgs e)
        {
            //verifica se os campos estao vasios
            if (this.txtbEstacaoFazerRelat.Text == string.Empty || this.txtbMudasNProntas.Text == string.Empty ||
                this.txtbMudasPerdidas.Text == string.Empty || this.txtbQtdMudasProntas.Text == string.Empty)
            {
                //caso algum campo esteja vazio ele mostra essa mensasagem
                MessageBox.Show("Um dos campos não foi preenchido, por favor os preencha com os dados corretos");
            }
            //verifica se o combo box tem um item selecionado
            else if (this.cmbSelecPlantFazerRelat.SelectedItem == null)
            {
                //caso a comobox campo esteja desselecionada ele mostra essa mensasagem
                MessageBox.Show("Por favor selecione uma das plantações disponiveis");
            }
            else
            {


                //executar a query
                BdRelatorio bd = new BdRelatorio();
                bool succss = bd.Insert(this.cmbSelecPlantFazerRelat.GetItemText(this.cmbSelecPlantFazerRelat.SelectedItem), this.txtbQtdMudasProntas.Text);
                MessageBox.Show(succss.ToString());

                //esvazia os campos
                this.txtbEstacaoFazerRelat.Text = string.Empty;
                this.txtbMudasNProntas.Text = string.Empty;
                this.txtbMudasPerdidas.Text = string.Empty;
                this.txtbQtdMudasProntas.Text = string.Empty;
                this.cmbSelecPlantFazerRelat.SelectedIndex = -1;

                //caso tudo esteja certo mostra essa menssagem
                //MessageBox.Show("Relatorio criado!");





            }

        }

        private void cmbSelecPlantFazerRelat_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void frmFazerRelat_Load(object sender, EventArgs e)
        {

        }
    }
}
