﻿namespace PIMTESTE_
{
    partial class TelaDosGerentes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaDosGerentes));
            lblStartuGerente = new Label();
            panStartuGerente = new Panel();
            panel3 = new Panel();
            Content = new Panel();
            flowLayoutPanel13 = new FlowLayoutPanel();
            ptbStartuGerente = new PictureBox();
            panMenuGerente = new Panel();
            ptbMenuGerente = new PictureBox();
            flowLayoutPanel1 = new FlowLayoutPanel();
            ptbRelatPlants = new PictureBox();
            btnRelatoriosPlants = new Button();
            flowLayoutPanel2 = new FlowLayoutPanel();
            ptbRelatEstoq = new PictureBox();
            btnRelatEstoq = new Button();
            button3 = new Button();
            flowLayoutPanel4 = new FlowLayoutPanel();
            ptbFutPlantios = new PictureBox();
            btnFuturosPlant = new Button();
            flowLayoutPanel12 = new FlowLayoutPanel();
            ptbRelatVendas = new PictureBox();
            btnRelatVendas = new Button();
            flowLayoutPanel3 = new FlowLayoutPanel();
            ptbCadastFunc = new PictureBox();
            btnCadastFunc = new Button();
            flowLayoutPanel5 = new FlowLayoutPanel();
            pictureBox6 = new PictureBox();
            button6 = new Button();
            button7 = new Button();
            flowLayoutPanel6 = new FlowLayoutPanel();
            pictureBox7 = new PictureBox();
            button8 = new Button();
            button9 = new Button();
            flowLayoutPanel7 = new FlowLayoutPanel();
            pictureBox8 = new PictureBox();
            button10 = new Button();
            button11 = new Button();
            flowLayoutPanel8 = new FlowLayoutPanel();
            pictureBox9 = new PictureBox();
            button12 = new Button();
            button13 = new Button();
            flowLayoutPanel9 = new FlowLayoutPanel();
            pictureBox10 = new PictureBox();
            button14 = new Button();
            button15 = new Button();
            flowLayoutPanel10 = new FlowLayoutPanel();
            pictureBox11 = new PictureBox();
            button16 = new Button();
            button17 = new Button();
            flowLayoutPanel11 = new FlowLayoutPanel();
            pictureBox12 = new PictureBox();
            button18 = new Button();
            button19 = new Button();
            panTelaGerente = new Panel();
            panStartuGerente.SuspendLayout();
            flowLayoutPanel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbStartuGerente).BeginInit();
            panMenuGerente.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbMenuGerente).BeginInit();
            flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbRelatPlants).BeginInit();
            flowLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbRelatEstoq).BeginInit();
            flowLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbFutPlantios).BeginInit();
            flowLayoutPanel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbRelatVendas).BeginInit();
            flowLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbCadastFunc).BeginInit();
            flowLayoutPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            flowLayoutPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            flowLayoutPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            flowLayoutPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            flowLayoutPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            flowLayoutPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            flowLayoutPanel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            SuspendLayout();
            // 
            // lblStartuGerente
            // 
            lblStartuGerente.Anchor = AnchorStyles.Top;
            lblStartuGerente.AutoSize = true;
            lblStartuGerente.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblStartuGerente.ForeColor = Color.White;
            lblStartuGerente.Location = new Point(45, 0);
            lblStartuGerente.Name = "lblStartuGerente";
            lblStartuGerente.Size = new Size(149, 32);
            lblStartuGerente.TabIndex = 0;
            lblStartuGerente.Text = "STARTUPYX";
            lblStartuGerente.TextAlign = ContentAlignment.MiddleCenter;
            lblStartuGerente.Click += lblStartupyx_Click;
            // 
            // panStartuGerente
            // 
            panStartuGerente.BackColor = Color.FromArgb(57, 62, 40);
            panStartuGerente.Controls.Add(panel3);
            panStartuGerente.Controls.Add(Content);
            panStartuGerente.Controls.Add(flowLayoutPanel13);
            panStartuGerente.Dock = DockStyle.Top;
            panStartuGerente.Location = new Point(0, 0);
            panStartuGerente.Name = "panStartuGerente";
            panStartuGerente.Size = new Size(800, 43);
            panStartuGerente.TabIndex = 2;
            // 
            // panel3
            // 
            panel3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panel3.BackColor = Color.FromArgb(238, 241, 212);
            panel3.Location = new Point(215, 40);
            panel3.Name = "panel3";
            panel3.Size = new Size(584, 0);
            panel3.TabIndex = 4;
            // 
            // Content
            // 
            Content.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Content.BackColor = Color.FromArgb(238, 241, 212);
            Content.Location = new Point(215, 38);
            Content.Name = "Content";
            Content.Size = new Size(482, 0);
            Content.TabIndex = 4;
            // 
            // flowLayoutPanel13
            // 
            flowLayoutPanel13.Controls.Add(ptbStartuGerente);
            flowLayoutPanel13.Controls.Add(lblStartuGerente);
            flowLayoutPanel13.Location = new Point(290, 4);
            flowLayoutPanel13.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel13.Name = "flowLayoutPanel13";
            flowLayoutPanel13.Size = new Size(214, 38);
            flowLayoutPanel13.TabIndex = 5;
            // 
            // ptbStartuGerente
            // 
            ptbStartuGerente.Image = (Image)resources.GetObject("ptbStartuGerente.Image");
            ptbStartuGerente.Location = new Point(3, 2);
            ptbStartuGerente.Margin = new Padding(3, 2, 3, 2);
            ptbStartuGerente.Name = "ptbStartuGerente";
            ptbStartuGerente.Size = new Size(36, 32);
            ptbStartuGerente.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbStartuGerente.TabIndex = 3;
            ptbStartuGerente.TabStop = false;
            // 
            // panMenuGerente
            // 
            panMenuGerente.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            panMenuGerente.BackColor = Color.FromArgb(148, 152, 126);
            panMenuGerente.Controls.Add(ptbMenuGerente);
            panMenuGerente.Controls.Add(flowLayoutPanel1);
            panMenuGerente.Controls.Add(flowLayoutPanel2);
            panMenuGerente.Controls.Add(flowLayoutPanel4);
            panMenuGerente.Controls.Add(flowLayoutPanel12);
            panMenuGerente.Controls.Add(flowLayoutPanel3);
            panMenuGerente.Location = new Point(-2, 0);
            panMenuGerente.Name = "panMenuGerente";
            panMenuGerente.Size = new Size(217, 450);
            panMenuGerente.TabIndex = 3;
            // 
            // ptbMenuGerente
            // 
            ptbMenuGerente.Image = (Image)resources.GetObject("ptbMenuGerente.Image");
            ptbMenuGerente.Location = new Point(38, 63);
            ptbMenuGerente.Name = "ptbMenuGerente";
            ptbMenuGerente.Size = new Size(142, 105);
            ptbMenuGerente.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbMenuGerente.TabIndex = 0;
            ptbMenuGerente.TabStop = false;
            ptbMenuGerente.Click += pictureBox1_Click_1;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Controls.Add(ptbRelatPlants);
            flowLayoutPanel1.Controls.Add(btnRelatoriosPlants);
            flowLayoutPanel1.Location = new Point(2, 238);
            flowLayoutPanel1.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(214, 50);
            flowLayoutPanel1.TabIndex = 0;
            // 
            // ptbRelatPlants
            // 
            ptbRelatPlants.Image = (Image)resources.GetObject("ptbRelatPlants.Image");
            ptbRelatPlants.Location = new Point(3, 2);
            ptbRelatPlants.Margin = new Padding(3, 2, 3, 2);
            ptbRelatPlants.Name = "ptbRelatPlants";
            ptbRelatPlants.Size = new Size(44, 44);
            ptbRelatPlants.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbRelatPlants.TabIndex = 3;
            ptbRelatPlants.TabStop = false;
            // 
            // btnRelatoriosPlants
            // 
            btnRelatoriosPlants.BackColor = Color.FromArgb(148, 152, 126);
            btnRelatoriosPlants.FlatAppearance.BorderSize = 0;
            btnRelatoriosPlants.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            btnRelatoriosPlants.FlatStyle = FlatStyle.Flat;
            btnRelatoriosPlants.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRelatoriosPlants.ForeColor = Color.FromArgb(57, 62, 40);
            btnRelatoriosPlants.Location = new Point(53, 3);
            btnRelatoriosPlants.Name = "btnRelatoriosPlants";
            btnRelatoriosPlants.Size = new Size(158, 47);
            btnRelatoriosPlants.TabIndex = 2;
            btnRelatoriosPlants.Text = "Relatório de Plantações";
            btnRelatoriosPlants.UseVisualStyleBackColor = false;
            btnRelatoriosPlants.Click += btnRelatoriosPlants_Click_1;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.Controls.Add(ptbRelatEstoq);
            flowLayoutPanel2.Controls.Add(btnRelatEstoq);
            flowLayoutPanel2.Controls.Add(button3);
            flowLayoutPanel2.Location = new Point(2, 292);
            flowLayoutPanel2.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(214, 50);
            flowLayoutPanel2.TabIndex = 4;
            // 
            // ptbRelatEstoq
            // 
            ptbRelatEstoq.Image = (Image)resources.GetObject("ptbRelatEstoq.Image");
            ptbRelatEstoq.Location = new Point(3, 2);
            ptbRelatEstoq.Margin = new Padding(3, 2, 3, 2);
            ptbRelatEstoq.Name = "ptbRelatEstoq";
            ptbRelatEstoq.Size = new Size(44, 44);
            ptbRelatEstoq.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbRelatEstoq.TabIndex = 3;
            ptbRelatEstoq.TabStop = false;
            // 
            // btnRelatEstoq
            // 
            btnRelatEstoq.BackColor = Color.FromArgb(148, 152, 126);
            btnRelatEstoq.FlatAppearance.BorderSize = 0;
            btnRelatEstoq.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            btnRelatEstoq.FlatStyle = FlatStyle.Flat;
            btnRelatEstoq.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRelatEstoq.ForeColor = Color.FromArgb(57, 62, 40);
            btnRelatEstoq.Location = new Point(53, 3);
            btnRelatEstoq.Name = "btnRelatEstoq";
            btnRelatEstoq.Size = new Size(158, 43);
            btnRelatEstoq.TabIndex = 2;
            btnRelatEstoq.Text = "Relatório de Estoque";
            btnRelatEstoq.UseVisualStyleBackColor = false;
            btnRelatEstoq.Click += btnRelatEstoq_Click_1;
            // 
            // button3
            // 
            button3.BackColor = Color.LightGray;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Location = new Point(3, 52);
            button3.Name = "button3";
            button3.Size = new Size(158, 43);
            button3.TabIndex = 4;
            button3.Text = "Opc. de Futuros Plantios";
            button3.UseVisualStyleBackColor = false;
            // 
            // flowLayoutPanel4
            // 
            flowLayoutPanel4.Controls.Add(ptbFutPlantios);
            flowLayoutPanel4.Controls.Add(btnFuturosPlant);
            flowLayoutPanel4.Location = new Point(2, 184);
            flowLayoutPanel4.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel4.Name = "flowLayoutPanel4";
            flowLayoutPanel4.Size = new Size(214, 50);
            flowLayoutPanel4.TabIndex = 4;
            // 
            // ptbFutPlantios
            // 
            ptbFutPlantios.Image = (Image)resources.GetObject("ptbFutPlantios.Image");
            ptbFutPlantios.Location = new Point(3, 2);
            ptbFutPlantios.Margin = new Padding(3, 2, 3, 2);
            ptbFutPlantios.Name = "ptbFutPlantios";
            ptbFutPlantios.Size = new Size(44, 44);
            ptbFutPlantios.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbFutPlantios.TabIndex = 3;
            ptbFutPlantios.TabStop = false;
            // 
            // btnFuturosPlant
            // 
            btnFuturosPlant.BackColor = Color.FromArgb(148, 152, 126);
            btnFuturosPlant.FlatAppearance.BorderSize = 0;
            btnFuturosPlant.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            btnFuturosPlant.FlatStyle = FlatStyle.Flat;
            btnFuturosPlant.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnFuturosPlant.ForeColor = Color.FromArgb(57, 62, 40);
            btnFuturosPlant.Location = new Point(53, 3);
            btnFuturosPlant.Name = "btnFuturosPlant";
            btnFuturosPlant.Size = new Size(158, 43);
            btnFuturosPlant.TabIndex = 2;
            btnFuturosPlant.Text = "Futuros Plantios";
            btnFuturosPlant.UseVisualStyleBackColor = false;
            btnFuturosPlant.Click += btnFuturosPlant_Click;
            // 
            // flowLayoutPanel12
            // 
            flowLayoutPanel12.Controls.Add(ptbRelatVendas);
            flowLayoutPanel12.Controls.Add(btnRelatVendas);
            flowLayoutPanel12.Location = new Point(2, 346);
            flowLayoutPanel12.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel12.Name = "flowLayoutPanel12";
            flowLayoutPanel12.Size = new Size(214, 50);
            flowLayoutPanel12.TabIndex = 5;
            // 
            // ptbRelatVendas
            // 
            ptbRelatVendas.Image = (Image)resources.GetObject("ptbRelatVendas.Image");
            ptbRelatVendas.Location = new Point(3, 2);
            ptbRelatVendas.Margin = new Padding(3, 2, 3, 2);
            ptbRelatVendas.Name = "ptbRelatVendas";
            ptbRelatVendas.Size = new Size(44, 44);
            ptbRelatVendas.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbRelatVendas.TabIndex = 3;
            ptbRelatVendas.TabStop = false;
            // 
            // btnRelatVendas
            // 
            btnRelatVendas.BackColor = Color.FromArgb(148, 152, 126);
            btnRelatVendas.FlatAppearance.BorderSize = 0;
            btnRelatVendas.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            btnRelatVendas.FlatStyle = FlatStyle.Flat;
            btnRelatVendas.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRelatVendas.ForeColor = Color.FromArgb(57, 62, 40);
            btnRelatVendas.Location = new Point(53, 3);
            btnRelatVendas.Name = "btnRelatVendas";
            btnRelatVendas.Size = new Size(158, 43);
            btnRelatVendas.TabIndex = 2;
            btnRelatVendas.Text = "Relatório de  Vendas";
            btnRelatVendas.UseVisualStyleBackColor = false;
            btnRelatVendas.Click += button20_Click;
            // 
            // flowLayoutPanel3
            // 
            flowLayoutPanel3.Controls.Add(ptbCadastFunc);
            flowLayoutPanel3.Controls.Add(btnCadastFunc);
            flowLayoutPanel3.Controls.Add(flowLayoutPanel5);
            flowLayoutPanel3.Controls.Add(flowLayoutPanel6);
            flowLayoutPanel3.Controls.Add(flowLayoutPanel8);
            flowLayoutPanel3.Location = new Point(2, 400);
            flowLayoutPanel3.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel3.Name = "flowLayoutPanel3";
            flowLayoutPanel3.Size = new Size(214, 50);
            flowLayoutPanel3.TabIndex = 5;
            // 
            // ptbCadastFunc
            // 
            ptbCadastFunc.Image = (Image)resources.GetObject("ptbCadastFunc.Image");
            ptbCadastFunc.Location = new Point(3, 2);
            ptbCadastFunc.Margin = new Padding(3, 2, 3, 2);
            ptbCadastFunc.Name = "ptbCadastFunc";
            ptbCadastFunc.Size = new Size(44, 44);
            ptbCadastFunc.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbCadastFunc.TabIndex = 3;
            ptbCadastFunc.TabStop = false;
            // 
            // btnCadastFunc
            // 
            btnCadastFunc.BackColor = Color.FromArgb(148, 152, 126);
            btnCadastFunc.FlatAppearance.BorderSize = 0;
            btnCadastFunc.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            btnCadastFunc.FlatStyle = FlatStyle.Flat;
            btnCadastFunc.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCadastFunc.ForeColor = Color.FromArgb(57, 62, 40);
            btnCadastFunc.Location = new Point(53, 3);
            btnCadastFunc.Name = "btnCadastFunc";
            btnCadastFunc.Size = new Size(158, 43);
            btnCadastFunc.TabIndex = 2;
            btnCadastFunc.Text = "Cadastrar Funcionário";
            btnCadastFunc.UseVisualStyleBackColor = false;
            btnCadastFunc.Click += btnCadastFunc_Click;
            // 
            // flowLayoutPanel5
            // 
            flowLayoutPanel5.Controls.Add(pictureBox6);
            flowLayoutPanel5.Controls.Add(button6);
            flowLayoutPanel5.Controls.Add(button7);
            flowLayoutPanel5.Location = new Point(3, 51);
            flowLayoutPanel5.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel5.Name = "flowLayoutPanel5";
            flowLayoutPanel5.Size = new Size(214, 50);
            flowLayoutPanel5.TabIndex = 6;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(3, 2);
            pictureBox6.Margin = new Padding(3, 2, 3, 2);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(44, 44);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 3;
            pictureBox6.TabStop = false;
            // 
            // button6
            // 
            button6.BackColor = Color.LightGray;
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Location = new Point(53, 3);
            button6.Name = "button6";
            button6.Size = new Size(158, 43);
            button6.TabIndex = 2;
            button6.Text = "Cadastrar Funcionário";
            button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            button7.BackColor = Color.LightGray;
            button7.FlatAppearance.BorderSize = 0;
            button7.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Location = new Point(3, 52);
            button7.Name = "button7";
            button7.Size = new Size(158, 43);
            button7.TabIndex = 4;
            button7.Text = "Opc. de Futuros Plantios";
            button7.UseVisualStyleBackColor = false;
            // 
            // flowLayoutPanel6
            // 
            flowLayoutPanel6.Controls.Add(pictureBox7);
            flowLayoutPanel6.Controls.Add(button8);
            flowLayoutPanel6.Controls.Add(button9);
            flowLayoutPanel6.Controls.Add(flowLayoutPanel7);
            flowLayoutPanel6.Location = new Point(3, 105);
            flowLayoutPanel6.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel6.Name = "flowLayoutPanel6";
            flowLayoutPanel6.Size = new Size(214, 50);
            flowLayoutPanel6.TabIndex = 7;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(3, 2);
            pictureBox7.Margin = new Padding(3, 2, 3, 2);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(44, 44);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 3;
            pictureBox7.TabStop = false;
            // 
            // button8
            // 
            button8.BackColor = Color.LightGray;
            button8.FlatAppearance.BorderSize = 0;
            button8.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            button8.FlatStyle = FlatStyle.Flat;
            button8.Location = new Point(53, 3);
            button8.Name = "button8";
            button8.Size = new Size(158, 43);
            button8.TabIndex = 2;
            button8.Text = "Cadastrar Funcionário";
            button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            button9.BackColor = Color.LightGray;
            button9.FlatAppearance.BorderSize = 0;
            button9.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            button9.FlatStyle = FlatStyle.Flat;
            button9.Location = new Point(3, 52);
            button9.Name = "button9";
            button9.Size = new Size(158, 43);
            button9.TabIndex = 4;
            button9.Text = "Opc. de Futuros Plantios";
            button9.UseVisualStyleBackColor = false;
            // 
            // flowLayoutPanel7
            // 
            flowLayoutPanel7.Controls.Add(pictureBox8);
            flowLayoutPanel7.Controls.Add(button10);
            flowLayoutPanel7.Controls.Add(button11);
            flowLayoutPanel7.Location = new Point(3, 100);
            flowLayoutPanel7.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel7.Name = "flowLayoutPanel7";
            flowLayoutPanel7.Size = new Size(214, 50);
            flowLayoutPanel7.TabIndex = 6;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(3, 2);
            pictureBox8.Margin = new Padding(3, 2, 3, 2);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(44, 44);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 3;
            pictureBox8.TabStop = false;
            // 
            // button10
            // 
            button10.BackColor = Color.LightGray;
            button10.FlatAppearance.BorderSize = 0;
            button10.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            button10.FlatStyle = FlatStyle.Flat;
            button10.Location = new Point(53, 3);
            button10.Name = "button10";
            button10.Size = new Size(158, 43);
            button10.TabIndex = 2;
            button10.Text = "Cadastrar Funcionário";
            button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            button11.BackColor = Color.LightGray;
            button11.FlatAppearance.BorderSize = 0;
            button11.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            button11.FlatStyle = FlatStyle.Flat;
            button11.Location = new Point(3, 52);
            button11.Name = "button11";
            button11.Size = new Size(158, 43);
            button11.TabIndex = 4;
            button11.Text = "Opc. de Futuros Plantios";
            button11.UseVisualStyleBackColor = false;
            // 
            // flowLayoutPanel8
            // 
            flowLayoutPanel8.Controls.Add(pictureBox9);
            flowLayoutPanel8.Controls.Add(button12);
            flowLayoutPanel8.Controls.Add(button13);
            flowLayoutPanel8.Controls.Add(flowLayoutPanel9);
            flowLayoutPanel8.Controls.Add(flowLayoutPanel10);
            flowLayoutPanel8.Location = new Point(3, 159);
            flowLayoutPanel8.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel8.Name = "flowLayoutPanel8";
            flowLayoutPanel8.Size = new Size(214, 50);
            flowLayoutPanel8.TabIndex = 8;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(3, 2);
            pictureBox9.Margin = new Padding(3, 2, 3, 2);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(44, 44);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 3;
            pictureBox9.TabStop = false;
            // 
            // button12
            // 
            button12.BackColor = Color.LightGray;
            button12.FlatAppearance.BorderSize = 0;
            button12.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            button12.FlatStyle = FlatStyle.Flat;
            button12.Location = new Point(53, 3);
            button12.Name = "button12";
            button12.Size = new Size(158, 43);
            button12.TabIndex = 2;
            button12.Text = "Cadastrar Funcionário";
            button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            button13.BackColor = Color.LightGray;
            button13.FlatAppearance.BorderSize = 0;
            button13.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            button13.FlatStyle = FlatStyle.Flat;
            button13.Location = new Point(3, 52);
            button13.Name = "button13";
            button13.Size = new Size(158, 43);
            button13.TabIndex = 4;
            button13.Text = "Opc. de Futuros Plantios";
            button13.UseVisualStyleBackColor = false;
            // 
            // flowLayoutPanel9
            // 
            flowLayoutPanel9.Controls.Add(pictureBox10);
            flowLayoutPanel9.Controls.Add(button14);
            flowLayoutPanel9.Controls.Add(button15);
            flowLayoutPanel9.Location = new Point(3, 100);
            flowLayoutPanel9.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel9.Name = "flowLayoutPanel9";
            flowLayoutPanel9.Size = new Size(214, 50);
            flowLayoutPanel9.TabIndex = 6;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = (Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new Point(3, 2);
            pictureBox10.Margin = new Padding(3, 2, 3, 2);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(44, 44);
            pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox10.TabIndex = 3;
            pictureBox10.TabStop = false;
            // 
            // button14
            // 
            button14.BackColor = Color.LightGray;
            button14.FlatAppearance.BorderSize = 0;
            button14.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            button14.FlatStyle = FlatStyle.Flat;
            button14.Location = new Point(53, 3);
            button14.Name = "button14";
            button14.Size = new Size(158, 43);
            button14.TabIndex = 2;
            button14.Text = "Cadastrar Funcionário";
            button14.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            button15.BackColor = Color.LightGray;
            button15.FlatAppearance.BorderSize = 0;
            button15.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            button15.FlatStyle = FlatStyle.Flat;
            button15.Location = new Point(3, 52);
            button15.Name = "button15";
            button15.Size = new Size(158, 43);
            button15.TabIndex = 4;
            button15.Text = "Opc. de Futuros Plantios";
            button15.UseVisualStyleBackColor = false;
            // 
            // flowLayoutPanel10
            // 
            flowLayoutPanel10.Controls.Add(pictureBox11);
            flowLayoutPanel10.Controls.Add(button16);
            flowLayoutPanel10.Controls.Add(button17);
            flowLayoutPanel10.Controls.Add(flowLayoutPanel11);
            flowLayoutPanel10.Location = new Point(3, 154);
            flowLayoutPanel10.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel10.Name = "flowLayoutPanel10";
            flowLayoutPanel10.Size = new Size(214, 50);
            flowLayoutPanel10.TabIndex = 7;
            // 
            // pictureBox11
            // 
            pictureBox11.Image = (Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new Point(3, 2);
            pictureBox11.Margin = new Padding(3, 2, 3, 2);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(44, 44);
            pictureBox11.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox11.TabIndex = 3;
            pictureBox11.TabStop = false;
            // 
            // button16
            // 
            button16.BackColor = Color.LightGray;
            button16.FlatAppearance.BorderSize = 0;
            button16.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            button16.FlatStyle = FlatStyle.Flat;
            button16.Location = new Point(53, 3);
            button16.Name = "button16";
            button16.Size = new Size(158, 43);
            button16.TabIndex = 2;
            button16.Text = "Cadastrar Funcionário";
            button16.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            button17.BackColor = Color.LightGray;
            button17.FlatAppearance.BorderSize = 0;
            button17.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            button17.FlatStyle = FlatStyle.Flat;
            button17.Location = new Point(3, 52);
            button17.Name = "button17";
            button17.Size = new Size(158, 43);
            button17.TabIndex = 4;
            button17.Text = "Opc. de Futuros Plantios";
            button17.UseVisualStyleBackColor = false;
            // 
            // flowLayoutPanel11
            // 
            flowLayoutPanel11.Controls.Add(pictureBox12);
            flowLayoutPanel11.Controls.Add(button18);
            flowLayoutPanel11.Controls.Add(button19);
            flowLayoutPanel11.Location = new Point(3, 100);
            flowLayoutPanel11.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel11.Name = "flowLayoutPanel11";
            flowLayoutPanel11.Size = new Size(214, 50);
            flowLayoutPanel11.TabIndex = 6;
            // 
            // pictureBox12
            // 
            pictureBox12.Image = (Image)resources.GetObject("pictureBox12.Image");
            pictureBox12.Location = new Point(3, 2);
            pictureBox12.Margin = new Padding(3, 2, 3, 2);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(44, 44);
            pictureBox12.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox12.TabIndex = 3;
            pictureBox12.TabStop = false;
            // 
            // button18
            // 
            button18.BackColor = Color.LightGray;
            button18.FlatAppearance.BorderSize = 0;
            button18.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            button18.FlatStyle = FlatStyle.Flat;
            button18.Location = new Point(53, 3);
            button18.Name = "button18";
            button18.Size = new Size(158, 43);
            button18.TabIndex = 2;
            button18.Text = "Cadastrar Funcionário";
            button18.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            button19.BackColor = Color.LightGray;
            button19.FlatAppearance.BorderSize = 0;
            button19.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            button19.FlatStyle = FlatStyle.Flat;
            button19.Location = new Point(3, 52);
            button19.Name = "button19";
            button19.Size = new Size(158, 43);
            button19.TabIndex = 4;
            button19.Text = "Opc. de Futuros Plantios";
            button19.UseVisualStyleBackColor = false;
            // 
            // panTelaGerente
            // 
            panTelaGerente.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panTelaGerente.BackColor = Color.FromArgb(238, 241, 212);
            panTelaGerente.Location = new Point(215, 43);
            panTelaGerente.Name = "panTelaGerente";
            panTelaGerente.Size = new Size(584, 406);
            panTelaGerente.TabIndex = 4;
            // 
            // TelaDosGerentes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(238, 241, 212);
            ClientSize = new Size(800, 450);
            Controls.Add(panTelaGerente);
            Controls.Add(panStartuGerente);
            Controls.Add(panMenuGerente);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "TelaDosGerentes";
            Text = "TelaDosGerentes";
            Load += TelaDosGerentes_Load;
            panStartuGerente.ResumeLayout(false);
            flowLayoutPanel13.ResumeLayout(false);
            flowLayoutPanel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)ptbStartuGerente).EndInit();
            panMenuGerente.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)ptbMenuGerente).EndInit();
            flowLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)ptbRelatPlants).EndInit();
            flowLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)ptbRelatEstoq).EndInit();
            flowLayoutPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)ptbFutPlantios).EndInit();
            flowLayoutPanel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)ptbRelatVendas).EndInit();
            flowLayoutPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)ptbCadastFunc).EndInit();
            flowLayoutPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            flowLayoutPanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            flowLayoutPanel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            flowLayoutPanel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            flowLayoutPanel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            flowLayoutPanel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            flowLayoutPanel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label lblStartuGerente;
        private Panel panStartuGerente;
        private Panel panMenuGerente;
        private PictureBox ptbMenuGerente;
        private Button btnRelatoriosPlants;
        private FlowLayoutPanel flowLayoutPanel1;
        private PictureBox ptbRelatPlants;
        private FlowLayoutPanel flowLayoutPanel2;
        private PictureBox ptbRelatEstoq;
        private Button btnRelatEstoq;
        private Button button3;
        private FlowLayoutPanel flowLayoutPanel4;
        private PictureBox ptbFutPlantios;
        private Button btnFuturosPlant;
        private FlowLayoutPanel flowLayoutPanel3;
        private PictureBox ptbCadastFunc;
        private Button btnCadastFunc;
        private FlowLayoutPanel flowLayoutPanel12;
        private PictureBox ptbRelatVendas;
        private Button btnRelatVendas;
        private FlowLayoutPanel flowLayoutPanel5;
        private PictureBox pictureBox6;
        private Button button6;
        private Button button7;
        private FlowLayoutPanel flowLayoutPanel6;
        private PictureBox pictureBox7;
        private Button button8;
        private Button button9;
        private FlowLayoutPanel flowLayoutPanel7;
        private PictureBox pictureBox8;
        private Button button10;
        private Button button11;
        private FlowLayoutPanel flowLayoutPanel8;
        private PictureBox pictureBox9;
        private Button button12;
        private Button button13;
        private FlowLayoutPanel flowLayoutPanel9;
        private PictureBox pictureBox10;
        private Button button14;
        private Button button15;
        private FlowLayoutPanel flowLayoutPanel10;
        private PictureBox pictureBox11;
        private Button button16;
        private Button button17;
        private FlowLayoutPanel flowLayoutPanel11;
        private PictureBox pictureBox12;
        private Button button18;
        private Button button19;
        private FlowLayoutPanel flowLayoutPanel13;
        private PictureBox ptbStartuGerente;
        private Panel Content;
        private Panel panel3;
        private Panel panTelaGerente;
    }
}