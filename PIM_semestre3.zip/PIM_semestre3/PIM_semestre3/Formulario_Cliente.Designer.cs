﻿namespace PIMTESTE_
{
    partial class Formulario_Cliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Formulario_Cliente));
            txtbNomeFormClien = new TextBox();
            flowLayoutPanel2 = new FlowLayoutPanel();
            txtbBairroFormClien = new TextBox();
            txtbCNPJFormClien = new TextBox();
            txtbRuaFormClien = new TextBox();
            txtbRSocialFormClien = new TextBox();
            txtbNumFormClien = new TextBox();
            txtbUFFormClien = new TextBox();
            txtbEmailFormClien = new TextBox();
            txtbMunicFormClien = new TextBox();
            txtbTelFixoFormClien = new TextBox();
            txtbCEPFormClien = new TextBox();
            txtbTelCelFormClien = new TextBox();
            txtbUsuarios = new TextBox();
            txtbSenha = new TextBox();
            Content = new Panel();
            panCriarContaFormClien = new Panel();
            btnProximoFormClien = new Button();
            lblPCamposFormClien = new Label();
            lblCriarContaFormClien = new Label();
            panStartuFormClien = new Panel();
            flowLayoutPanel13 = new FlowLayoutPanel();
            ptbStartuFormClien = new PictureBox();
            lblStartuFormClien = new Label();
            flowLayoutPanel2.SuspendLayout();
            Content.SuspendLayout();
            panCriarContaFormClien.SuspendLayout();
            panStartuFormClien.SuspendLayout();
            flowLayoutPanel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbStartuFormClien).BeginInit();
            SuspendLayout();
            // 
            // txtbNomeFormClien
            // 
            txtbNomeFormClien.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbNomeFormClien.Location = new Point(3, 3);
            txtbNomeFormClien.Name = "txtbNomeFormClien";
            txtbNomeFormClien.PlaceholderText = "Nome completo*";
            txtbNomeFormClien.Size = new Size(310, 29);
            txtbNomeFormClien.TabIndex = 38;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.Controls.Add(txtbNomeFormClien);
            flowLayoutPanel2.Controls.Add(txtbBairroFormClien);
            flowLayoutPanel2.Controls.Add(txtbCNPJFormClien);
            flowLayoutPanel2.Controls.Add(txtbRuaFormClien);
            flowLayoutPanel2.Controls.Add(txtbRSocialFormClien);
            flowLayoutPanel2.Controls.Add(txtbNumFormClien);
            flowLayoutPanel2.Controls.Add(txtbUFFormClien);
            flowLayoutPanel2.Controls.Add(txtbEmailFormClien);
            flowLayoutPanel2.Controls.Add(txtbMunicFormClien);
            flowLayoutPanel2.Controls.Add(txtbTelFixoFormClien);
            flowLayoutPanel2.Controls.Add(txtbCEPFormClien);
            flowLayoutPanel2.Controls.Add(txtbTelCelFormClien);
            flowLayoutPanel2.Controls.Add(txtbUsuarios);
            flowLayoutPanel2.Controls.Add(txtbSenha);
            flowLayoutPanel2.Location = new Point(79, 127);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(632, 243);
            flowLayoutPanel2.TabIndex = 51;
            // 
            // txtbBairroFormClien
            // 
            txtbBairroFormClien.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbBairroFormClien.Location = new Point(319, 3);
            txtbBairroFormClien.Name = "txtbBairroFormClien";
            txtbBairroFormClien.PlaceholderText = "Bairro*";
            txtbBairroFormClien.Size = new Size(310, 29);
            txtbBairroFormClien.TabIndex = 39;
            // 
            // txtbCNPJFormClien
            // 
            txtbCNPJFormClien.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbCNPJFormClien.Location = new Point(3, 38);
            txtbCNPJFormClien.Name = "txtbCNPJFormClien";
            txtbCNPJFormClien.PlaceholderText = "CNPJ*";
            txtbCNPJFormClien.Size = new Size(310, 29);
            txtbCNPJFormClien.TabIndex = 40;
            // 
            // txtbRuaFormClien
            // 
            txtbRuaFormClien.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbRuaFormClien.Location = new Point(319, 38);
            txtbRuaFormClien.Name = "txtbRuaFormClien";
            txtbRuaFormClien.PlaceholderText = "Rua*";
            txtbRuaFormClien.Size = new Size(310, 29);
            txtbRuaFormClien.TabIndex = 41;
            // 
            // txtbRSocialFormClien
            // 
            txtbRSocialFormClien.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbRSocialFormClien.Location = new Point(3, 73);
            txtbRSocialFormClien.Name = "txtbRSocialFormClien";
            txtbRSocialFormClien.PlaceholderText = "Razão Social*";
            txtbRSocialFormClien.Size = new Size(310, 29);
            txtbRSocialFormClien.TabIndex = 42;
            // 
            // txtbNumFormClien
            // 
            txtbNumFormClien.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbNumFormClien.Location = new Point(319, 73);
            txtbNumFormClien.Name = "txtbNumFormClien";
            txtbNumFormClien.PlaceholderText = "Número*";
            txtbNumFormClien.Size = new Size(310, 29);
            txtbNumFormClien.TabIndex = 43;
            // 
            // txtbUFFormClien
            // 
            txtbUFFormClien.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbUFFormClien.Location = new Point(3, 108);
            txtbUFFormClien.Name = "txtbUFFormClien";
            txtbUFFormClien.PlaceholderText = "UF*";
            txtbUFFormClien.Size = new Size(310, 29);
            txtbUFFormClien.TabIndex = 44;
            // 
            // txtbEmailFormClien
            // 
            txtbEmailFormClien.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbEmailFormClien.Location = new Point(319, 108);
            txtbEmailFormClien.Name = "txtbEmailFormClien";
            txtbEmailFormClien.PlaceholderText = "E-mail*";
            txtbEmailFormClien.Size = new Size(310, 29);
            txtbEmailFormClien.TabIndex = 45;
            txtbEmailFormClien.TextChanged += textBox19_TextChanged;
            // 
            // txtbMunicFormClien
            // 
            txtbMunicFormClien.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbMunicFormClien.Location = new Point(3, 143);
            txtbMunicFormClien.Name = "txtbMunicFormClien";
            txtbMunicFormClien.PlaceholderText = "Município*";
            txtbMunicFormClien.Size = new Size(310, 29);
            txtbMunicFormClien.TabIndex = 46;
            // 
            // txtbTelFixoFormClien
            // 
            txtbTelFixoFormClien.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbTelFixoFormClien.Location = new Point(319, 143);
            txtbTelFixoFormClien.Name = "txtbTelFixoFormClien";
            txtbTelFixoFormClien.PlaceholderText = "Telefone Fixo*";
            txtbTelFixoFormClien.Size = new Size(310, 29);
            txtbTelFixoFormClien.TabIndex = 47;
            // 
            // txtbCEPFormClien
            // 
            txtbCEPFormClien.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbCEPFormClien.Location = new Point(3, 178);
            txtbCEPFormClien.Name = "txtbCEPFormClien";
            txtbCEPFormClien.PlaceholderText = "CEP*";
            txtbCEPFormClien.Size = new Size(310, 29);
            txtbCEPFormClien.TabIndex = 48;
            // 
            // txtbTelCelFormClien
            // 
            txtbTelCelFormClien.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbTelCelFormClien.Location = new Point(319, 178);
            txtbTelCelFormClien.Name = "txtbTelCelFormClien";
            txtbTelCelFormClien.PlaceholderText = "Telefone Celular*";
            txtbTelCelFormClien.Size = new Size(310, 29);
            txtbTelCelFormClien.TabIndex = 49;
            // 
            // txtbUsuarios
            // 
            txtbUsuarios.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbUsuarios.Location = new Point(3, 213);
            txtbUsuarios.Name = "txtbUsuarios";
            txtbUsuarios.PlaceholderText = "Usuario*";
            txtbUsuarios.Size = new Size(310, 29);
            txtbUsuarios.TabIndex = 50;
            // 
            // txtbSenha
            // 
            txtbSenha.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbSenha.Location = new Point(319, 213);
            txtbSenha.Name = "txtbSenha";
            txtbSenha.PlaceholderText = "Senha*";
            txtbSenha.Size = new Size(310, 29);
            txtbSenha.TabIndex = 51;
            // 
            // Content
            // 
            Content.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Content.BackColor = Color.FromArgb(126, 211, 109);
            Content.Controls.Add(panCriarContaFormClien);
            Content.Controls.Add(panStartuFormClien);
            Content.Location = new Point(0, 0);
            Content.Name = "Content";
            Content.Size = new Size(802, 449);
            Content.TabIndex = 52;
            // 
            // panCriarContaFormClien
            // 
            panCriarContaFormClien.Controls.Add(btnProximoFormClien);
            panCriarContaFormClien.Controls.Add(lblPCamposFormClien);
            panCriarContaFormClien.Controls.Add(flowLayoutPanel2);
            panCriarContaFormClien.Controls.Add(lblCriarContaFormClien);
            panCriarContaFormClien.Location = new Point(0, 43);
            panCriarContaFormClien.Margin = new Padding(3, 2, 3, 2);
            panCriarContaFormClien.Name = "panCriarContaFormClien";
            panCriarContaFormClien.Size = new Size(799, 406);
            panCriarContaFormClien.TabIndex = 59;
            // 
            // btnProximoFormClien
            // 
            btnProximoFormClien.BackColor = Color.YellowGreen;
            btnProximoFormClien.FlatAppearance.BorderSize = 0;
            btnProximoFormClien.FlatStyle = FlatStyle.Flat;
            btnProximoFormClien.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnProximoFormClien.ForeColor = Color.FromArgb(57, 62, 40);
            btnProximoFormClien.Location = new Point(592, 351);
            btnProximoFormClien.Name = "btnProximoFormClien";
            btnProximoFormClien.Size = new Size(115, 34);
            btnProximoFormClien.TabIndex = 57;
            btnProximoFormClien.Text = "Próximo";
            btnProximoFormClien.UseVisualStyleBackColor = false;
            btnProximoFormClien.Click += button5_Click;
            // 
            // lblPCamposFormClien
            // 
            lblPCamposFormClien.AutoSize = true;
            lblPCamposFormClien.BackColor = Color.Transparent;
            lblPCamposFormClien.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPCamposFormClien.ForeColor = SystemColors.WindowText;
            lblPCamposFormClien.Location = new Point(79, 95);
            lblPCamposFormClien.Name = "lblPCamposFormClien";
            lblPCamposFormClien.Size = new Size(215, 30);
            lblPCamposFormClien.TabIndex = 58;
            lblPCamposFormClien.Text = "Preencha os Campos";
            lblPCamposFormClien.Click += label1_Click;
            // 
            // lblCriarContaFormClien
            // 
            lblCriarContaFormClien.AutoSize = true;
            lblCriarContaFormClien.BackColor = Color.Transparent;
            lblCriarContaFormClien.Dock = DockStyle.Top;
            lblCriarContaFormClien.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCriarContaFormClien.ForeColor = Color.FromArgb(57, 62, 40);
            lblCriarContaFormClien.Location = new Point(0, 0);
            lblCriarContaFormClien.Name = "lblCriarContaFormClien";
            lblCriarContaFormClien.Size = new Size(232, 51);
            lblCriarContaFormClien.TabIndex = 52;
            lblCriarContaFormClien.Text = "Criar Conta:";
            lblCriarContaFormClien.TextAlign = ContentAlignment.MiddleCenter;
            lblCriarContaFormClien.Click += lblAlterarPlant_Click;
            // 
            // panStartuFormClien
            // 
            panStartuFormClien.BackColor = Color.FromArgb(255, 255, 192);
            panStartuFormClien.Controls.Add(flowLayoutPanel13);
            panStartuFormClien.Dock = DockStyle.Top;
            panStartuFormClien.Location = new Point(0, 0);
            panStartuFormClien.Name = "panStartuFormClien";
            panStartuFormClien.Size = new Size(802, 43);
            panStartuFormClien.TabIndex = 58;
            // 
            // flowLayoutPanel13
            // 
            flowLayoutPanel13.Controls.Add(ptbStartuFormClien);
            flowLayoutPanel13.Controls.Add(lblStartuFormClien);
            flowLayoutPanel13.Location = new Point(281, 0);
            flowLayoutPanel13.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel13.Name = "flowLayoutPanel13";
            flowLayoutPanel13.Size = new Size(214, 38);
            flowLayoutPanel13.TabIndex = 6;
            // 
            // ptbStartuFormClien
            // 
            ptbStartuFormClien.Image = (Image)resources.GetObject("ptbStartuFormClien.Image");
            ptbStartuFormClien.Location = new Point(3, 2);
            ptbStartuFormClien.Margin = new Padding(3, 2, 3, 2);
            ptbStartuFormClien.Name = "ptbStartuFormClien";
            ptbStartuFormClien.Size = new Size(36, 32);
            ptbStartuFormClien.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbStartuFormClien.TabIndex = 3;
            ptbStartuFormClien.TabStop = false;
            // 
            // lblStartuFormClien
            // 
            lblStartuFormClien.Anchor = AnchorStyles.Top;
            lblStartuFormClien.AutoSize = true;
            lblStartuFormClien.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblStartuFormClien.ForeColor = Color.Black;
            lblStartuFormClien.Location = new Point(45, 0);
            lblStartuFormClien.Name = "lblStartuFormClien";
            lblStartuFormClien.Size = new Size(149, 32);
            lblStartuFormClien.TabIndex = 0;
            lblStartuFormClien.Text = "STARTUPYX";
            lblStartuFormClien.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Formulario_Cliente
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(800, 450);
            Controls.Add(Content);
            Name = "Formulario_Cliente";
            Text = "formulario_cliente";
            Load += Formulario_Cliente_Load;
            flowLayoutPanel2.ResumeLayout(false);
            flowLayoutPanel2.PerformLayout();
            Content.ResumeLayout(false);
            panCriarContaFormClien.ResumeLayout(false);
            panCriarContaFormClien.PerformLayout();
            panStartuFormClien.ResumeLayout(false);
            flowLayoutPanel13.ResumeLayout(false);
            flowLayoutPanel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)ptbStartuFormClien).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private System.Windows.Forms.TextBox txtbNomeFormClien;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private Panel Content;
        private TextBox txtbCNPJFormClien;
        private TextBox txtbRuaFormClien;
        private TextBox txtbRSocialFormClien;
        private TextBox txtbNumFormClien;
        private TextBox txtbUFFormClien;
        private TextBox txtbEmailFormClien;
        private TextBox txtbMunicFormClien;
        private TextBox txtbTelFixoFormClien;
        private Label lblCriarContaFormClien;
        private Button btnProximoFormClien;
        private Panel panStartuFormClien;
        private FlowLayoutPanel flowLayoutPanel13;
        private PictureBox ptbStartuFormClien;
        private Label lblStartuFormClien;
        private Panel panCriarContaFormClien;
        private Label lblPCamposFormClien;
        private TextBox txtbCEPFormClien;
        private TextBox txtbBairroFormClien;
        private TextBox txtbTelCelFormClien;
        private TextBox txtbUsuarios;
        private TextBox txtbSenha;
    }
}