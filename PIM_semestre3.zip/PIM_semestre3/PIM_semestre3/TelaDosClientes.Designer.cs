﻿namespace PIMTESTE_
{
    partial class TelaDosClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaDosClientes));
            panMenuTelaClien = new Panel();
            flowLayoutPanel4 = new FlowLayoutPanel();
            ptbComprarTelaClien = new PictureBox();
            btnComprarTelaClien = new Button();
            ptbMenuTelaClien = new PictureBox();
            panTelaClien = new Panel();
            flowLayoutPanel13 = new FlowLayoutPanel();
            ptbStartuTelaClien = new PictureBox();
            lblStartuTelaClien = new Label();
            panStartuTelaClien = new Panel();
            panMenuTelaClien.SuspendLayout();
            flowLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbComprarTelaClien).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ptbMenuTelaClien).BeginInit();
            flowLayoutPanel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbStartuTelaClien).BeginInit();
            panStartuTelaClien.SuspendLayout();
            SuspendLayout();
            // 
            // panMenuTelaClien
            // 
            panMenuTelaClien.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            panMenuTelaClien.BackColor = Color.FromArgb(66, 110, 49);
            panMenuTelaClien.Controls.Add(flowLayoutPanel4);
            panMenuTelaClien.Controls.Add(ptbMenuTelaClien);
            panMenuTelaClien.Location = new Point(-2, 0);
            panMenuTelaClien.Name = "panMenuTelaClien";
            panMenuTelaClien.Size = new Size(217, 450);
            panMenuTelaClien.TabIndex = 0;
            // 
            // flowLayoutPanel4
            // 
            flowLayoutPanel4.Controls.Add(ptbComprarTelaClien);
            flowLayoutPanel4.Controls.Add(btnComprarTelaClien);
            flowLayoutPanel4.Location = new Point(3, 195);
            flowLayoutPanel4.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel4.Name = "flowLayoutPanel4";
            flowLayoutPanel4.Size = new Size(214, 50);
            flowLayoutPanel4.TabIndex = 5;
            // 
            // ptbComprarTelaClien
            // 
            ptbComprarTelaClien.Image = (Image)resources.GetObject("ptbComprarTelaClien.Image");
            ptbComprarTelaClien.Location = new Point(3, 2);
            ptbComprarTelaClien.Margin = new Padding(3, 2, 3, 2);
            ptbComprarTelaClien.Name = "ptbComprarTelaClien";
            ptbComprarTelaClien.Size = new Size(44, 44);
            ptbComprarTelaClien.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbComprarTelaClien.TabIndex = 3;
            ptbComprarTelaClien.TabStop = false;
            // 
            // btnComprarTelaClien
            // 
            btnComprarTelaClien.BackColor = Color.FromArgb(66, 110, 49);
            btnComprarTelaClien.FlatAppearance.BorderSize = 0;
            btnComprarTelaClien.FlatAppearance.MouseDownBackColor = Color.DarkGray;
            btnComprarTelaClien.FlatStyle = FlatStyle.Flat;
            btnComprarTelaClien.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnComprarTelaClien.ForeColor = Color.FromArgb(255, 255, 192);
            btnComprarTelaClien.Location = new Point(53, 3);
            btnComprarTelaClien.Name = "btnComprarTelaClien";
            btnComprarTelaClien.Size = new Size(158, 43);
            btnComprarTelaClien.TabIndex = 2;
            btnComprarTelaClien.Text = "Comprar";
            btnComprarTelaClien.UseVisualStyleBackColor = false;
            btnComprarTelaClien.Click += btnComprarTelaClien_Click;
            // 
            // ptbMenuTelaClien
            // 
            ptbMenuTelaClien.Image = (Image)resources.GetObject("ptbMenuTelaClien.Image");
            ptbMenuTelaClien.Location = new Point(38, 66);
            ptbMenuTelaClien.Name = "ptbMenuTelaClien";
            ptbMenuTelaClien.Size = new Size(142, 105);
            ptbMenuTelaClien.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbMenuTelaClien.TabIndex = 0;
            ptbMenuTelaClien.TabStop = false;
            // 
            // panTelaClien
            // 
            panTelaClien.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panTelaClien.BackColor = Color.FromArgb(126, 211, 109);
            panTelaClien.Location = new Point(216, 44);
            panTelaClien.Name = "panTelaClien";
            panTelaClien.Size = new Size(584, 406);
            panTelaClien.TabIndex = 1;
            // 
            // flowLayoutPanel13
            // 
            flowLayoutPanel13.Controls.Add(ptbStartuTelaClien);
            flowLayoutPanel13.Controls.Add(lblStartuTelaClien);
            flowLayoutPanel13.Location = new Point(281, 0);
            flowLayoutPanel13.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel13.Name = "flowLayoutPanel13";
            flowLayoutPanel13.Size = new Size(214, 38);
            flowLayoutPanel13.TabIndex = 6;
            // 
            // ptbStartuTelaClien
            // 
            ptbStartuTelaClien.Image = (Image)resources.GetObject("ptbStartuTelaClien.Image");
            ptbStartuTelaClien.Location = new Point(3, 2);
            ptbStartuTelaClien.Margin = new Padding(3, 2, 3, 2);
            ptbStartuTelaClien.Name = "ptbStartuTelaClien";
            ptbStartuTelaClien.Size = new Size(36, 32);
            ptbStartuTelaClien.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbStartuTelaClien.TabIndex = 3;
            ptbStartuTelaClien.TabStop = false;
            // 
            // lblStartuTelaClien
            // 
            lblStartuTelaClien.Anchor = AnchorStyles.Top;
            lblStartuTelaClien.AutoSize = true;
            lblStartuTelaClien.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblStartuTelaClien.ForeColor = Color.Black;
            lblStartuTelaClien.Location = new Point(45, 0);
            lblStartuTelaClien.Name = "lblStartuTelaClien";
            lblStartuTelaClien.Size = new Size(149, 32);
            lblStartuTelaClien.TabIndex = 0;
            lblStartuTelaClien.Text = "STARTUPYX";
            lblStartuTelaClien.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panStartuTelaClien
            // 
            panStartuTelaClien.BackColor = Color.FromArgb(255, 255, 192);
            panStartuTelaClien.Controls.Add(flowLayoutPanel13);
            panStartuTelaClien.Dock = DockStyle.Top;
            panStartuTelaClien.Location = new Point(0, 0);
            panStartuTelaClien.Name = "panStartuTelaClien";
            panStartuTelaClien.Size = new Size(800, 43);
            panStartuTelaClien.TabIndex = 3;
            // 
            // TelaDosClientes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(126, 211, 109);
            ClientSize = new Size(800, 450);
            Controls.Add(panStartuTelaClien);
            Controls.Add(panTelaClien);
            Controls.Add(panMenuTelaClien);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "TelaDosClientes";
            Text = "TelaDosClientes";
            panMenuTelaClien.ResumeLayout(false);
            flowLayoutPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)ptbComprarTelaClien).EndInit();
            ((System.ComponentModel.ISupportInitialize)ptbMenuTelaClien).EndInit();
            flowLayoutPanel13.ResumeLayout(false);
            flowLayoutPanel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)ptbStartuTelaClien).EndInit();
            panStartuTelaClien.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panMenuTelaClien;
        private Panel panTelaClien;
        private PictureBox ptbMenuTelaClien;
        private FlowLayoutPanel flowLayoutPanel13;
        private PictureBox ptbStartuTelaClien;
        private Label lblStartuTelaClien;
        private Panel panStartuTelaClien;
        private FlowLayoutPanel flowLayoutPanel4;
        private PictureBox ptbComprarTelaClien;
        private Button btnComprarTelaClien;
    }
}