namespace PIMTESTE_
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();

            //------------inicia a tela de Login como tela inicial
            //Application.Run(new Tela1_Usuarios());

            //------------inicia a aplica��o com a tela dos clientes como tela inicial
            //Application.Run(new TelaDosClientes());

            //------------inicia a aplica��o com a tela dos funcionarios como tela inicial
            //Application.Run(new TelaDosFuncionarios());

            //------------inicia a aplica��o com a tela dos gerentes como tela inicial
            Application.Run(new TelaDosGerentes());
        }
    }
}