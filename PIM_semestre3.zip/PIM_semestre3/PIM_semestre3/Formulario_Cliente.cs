﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMTESTE_
{
    public partial class Formulario_Cliente : Form
    {
        public Formulario_Cliente()
        {
            InitializeComponent();
        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Tela1_Usuarios maintela = new Tela1_Usuarios();
            this.Hide();
            maintela.Show();
        }

        private void btnProximoFormClien_Click(object sender, EventArgs e)
        {
            if (this.txtbTelCelFormClien.Text == string.Empty || this.txtbNomeFormClien.Text == string.Empty 
                || this.txtbRSocialFormClien.Text == string.Empty || this.txtbCEPFormClien.Text == string.Empty
                || this.txtbUFFormClien.Text == string.Empty || this.txtbMunicFormClien.Text == string.Empty
                || this.txtbBairroFormClien.Text == string.Empty || this.txtbRuaFormClien.Text == string.Empty
                || this.txtbNumFormClien.Text == string.Empty || this.txtbEmailFormClien.Text == string.Empty
                || this.txtbTelFixoFormClien.Text == string.Empty || this.txtbCNPJFormClien.Text == string.Empty)
            {
                MessageBox.Show("Existe um campo em branco!");
            }
            else
            {
                MessageBox.Show("Cadastro realizado!");
            }
        }

        private void lblAlterarPlant_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (this.txtbTelCelFormClien.Text == string.Empty || this.txtbNomeFormClien.Text == string.Empty
                || this.txtbRSocialFormClien.Text == string.Empty || this.txtbCEPFormClien.Text == string.Empty
                || this.txtbUFFormClien.Text == string.Empty || this.txtbMunicFormClien.Text == string.Empty
                || this.txtbBairroFormClien.Text == string.Empty || this.txtbRuaFormClien.Text == string.Empty
                || this.txtbNumFormClien.Text == string.Empty || this.txtbEmailFormClien.Text == string.Empty
                || this.txtbTelFixoFormClien.Text == string.Empty || this.txtbCNPJFormClien.Text == string.Empty
                || this.txtbUsuarios.Text == string.Empty || this.txtbSenha.Text == string.Empty)
            {
                MessageBox.Show("Existe um campo em branco!");
            }
            else
            {
                var strConexao = "server=localhost;uid=root;pwd=439360;database=db_fazenda_urbana";

                var telCelFormClien = txtbTelCelFormClien.Text;
                var nomeFormClien = txtbNomeFormClien.Text;
                var rSocialFormClien = txtbRSocialFormClien.Text;
                var cepFormClien = txtbCEPFormClien.Text;
                var ufFormClien = txtbUFFormClien.Text;
                var municFormClien = txtbMunicFormClien.Text;
                var bairroFormClien = txtbBairroFormClien.Text;
                var ruaFormClien = txtbRuaFormClien.Text;
                var numFormClien = txtbNumFormClien.Text;
                var emailFormClien = txtbEmailFormClien.Text;
                var telFixoFormClien = txtbTelFixoFormClien.Text;
                var cnpjFormClien = txtbCNPJFormClien.Text;
                var Usuario = txtbUsuarios.Text;
                var senha = txtbSenha.Text;

                using (var conexao = new MySqlConnection(strConexao))
                {
                    try
                    {
                        conexao.Open();
                        var comando = new MySqlCommand("INSERT INTO cliente (CNPJ, Razão_social, Nome, UF, Numero, Municipio, Bairro, Rua, CEP, Telefone_1, Telefone_2, E_mail, Usuario, Senha) VALUES (@CNPJ, @Razão_social, @Nome, @UF, @Numero, @Municipio, @Bairro, @Rua, @CEP, @Telefone_1, @Telefone_2, @E_mail, @Usuario, @Senha)", conexao);
                        comando.Parameters.AddWithValue("@CNPJ", cnpjFormClien);
                        comando.Parameters.AddWithValue("@Razão_social", rSocialFormClien);
                        comando.Parameters.AddWithValue("@Nome", nomeFormClien);
                        comando.Parameters.AddWithValue("@UF", ufFormClien);
                        comando.Parameters.AddWithValue("@Numero", numFormClien);
                        comando.Parameters.AddWithValue("@Municipio", municFormClien);
                        comando.Parameters.AddWithValue("@Bairro", bairroFormClien);
                        comando.Parameters.AddWithValue("@Rua", ruaFormClien);
                        comando.Parameters.AddWithValue("@CEP", cepFormClien);
                        comando.Parameters.AddWithValue("@Telefone_1", telCelFormClien);
                        comando.Parameters.AddWithValue("@Telefone_2", telFixoFormClien);
                        comando.Parameters.AddWithValue("@E_mail", emailFormClien);
                        comando.Parameters.AddWithValue("@Usuario", Usuario);
                        comando.Parameters.AddWithValue("@Senha", senha);

                        comando.ExecuteNonQuery();
                        MessageBox.Show("Cadastro realizado com sucesso!");

                        Tela2_Usuarios tela2_Usuarios = new Tela2_Usuarios();
                        tela2_Usuarios.Show();
                        this.Hide();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message);
                    }
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox19_TextChanged(object sender, EventArgs e)
        {

        }

        private void Formulario_Cliente_Load(object sender, EventArgs e)
        {

        }
    }
}
