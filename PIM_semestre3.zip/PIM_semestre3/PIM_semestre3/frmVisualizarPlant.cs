﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMTESTE_
{
    public partial class frmVisualizarPlant : Form
    {
        public frmVisualizarPlant()
        {
            InitializeComponent();
            //executar a query
            //Dbconnection db = new Dbconnection();
            //string[] valores = db.bdSelect("Tipo_cultivo,Qtd_sacos_semente,Qtd_sacos_adubo,Tipo_plantio", "Plantacao","ORDER BY ID_plantacao_PK DESC LIMIT 1");

            //conexao com o bd
            BdPlantacaoSelect db = new BdPlantacaoSelect();

            // Seleção
            string[] resultados = db.Select();
            this.txtbTipoPlantVisuaPlant.Text = resultados[4];
            this.txtbSacoSemenVisuaPlant.Text = resultados[2];
            this.txtbSacoAduboVisuaPlant.Text = resultados[3];
            this.txtbTipoCultVisuaPlant.Text = resultados[1];



        }

        private void frmVisualizarPlant_Load(object sender, EventArgs e)
        {

        }
    }
}
