﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMTESTE_
{
    public partial class frmRelatPlants : Form
    {
        public frmRelatPlants()
        {
            InitializeComponent();
        }

        private void lblRelatorios_Click(object sender, EventArgs e)
        {

        }

        private void btnGerarRelatPlants_Click(object sender, EventArgs e)
        {
            //fazer as querys
            //popular as tabelas
            //mostrar menssagem ao popular as tabelas
            MessageBox.Show("Dados atualizados");
        }
    }
}
