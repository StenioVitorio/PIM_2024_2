﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMTESTE_
{
    public partial class frmOpcoesFuturas : Form
    {
        public frmOpcoesFuturas()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblFazerRelat_Click(object sender, EventArgs e)
        {

        }

        private void btnEnviarFutPlantios_Click(object sender, EventArgs e)
        {
            //Checando se os campos estão vazios ou não
            if (txtbEstacaoFutPlantios.Text == string.Empty)
            {
                MessageBox.Show("O Campo 'Estação' está em branco!");
                txtbPlanRecomFutPlantios.Text = string.Empty;
            }
            else if (txtbRegiaoFutPlantios.Text == string.Empty)
            {
                MessageBox.Show("O campo 'Região' está em branco");
                txtbPlanRecomFutPlantios.Text = string.Empty;
            }

            //Inverno
            if (txtbEstacaoFutPlantios.Text == "Inverno" && txtbRegiaoFutPlantios.Text == "Sudeste")
            {
                txtbPlanRecomFutPlantios.Text = "Trigo, feijão, sorgo e cambe";
            }
            else if (txtbEstacaoFutPlantios.Text == "Inverno" && txtbRegiaoFutPlantios.Text == "Sul")
            {
                txtbPlanRecomFutPlantios.Text = "Trigo, aveia, centeio e milho";
            }
            else if (txtbEstacaoFutPlantios.Text == "Inverno" && txtbRegiaoFutPlantios.Text == "Norte")
            {
                txtbPlanRecomFutPlantios.Text = "Melancia, morango, cenoura e melão";
            }
            else if (txtbEstacaoFutPlantios.Text == "Inverno" && txtbRegiaoFutPlantios.Text == "Nordeste")
            {
                txtbPlanRecomFutPlantios.Text = "Abóbora, espinafre, alface e cenoura";
            }
            else if (txtbEstacaoFutPlantios.Text == "Inverno" && txtbRegiaoFutPlantios.Text == "Centro Oeste")
            {
                txtbPlanRecomFutPlantios.Text = "Aveia, feijão e sorgo";
            }

            //Verão
            else if (txtbEstacaoFutPlantios.Text == "Verão" && txtbRegiaoFutPlantios.Text == "Sudeste")
            {
                txtbPlanRecomFutPlantios.Text = "Pimentas, alface, berinjela e nabo";
            }
            else if (txtbEstacaoFutPlantios.Text == "Verão" && txtbRegiaoFutPlantios.Text == "Sul")
            {
                txtbPlanRecomFutPlantios.Text = "Beterraba, couve-manteiga, agrião e coentro";
            }
            else if (txtbEstacaoFutPlantios.Text == "Verão" && txtbRegiaoFutPlantios.Text == "Norte")
            {
                txtbPlanRecomFutPlantios.Text = "Melância, cebolas, alface e pimentas";
            }
            else if (txtbEstacaoFutPlantios.Text == "Verão" && txtbRegiaoFutPlantios.Text == "Nordeste")
            {
                txtbPlanRecomFutPlantios.Text = "Feijão-vagem, couve-flor e melão";
            }
            else if (txtbEstacaoFutPlantios.Text == "Verão" && txtbRegiaoFutPlantios.Text == "Centro Oeste")
            {
                txtbPlanRecomFutPlantios.Text = "Cenoura, abobrinha, tomate e pimentão";
            }

            //Primavera
            else if (txtbEstacaoFutPlantios.Text == "Primavera" && txtbRegiaoFutPlantios.Text == "Sudeste")
            {
                txtbPlanRecomFutPlantios.Text = "Salsa, espinafre, jiló, melância e melão";
            }
            else if (txtbEstacaoFutPlantios.Text == "Primavera" && txtbRegiaoFutPlantios.Text == "Sul")
            {
                txtbPlanRecomFutPlantios.Text = "Cenoura, pimenta, abóbora e berinjela";
            }
            else if (txtbEstacaoFutPlantios.Text == "Primavera" && txtbRegiaoFutPlantios.Text == "Norte")
            {
                txtbPlanRecomFutPlantios.Text = "Vagem, feijão, jiló, coentro e melância";
            }
            else if (txtbEstacaoFutPlantios.Text == "Primavera" && txtbRegiaoFutPlantios.Text == "Nordeste")
            {
                txtbPlanRecomFutPlantios.Text = "Cenoura, pepino, abóbora e tomate";
            }
            else if (txtbEstacaoFutPlantios.Text == "Primavera" && txtbRegiaoFutPlantios.Text == "Centro Oeste")
            {
                txtbPlanRecomFutPlantios.Text = "Vagem, feijão, jiló, coentro e melância";
            }

            //Outono
            else if (txtbEstacaoFutPlantios.Text == "Outono" && txtbRegiaoFutPlantios.Text == "Sudeste")
            {
                txtbPlanRecomFutPlantios.Text = "Rúcula, alface, beterraba e espinafre";
            }
            else if (txtbEstacaoFutPlantios.Text == "Outono" && txtbRegiaoFutPlantios.Text == "Sul")
            {
                txtbPlanRecomFutPlantios.Text = "Cebola, rúcula, salsa e alface";
            }
            else if (txtbEstacaoFutPlantios.Text == "Outono" && txtbRegiaoFutPlantios.Text == "Norte")
            {
                txtbPlanRecomFutPlantios.Text = "Abobrinha, tomate, pepino, e rabanete";
            }
            else if (txtbEstacaoFutPlantios.Text == "Outono" && txtbRegiaoFutPlantios.Text == "Nordeste")
            {
                txtbPlanRecomFutPlantios.Text = "Abobrinha, berinjela, jiló e pimentões";
            }
            else if (txtbEstacaoFutPlantios.Text == "Outono" && txtbRegiaoFutPlantios.Text == "Centro Oeste")
            {
                txtbPlanRecomFutPlantios.Text = "Ervilha, nabo, espinafre e tomate";
            }

            //Instruções
            else if (txtbEstacaoFutPlantios.Text != string.Empty && txtbEstacaoFutPlantios.Text != "Verão" 
                && txtbEstacaoFutPlantios.Text != "Primavera" && txtbEstacaoFutPlantios.Text != "Outono"
                && txtbEstacaoFutPlantios.Text != "Inverno")
            {
                txtbPlanRecomFutPlantios.Text = string.Empty;
                MessageBox.Show("Tente:\nNo campo 'Estação', insira uma das seguintes opções:\nPrimavera,\nVerão,\nOutono,\nou Inverno ");
            }
            else if (txtbRegiaoFutPlantios.Text != string.Empty && txtbRegiaoFutPlantios.Text != "Norte"
                && txtbRegiaoFutPlantios.Text != "Nordeste" && txtbRegiaoFutPlantios.Text != "Centro Oeste"
                && txtbRegiaoFutPlantios.Text != "Sul" && txtbRegiaoFutPlantios.Text != "Sudeste")
            {
                txtbPlanRecomFutPlantios.Text = string.Empty;
                MessageBox.Show("Tente:\nNo campo 'Região', insira uma das seguintes opções:\nSul,\nSudeste,\nCentro Oeste,\nNorte\nou Nordeste");
            }
        }

        private void txtbEstacaoFutPlantios_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
