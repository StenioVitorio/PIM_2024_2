﻿namespace PIMTESTE_
{
    partial class frmCriarPlant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblCriarPlant = new Label();
            flowLayoutPanel1 = new FlowLayoutPanel();
            txtbTipoCultCriarPlant = new TextBox();
            txtbSacoSemenCriarPlant = new TextBox();
            txtbSacoAduboCriarPlant = new TextBox();
            txtbTipoPlantCriarPlant = new TextBox();
            btnSalvarCriarPlant = new Button();
            lblPcamposCriarPlant = new Label();
            flowLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // lblCriarPlant
            // 
            lblCriarPlant.AutoSize = true;
            lblCriarPlant.Dock = DockStyle.Top;
            lblCriarPlant.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCriarPlant.ForeColor = Color.FromArgb(75, 82, 51);
            lblCriarPlant.Location = new Point(0, 0);
            lblCriarPlant.Name = "lblCriarPlant";
            lblCriarPlant.Size = new Size(290, 51);
            lblCriarPlant.TabIndex = 1;
            lblCriarPlant.Text = "Criar Plantação";
            lblCriarPlant.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Controls.Add(txtbTipoCultCriarPlant);
            flowLayoutPanel1.Controls.Add(txtbSacoSemenCriarPlant);
            flowLayoutPanel1.Controls.Add(txtbSacoAduboCriarPlant);
            flowLayoutPanel1.Controls.Add(txtbTipoPlantCriarPlant);
            flowLayoutPanel1.Location = new Point(65, 127);
            flowLayoutPanel1.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(453, 170);
            flowLayoutPanel1.TabIndex = 56;
            // 
            // txtbTipoCultCriarPlant
            // 
            txtbTipoCultCriarPlant.BackColor = SystemColors.Window;
            txtbTipoCultCriarPlant.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbTipoCultCriarPlant.ForeColor = SystemColors.WindowText;
            txtbTipoCultCriarPlant.Location = new Point(3, 3);
            txtbTipoCultCriarPlant.Name = "txtbTipoCultCriarPlant";
            txtbTipoCultCriarPlant.PlaceholderText = " Tipo de cultivo*";
            txtbTipoCultCriarPlant.Size = new Size(447, 36);
            txtbTipoCultCriarPlant.TabIndex = 10;
            // 
            // txtbSacoSemenCriarPlant
            // 
            txtbSacoSemenCriarPlant.BackColor = SystemColors.Window;
            txtbSacoSemenCriarPlant.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbSacoSemenCriarPlant.ForeColor = SystemColors.WindowText;
            txtbSacoSemenCriarPlant.Location = new Point(3, 45);
            txtbSacoSemenCriarPlant.Name = "txtbSacoSemenCriarPlant";
            txtbSacoSemenCriarPlant.PlaceholderText = " Saco de sementes*";
            txtbSacoSemenCriarPlant.Size = new Size(447, 36);
            txtbSacoSemenCriarPlant.TabIndex = 11;
            // 
            // txtbSacoAduboCriarPlant
            // 
            txtbSacoAduboCriarPlant.BackColor = SystemColors.Window;
            txtbSacoAduboCriarPlant.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbSacoAduboCriarPlant.ForeColor = SystemColors.WindowText;
            txtbSacoAduboCriarPlant.Location = new Point(3, 87);
            txtbSacoAduboCriarPlant.Name = "txtbSacoAduboCriarPlant";
            txtbSacoAduboCriarPlant.PlaceholderText = " Saco de adubo*";
            txtbSacoAduboCriarPlant.Size = new Size(447, 36);
            txtbSacoAduboCriarPlant.TabIndex = 12;
            // 
            // txtbTipoPlantCriarPlant
            // 
            txtbTipoPlantCriarPlant.BackColor = SystemColors.Window;
            txtbTipoPlantCriarPlant.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbTipoPlantCriarPlant.ForeColor = SystemColors.WindowText;
            txtbTipoPlantCriarPlant.Location = new Point(3, 129);
            txtbTipoPlantCriarPlant.Name = "txtbTipoPlantCriarPlant";
            txtbTipoPlantCriarPlant.PlaceholderText = " Tipo de plantio*";
            txtbTipoPlantCriarPlant.Size = new Size(447, 36);
            txtbTipoPlantCriarPlant.TabIndex = 13;
            // 
            // btnSalvarCriarPlant
            // 
            btnSalvarCriarPlant.BackColor = Color.YellowGreen;
            btnSalvarCriarPlant.FlatAppearance.BorderSize = 0;
            btnSalvarCriarPlant.FlatStyle = FlatStyle.Flat;
            btnSalvarCriarPlant.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnSalvarCriarPlant.ForeColor = Color.FromArgb(57, 62, 40);
            btnSalvarCriarPlant.Location = new Point(403, 350);
            btnSalvarCriarPlant.Name = "btnSalvarCriarPlant";
            btnSalvarCriarPlant.Size = new Size(115, 34);
            btnSalvarCriarPlant.TabIndex = 57;
            btnSalvarCriarPlant.Text = "Salvar";
            btnSalvarCriarPlant.UseVisualStyleBackColor = false;
            btnSalvarCriarPlant.Click += btnSalvarCriarPlant_Click;
            // 
            // lblPcamposCriarPlant
            // 
            lblPcamposCriarPlant.AutoSize = true;
            lblPcamposCriarPlant.BackColor = Color.Transparent;
            lblPcamposCriarPlant.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPcamposCriarPlant.ForeColor = SystemColors.WindowText;
            lblPcamposCriarPlant.Location = new Point(67, 96);
            lblPcamposCriarPlant.Name = "lblPcamposCriarPlant";
            lblPcamposCriarPlant.Size = new Size(211, 30);
            lblPcamposCriarPlant.TabIndex = 58;
            lblPcamposCriarPlant.Text = "Preencha os campos";
            // 
            // frmCriarPlant
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(238, 241, 212);
            ClientSize = new Size(584, 406);
            Controls.Add(lblPcamposCriarPlant);
            Controls.Add(btnSalvarCriarPlant);
            Controls.Add(flowLayoutPanel1);
            Controls.Add(lblCriarPlant);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmCriarPlant";
            Text = "frmAdicionarPlant";
            flowLayoutPanel1.ResumeLayout(false);
            flowLayoutPanel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblCriarPlant;
        private FlowLayoutPanel flowLayoutPanel1;
        private TextBox txtbTipoCultCriarPlant;
        private TextBox txtbSacoSemenCriarPlant;
        private TextBox txtbSacoAduboCriarPlant;
        private TextBox txtbTipoPlantCriarPlant;
        private Button btnSalvarCriarPlant;
        private Label lblPcamposCriarPlant;
    }
}