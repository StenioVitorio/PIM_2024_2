﻿namespace PIMTESTE_
{
    partial class frmOpcoesFuturas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblFutPlantios = new Label();
            txtbPlanRecomFutPlantios = new TextBox();
            txtbRegiaoFutPlantios = new TextBox();
            txtbEstacaoFutPlantios = new TextBox();
            btnEnviarFutPlantios = new Button();
            flowLayoutPanel1 = new FlowLayoutPanel();
            flowLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // lblFutPlantios
            // 
            lblFutPlantios.AutoSize = true;
            lblFutPlantios.Dock = DockStyle.Top;
            lblFutPlantios.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblFutPlantios.ForeColor = Color.FromArgb(57, 62, 40);
            lblFutPlantios.Location = new Point(0, 0);
            lblFutPlantios.Name = "lblFutPlantios";
            lblFutPlantios.Size = new Size(311, 51);
            lblFutPlantios.TabIndex = 1;
            lblFutPlantios.Text = "Futuros Plantios";
            lblFutPlantios.TextAlign = ContentAlignment.MiddleCenter;
            lblFutPlantios.Click += lblFazerRelat_Click;
            // 
            // txtbPlanRecomFutPlantios
            // 
            txtbPlanRecomFutPlantios.BackColor = SystemColors.Window;
            flowLayoutPanel1.SetFlowBreak(txtbPlanRecomFutPlantios, true);
            txtbPlanRecomFutPlantios.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbPlanRecomFutPlantios.ForeColor = SystemColors.WindowText;
            txtbPlanRecomFutPlantios.Location = new Point(3, 87);
            txtbPlanRecomFutPlantios.Name = "txtbPlanRecomFutPlantios";
            txtbPlanRecomFutPlantios.PlaceholderText = "Plantas recomendadas";
            txtbPlanRecomFutPlantios.ReadOnly = true;
            txtbPlanRecomFutPlantios.Size = new Size(447, 36);
            txtbPlanRecomFutPlantios.TabIndex = 12;
            // 
            // txtbRegiaoFutPlantios
            // 
            txtbRegiaoFutPlantios.BackColor = SystemColors.Window;
            txtbRegiaoFutPlantios.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbRegiaoFutPlantios.ForeColor = SystemColors.WindowText;
            txtbRegiaoFutPlantios.Location = new Point(3, 45);
            txtbRegiaoFutPlantios.Name = "txtbRegiaoFutPlantios";
            txtbRegiaoFutPlantios.PlaceholderText = "Região*";
            txtbRegiaoFutPlantios.Size = new Size(447, 36);
            txtbRegiaoFutPlantios.TabIndex = 11;
            // 
            // txtbEstacaoFutPlantios
            // 
            txtbEstacaoFutPlantios.BackColor = SystemColors.Window;
            txtbEstacaoFutPlantios.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbEstacaoFutPlantios.ForeColor = SystemColors.WindowText;
            txtbEstacaoFutPlantios.Location = new Point(3, 3);
            txtbEstacaoFutPlantios.Name = "txtbEstacaoFutPlantios";
            txtbEstacaoFutPlantios.PlaceholderText = "Estação*";
            txtbEstacaoFutPlantios.Size = new Size(447, 36);
            txtbEstacaoFutPlantios.TabIndex = 10;
            txtbEstacaoFutPlantios.TextChanged += txtbEstacaoFutPlantios_TextChanged;
            // 
            // btnEnviarFutPlantios
            // 
            btnEnviarFutPlantios.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnEnviarFutPlantios.BackColor = Color.YellowGreen;
            btnEnviarFutPlantios.FlatAppearance.BorderSize = 0;
            btnEnviarFutPlantios.FlatStyle = FlatStyle.Flat;
            btnEnviarFutPlantios.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnEnviarFutPlantios.ForeColor = Color.FromArgb(57, 62, 40);
            btnEnviarFutPlantios.Location = new Point(396, 350);
            btnEnviarFutPlantios.Name = "btnEnviarFutPlantios";
            btnEnviarFutPlantios.Size = new Size(115, 34);
            btnEnviarFutPlantios.TabIndex = 53;
            btnEnviarFutPlantios.Text = "Enviar";
            btnEnviarFutPlantios.UseVisualStyleBackColor = false;
            btnEnviarFutPlantios.Click += btnEnviarFutPlantios_Click;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            flowLayoutPanel1.Controls.Add(txtbEstacaoFutPlantios);
            flowLayoutPanel1.Controls.Add(txtbRegiaoFutPlantios);
            flowLayoutPanel1.Controls.Add(txtbPlanRecomFutPlantios);
            flowLayoutPanel1.Location = new Point(57, 127);
            flowLayoutPanel1.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(453, 127);
            flowLayoutPanel1.TabIndex = 54;
            // 
            // frmOpcoesFuturas
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(238, 241, 212);
            ClientSize = new Size(584, 409);
            Controls.Add(flowLayoutPanel1);
            Controls.Add(btnEnviarFutPlantios);
            Controls.Add(lblFutPlantios);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmOpcoesFuturas";
            Text = "frmOpcoesFuturas";
            flowLayoutPanel1.ResumeLayout(false);
            flowLayoutPanel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblFutPlantios;
        private TextBox txtbPlanRecomFutPlantios;
        private TextBox txtbRegiaoFutPlantios;
        private TextBox txtbEstacaoFutPlantios;
        private Button btnEnviarFutPlantios;
        private FlowLayoutPanel flowLayoutPanel1;
    }
}