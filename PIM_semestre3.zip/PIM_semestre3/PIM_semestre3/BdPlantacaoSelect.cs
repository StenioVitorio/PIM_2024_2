﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIMTESTE_
{
    internal class BdPlantacaoSelect
    {
        
        private string stringconexao = $"server=localhost;uid=root;pwd=BDADIMIN123?;database=db_fazenda_urbana";
        
        
        public string[] Select()
        {
            string[] valores = new string[5];
            using (MySqlConnection conn = new MySqlConnection(stringconexao))
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand("SELECT ID_plantacao_PK,Tipo_cultivo, Qtd_sacos_semente,Qtd_sacos_adubo,Tipo_plantio FROM plantacao ORDER BY ID_plantacao_PK DESC LIMIT 1",conn);
                    
                    MySqlDataReader reader = cmd.ExecuteReader();
                    reader.Read();
                    valores[0] = reader.GetInt32(0).ToString();
                    reader.Read();
                    valores[1]=reader.GetString(1);
                    reader.Read();
                    valores[2] = reader.GetInt32(2).ToString();
                    reader.Read();
                    valores[3] = reader.GetInt32(3).ToString();
                    reader.Read();
                    valores[4] = reader.GetString(4);
                    conn.Close();
                    
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    
                }
            }
            return valores;

        }
        public bool Insert(string data_plantio, string tipo_plantio,string Tipo_cultivo,string qtd_sacos_semente,string qtd_sacos_adubo)
        {
            int success = 0;
            using (MySqlConnection conn = new MySqlConnection(stringconexao))
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand("INSERT INTO plantacao (Data_plantio, Tipo_plantio, Tipo_cultivo, Qtd_sacos_semente, Qtd_sacos_adubo) VALUES " +
                        "(@Data_plantio, @Tipo_plantio, @Tipo_cultivo, @Qtd_sacos_semente, @Qtd_sacos_adubo)", conn);
                    cmd.Parameters.AddWithValue("@Data_plantio", data_plantio);
                    cmd.Parameters.AddWithValue("@Tipo_plantio",tipo_plantio);
                    cmd.Parameters.AddWithValue("@Tipo_cultivo", Tipo_cultivo) ;
                    cmd.Parameters.AddWithValue("@Qtd_sacos_semente", int.Parse(qtd_sacos_semente));
                    cmd.Parameters.AddWithValue("@Qtd_sacos_adubo", int.Parse(qtd_sacos_adubo));
                    

                    success = cmd.ExecuteNonQuery();
                    conn.Close();
                    return success > 0;


                }
                catch (Exception ex)
                {
                    return false;
                    Console.WriteLine(ex.Message);

                }

            }


        }

        public bool Update(int index,  string data_plantio, string tipo_plantio, string Tipo_cultivo, string qtd_sacos_semente, string qtd_sacos_adubo)
        {
            int success = 0;
            using (MySqlConnection conn = new MySqlConnection(stringconexao))
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand("UPDATE plantacao SET Data_plantio= @Data_plantio, Tipo_plantio=@Tipo_plantio, Tipo_cultivo=@Tipo_cultivo, Qtd_sacos_semente=@Qtd_sacos_semente, Qtd_sacos_adubo=@Qtd_sacos_adubo WHERE Id_plantacao_PK="+index, conn);
                    cmd.Parameters.AddWithValue("@Data_plantio", data_plantio);
                    cmd.Parameters.AddWithValue("@Tipo_plantio", tipo_plantio);
                    cmd.Parameters.AddWithValue("@Tipo_cultivo", Tipo_cultivo);
                    cmd.Parameters.AddWithValue("@Qtd_sacos_semente", int.Parse(qtd_sacos_semente));
                    cmd.Parameters.AddWithValue("@Qtd_sacos_adubo", int.Parse(qtd_sacos_adubo));


                    success = cmd.ExecuteNonQuery();
                    conn.Close();
                    return success > 0;


                }
                catch (Exception ex)
                {
                    return false;
                    Console.WriteLine(ex.Message);

                }

            }


        }





    }
}
