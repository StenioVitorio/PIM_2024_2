﻿namespace PIMTESTE_
{
    partial class frmAlterarPlant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblAlterarPlant = new Label();
            flowLayoutPanel1 = new FlowLayoutPanel();
            txtbTipoCultAlterarPlant = new TextBox();
            txtbSacoSemenAlterarPlant = new TextBox();
            txtbSacoAduboAlterarPlant = new TextBox();
            txtbTipoPlantAlterarPlant = new TextBox();
            btnAlterarAlterarPlant = new Button();
            lblPcamposAlterarPlant = new Label();
            flowLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // lblAlterarPlant
            // 
            lblAlterarPlant.AutoSize = true;
            lblAlterarPlant.BackColor = Color.Transparent;
            lblAlterarPlant.Dock = DockStyle.Top;
            lblAlterarPlant.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAlterarPlant.ForeColor = Color.FromArgb(75, 82, 51);
            lblAlterarPlant.Location = new Point(0, 0);
            lblAlterarPlant.Name = "lblAlterarPlant";
            lblAlterarPlant.Size = new Size(347, 51);
            lblAlterarPlant.TabIndex = 2;
            lblAlterarPlant.Text = "Alterar Plantações";
            lblAlterarPlant.TextAlign = ContentAlignment.MiddleCenter;
            lblAlterarPlant.Click += lblAlterarPlant_Click;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Controls.Add(txtbTipoCultAlterarPlant);
            flowLayoutPanel1.Controls.Add(txtbSacoSemenAlterarPlant);
            flowLayoutPanel1.Controls.Add(txtbSacoAduboAlterarPlant);
            flowLayoutPanel1.Controls.Add(txtbTipoPlantAlterarPlant);
            flowLayoutPanel1.Location = new Point(54, 134);
            flowLayoutPanel1.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(453, 170);
            flowLayoutPanel1.TabIndex = 55;
            // 
            // txtbTipoCultAlterarPlant
            // 
            txtbTipoCultAlterarPlant.BackColor = SystemColors.Window;
            txtbTipoCultAlterarPlant.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbTipoCultAlterarPlant.ForeColor = SystemColors.WindowText;
            txtbTipoCultAlterarPlant.Location = new Point(3, 3);
            txtbTipoCultAlterarPlant.Name = "txtbTipoCultAlterarPlant";
            txtbTipoCultAlterarPlant.PlaceholderText = " Tipo de cultivo*";
            txtbTipoCultAlterarPlant.Size = new Size(447, 36);
            txtbTipoCultAlterarPlant.TabIndex = 10;
            // 
            // txtbSacoSemenAlterarPlant
            // 
            txtbSacoSemenAlterarPlant.BackColor = SystemColors.Window;
            txtbSacoSemenAlterarPlant.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbSacoSemenAlterarPlant.ForeColor = SystemColors.WindowText;
            txtbSacoSemenAlterarPlant.Location = new Point(3, 45);
            txtbSacoSemenAlterarPlant.Name = "txtbSacoSemenAlterarPlant";
            txtbSacoSemenAlterarPlant.PlaceholderText = " Saco de sementes*";
            txtbSacoSemenAlterarPlant.Size = new Size(447, 36);
            txtbSacoSemenAlterarPlant.TabIndex = 11;
            // 
            // txtbSacoAduboAlterarPlant
            // 
            txtbSacoAduboAlterarPlant.BackColor = SystemColors.Window;
            txtbSacoAduboAlterarPlant.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbSacoAduboAlterarPlant.ForeColor = SystemColors.WindowText;
            txtbSacoAduboAlterarPlant.Location = new Point(3, 87);
            txtbSacoAduboAlterarPlant.Name = "txtbSacoAduboAlterarPlant";
            txtbSacoAduboAlterarPlant.PlaceholderText = " Saco de adubo*";
            txtbSacoAduboAlterarPlant.Size = new Size(447, 36);
            txtbSacoAduboAlterarPlant.TabIndex = 12;
            // 
            // txtbTipoPlantAlterarPlant
            // 
            txtbTipoPlantAlterarPlant.BackColor = SystemColors.Window;
            txtbTipoPlantAlterarPlant.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbTipoPlantAlterarPlant.ForeColor = SystemColors.WindowText;
            txtbTipoPlantAlterarPlant.Location = new Point(3, 129);
            txtbTipoPlantAlterarPlant.Name = "txtbTipoPlantAlterarPlant";
            txtbTipoPlantAlterarPlant.PlaceholderText = " Tipo de plantio*";
            txtbTipoPlantAlterarPlant.Size = new Size(447, 36);
            txtbTipoPlantAlterarPlant.TabIndex = 13;
            // 
            // btnAlterarAlterarPlant
            // 
            btnAlterarAlterarPlant.BackColor = Color.YellowGreen;
            btnAlterarAlterarPlant.FlatAppearance.BorderSize = 0;
            btnAlterarAlterarPlant.FlatStyle = FlatStyle.Flat;
            btnAlterarAlterarPlant.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnAlterarAlterarPlant.ForeColor = Color.FromArgb(57, 62, 40);
            btnAlterarAlterarPlant.Location = new Point(393, 351);
            btnAlterarAlterarPlant.Name = "btnAlterarAlterarPlant";
            btnAlterarAlterarPlant.Size = new Size(115, 34);
            btnAlterarAlterarPlant.TabIndex = 56;
            btnAlterarAlterarPlant.Text = "Alterar";
            btnAlterarAlterarPlant.UseVisualStyleBackColor = false;
            btnAlterarAlterarPlant.Click += btnAlterarAlterarPlant_Click;
            // 
            // lblPcamposAlterarPlant
            // 
            lblPcamposAlterarPlant.AutoSize = true;
            lblPcamposAlterarPlant.BackColor = Color.Transparent;
            lblPcamposAlterarPlant.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPcamposAlterarPlant.ForeColor = SystemColors.WindowText;
            lblPcamposAlterarPlant.Location = new Point(54, 103);
            lblPcamposAlterarPlant.Name = "lblPcamposAlterarPlant";
            lblPcamposAlterarPlant.Size = new Size(211, 30);
            lblPcamposAlterarPlant.TabIndex = 57;
            lblPcamposAlterarPlant.Text = "Preencha os campos";
            // 
            // frmAlterarPlant
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(238, 241, 212);
            ClientSize = new Size(584, 406);
            Controls.Add(lblPcamposAlterarPlant);
            Controls.Add(btnAlterarAlterarPlant);
            Controls.Add(flowLayoutPanel1);
            Controls.Add(lblAlterarPlant);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmAlterarPlant";
            Text = "frmAlterarPlant";
            Load += frmAlterarPlant_Load;
            flowLayoutPanel1.ResumeLayout(false);
            flowLayoutPanel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblAlterarPlant;
        private FlowLayoutPanel flowLayoutPanel1;
        private TextBox txtbTipoCultAlterarPlant;
        private TextBox txtbSacoSemenAlterarPlant;
        private TextBox txtbSacoAduboAlterarPlant;
        private TextBox txtbTipoPlantAlterarPlant;
        private Button btnAlterarAlterarPlant;
        private Label lblPcamposAlterarPlant;
    }
}