﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMTESTE_
{
    public partial class frmRelatEstoqs : Form
    {
        public frmRelatEstoqs()
        {
            InitializeComponent();
        }

        private void lblOpcoesFuturosPlantios_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnGerarRelatEstoqs_Click(object sender, EventArgs e)
        {
            var strConexao = "server=localhost;uid=root;pwd=BDADIMIN123?;database=db_fazenda_urbana";
            using (var conexao = new MySqlConnection(strConexao))
            {
                try
                {
                    conexao.Open();
                    string query = "SELECT ID_insumo_PK, Quantidade_insumo, Nome_insumo FROM insumo"; // Ajuste a consulta conforme necessário

                    MySqlDataAdapter adapter = new MySqlDataAdapter(query, conexao);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgvInsumoRelatEstoqs.DataSource = dataTable;

                    conexao.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                try
                {
                    conexao.Open();
                    string query = "SELECT ID_produto_PK, Quantidade_produto, Nome_produto FROM produto"; // Ajuste a consulta conforme necessário

                    MySqlDataAdapter adapter = new MySqlDataAdapter(query, conexao);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgvProdutoRelatEstoqs.DataSource = dataTable;

                    conexao.Close();
                    MessageBox.Show("Dados atualizados");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
    }
}
