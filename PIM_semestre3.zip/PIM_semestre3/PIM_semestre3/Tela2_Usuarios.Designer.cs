﻿namespace PIMTESTE_
{
    partial class Tela2_Usuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tela2_Usuarios));
            ptbFundoTela2Usuarios = new PictureBox();
            panAcessTela2Usuarios = new Panel();
            btnVoltarTela2Usuarios = new Button();
            btnAcessTela2Usuarios = new Button();
            btnEsqSenhaTela2Usuarios = new Button();
            lblSenhaTela2Usuarios = new Label();
            btnCriarContaTela2Usuarios = new Button();
            lblEmailTela2Usuarios = new Label();
            lblAcessTela2Usuarios = new Label();
            txtbSenhaTela2Usuarios = new TextBox();
            txtbEmailTela2Usuarios = new TextBox();
            panTela2Usuarios = new Panel();
            flowLayoutPanel13 = new FlowLayoutPanel();
            ptbStartuTela2Usuarios = new PictureBox();
            lblStartuTela2Usuarios = new Label();
            ((System.ComponentModel.ISupportInitialize)ptbFundoTela2Usuarios).BeginInit();
            panAcessTela2Usuarios.SuspendLayout();
            panTela2Usuarios.SuspendLayout();
            flowLayoutPanel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbStartuTela2Usuarios).BeginInit();
            SuspendLayout();
            // 
            // ptbFundoTela2Usuarios
            // 
            ptbFundoTela2Usuarios.BackColor = SystemColors.Control;
            ptbFundoTela2Usuarios.Image = (Image)resources.GetObject("ptbFundoTela2Usuarios.Image");
            ptbFundoTela2Usuarios.Location = new Point(-1, 1);
            ptbFundoTela2Usuarios.Name = "ptbFundoTela2Usuarios";
            ptbFundoTela2Usuarios.Size = new Size(802, 450);
            ptbFundoTela2Usuarios.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbFundoTela2Usuarios.TabIndex = 0;
            ptbFundoTela2Usuarios.TabStop = false;
            // 
            // panAcessTela2Usuarios
            // 
            panAcessTela2Usuarios.BackColor = Color.FromArgb(255, 255, 192);
            panAcessTela2Usuarios.Controls.Add(btnVoltarTela2Usuarios);
            panAcessTela2Usuarios.Controls.Add(btnAcessTela2Usuarios);
            panAcessTela2Usuarios.Controls.Add(btnEsqSenhaTela2Usuarios);
            panAcessTela2Usuarios.Controls.Add(lblSenhaTela2Usuarios);
            panAcessTela2Usuarios.Controls.Add(btnCriarContaTela2Usuarios);
            panAcessTela2Usuarios.Controls.Add(lblEmailTela2Usuarios);
            panAcessTela2Usuarios.Controls.Add(lblAcessTela2Usuarios);
            panAcessTela2Usuarios.Controls.Add(txtbSenhaTela2Usuarios);
            panAcessTela2Usuarios.Controls.Add(txtbEmailTela2Usuarios);
            panAcessTela2Usuarios.Location = new Point(261, 80);
            panAcessTela2Usuarios.Name = "panAcessTela2Usuarios";
            panAcessTela2Usuarios.Size = new Size(276, 341);
            panAcessTela2Usuarios.TabIndex = 1;
            // 
            // btnVoltarTela2Usuarios
            // 
            btnVoltarTela2Usuarios.BackColor = Color.YellowGreen;
            btnVoltarTela2Usuarios.FlatAppearance.BorderSize = 0;
            btnVoltarTela2Usuarios.FlatStyle = FlatStyle.Flat;
            btnVoltarTela2Usuarios.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnVoltarTela2Usuarios.ForeColor = Color.FromArgb(57, 62, 40);
            btnVoltarTela2Usuarios.Location = new Point(23, 223);
            btnVoltarTela2Usuarios.Name = "btnVoltarTela2Usuarios";
            btnVoltarTela2Usuarios.Size = new Size(102, 34);
            btnVoltarTela2Usuarios.TabIndex = 58;
            btnVoltarTela2Usuarios.Text = "Voltar";
            btnVoltarTela2Usuarios.UseVisualStyleBackColor = false;
            btnVoltarTela2Usuarios.Click += btnVoltarTela2Usuarios_Click_1;
            // 
            // btnAcessTela2Usuarios
            // 
            btnAcessTela2Usuarios.BackColor = Color.YellowGreen;
            btnAcessTela2Usuarios.FlatAppearance.BorderSize = 0;
            btnAcessTela2Usuarios.FlatStyle = FlatStyle.Flat;
            btnAcessTela2Usuarios.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnAcessTela2Usuarios.ForeColor = Color.FromArgb(57, 62, 40);
            btnAcessTela2Usuarios.Location = new Point(147, 223);
            btnAcessTela2Usuarios.Name = "btnAcessTela2Usuarios";
            btnAcessTela2Usuarios.Size = new Size(102, 34);
            btnAcessTela2Usuarios.TabIndex = 57;
            btnAcessTela2Usuarios.Text = "Acessar";
            btnAcessTela2Usuarios.UseVisualStyleBackColor = false;
            btnAcessTela2Usuarios.Click += btnAcessTela2Usuarios_Click_1;
            // 
            // btnEsqSenhaTela2Usuarios
            // 
            btnEsqSenhaTela2Usuarios.BackColor = Color.FromArgb(255, 255, 192);
            btnEsqSenhaTela2Usuarios.FlatAppearance.BorderSize = 0;
            btnEsqSenhaTela2Usuarios.FlatStyle = FlatStyle.Flat;
            btnEsqSenhaTela2Usuarios.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold | FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point, 0);
            btnEsqSenhaTela2Usuarios.ForeColor = Color.Black;
            btnEsqSenhaTela2Usuarios.Location = new Point(44, 175);
            btnEsqSenhaTela2Usuarios.Margin = new Padding(3, 2, 3, 2);
            btnEsqSenhaTela2Usuarios.Name = "btnEsqSenhaTela2Usuarios";
            btnEsqSenhaTela2Usuarios.Size = new Size(184, 29);
            btnEsqSenhaTela2Usuarios.TabIndex = 5;
            btnEsqSenhaTela2Usuarios.Text = "Esqueci a minha senha";
            btnEsqSenhaTela2Usuarios.UseVisualStyleBackColor = false;
            // 
            // lblSenhaTela2Usuarios
            // 
            lblSenhaTela2Usuarios.AutoSize = true;
            lblSenhaTela2Usuarios.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblSenhaTela2Usuarios.Location = new Point(23, 129);
            lblSenhaTela2Usuarios.Name = "lblSenhaTela2Usuarios";
            lblSenhaTela2Usuarios.Size = new Size(99, 19);
            lblSenhaTela2Usuarios.TabIndex = 4;
            lblSenhaTela2Usuarios.Text = "Digite a senha:";
            lblSenhaTela2Usuarios.Click += label3_Click;
            // 
            // btnCriarContaTela2Usuarios
            // 
            btnCriarContaTela2Usuarios.BackColor = Color.FromArgb(126, 211, 109);
            btnCriarContaTela2Usuarios.FlatAppearance.BorderSize = 0;
            btnCriarContaTela2Usuarios.FlatStyle = FlatStyle.Flat;
            btnCriarContaTela2Usuarios.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCriarContaTela2Usuarios.ForeColor = Color.Black;
            btnCriarContaTela2Usuarios.Location = new Point(23, 281);
            btnCriarContaTela2Usuarios.Name = "btnCriarContaTela2Usuarios";
            btnCriarContaTela2Usuarios.Size = new Size(226, 49);
            btnCriarContaTela2Usuarios.TabIndex = 0;
            btnCriarContaTela2Usuarios.Text = "Criar uma nova conta STARTUPYX";
            btnCriarContaTela2Usuarios.UseVisualStyleBackColor = false;
            btnCriarContaTela2Usuarios.Click += btnCriarContaTela2Usuarios_Click_1;
            // 
            // lblEmailTela2Usuarios
            // 
            lblEmailTela2Usuarios.AutoSize = true;
            lblEmailTela2Usuarios.BackColor = Color.Transparent;
            lblEmailTela2Usuarios.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblEmailTela2Usuarios.Location = new Point(23, 79);
            lblEmailTela2Usuarios.Name = "lblEmailTela2Usuarios";
            lblEmailTela2Usuarios.Size = new Size(127, 19);
            lblEmailTela2Usuarios.TabIndex = 2;
            lblEmailTela2Usuarios.Text = "Digite o seu e-mail:";
            lblEmailTela2Usuarios.Click += label2_Click;
            // 
            // lblAcessTela2Usuarios
            // 
            lblAcessTela2Usuarios.AutoSize = true;
            lblAcessTela2Usuarios.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAcessTela2Usuarios.Location = new Point(69, 35);
            lblAcessTela2Usuarios.Name = "lblAcessTela2Usuarios";
            lblAcessTela2Usuarios.Size = new Size(103, 32);
            lblAcessTela2Usuarios.TabIndex = 3;
            lblAcessTela2Usuarios.Text = "ACESSO";
            // 
            // txtbSenhaTela2Usuarios
            // 
            txtbSenhaTela2Usuarios.Location = new Point(23, 149);
            txtbSenhaTela2Usuarios.Name = "txtbSenhaTela2Usuarios";
            txtbSenhaTela2Usuarios.PlaceholderText = "Senha*";
            txtbSenhaTela2Usuarios.Size = new Size(226, 23);
            txtbSenhaTela2Usuarios.TabIndex = 2;
            // 
            // txtbEmailTela2Usuarios
            // 
            txtbEmailTela2Usuarios.Location = new Point(23, 99);
            txtbEmailTela2Usuarios.Name = "txtbEmailTela2Usuarios";
            txtbEmailTela2Usuarios.PlaceholderText = "E-mail*";
            txtbEmailTela2Usuarios.Size = new Size(226, 23);
            txtbEmailTela2Usuarios.TabIndex = 1;
            txtbEmailTela2Usuarios.TextChanged += textBox1_TextChanged;
            // 
            // panTela2Usuarios
            // 
            panTela2Usuarios.BackColor = Color.FromArgb(255, 255, 192);
            panTela2Usuarios.Controls.Add(flowLayoutPanel13);
            panTela2Usuarios.Dock = DockStyle.Top;
            panTela2Usuarios.Location = new Point(0, 0);
            panTela2Usuarios.Name = "panTela2Usuarios";
            panTela2Usuarios.Size = new Size(800, 43);
            panTela2Usuarios.TabIndex = 4;
            // 
            // flowLayoutPanel13
            // 
            flowLayoutPanel13.Controls.Add(ptbStartuTela2Usuarios);
            flowLayoutPanel13.Controls.Add(lblStartuTela2Usuarios);
            flowLayoutPanel13.Location = new Point(281, 0);
            flowLayoutPanel13.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel13.Name = "flowLayoutPanel13";
            flowLayoutPanel13.Size = new Size(214, 38);
            flowLayoutPanel13.TabIndex = 6;
            // 
            // ptbStartuTela2Usuarios
            // 
            ptbStartuTela2Usuarios.Image = (Image)resources.GetObject("ptbStartuTela2Usuarios.Image");
            ptbStartuTela2Usuarios.Location = new Point(3, 2);
            ptbStartuTela2Usuarios.Margin = new Padding(3, 2, 3, 2);
            ptbStartuTela2Usuarios.Name = "ptbStartuTela2Usuarios";
            ptbStartuTela2Usuarios.Size = new Size(36, 32);
            ptbStartuTela2Usuarios.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbStartuTela2Usuarios.TabIndex = 3;
            ptbStartuTela2Usuarios.TabStop = false;
            // 
            // lblStartuTela2Usuarios
            // 
            lblStartuTela2Usuarios.Anchor = AnchorStyles.Top;
            lblStartuTela2Usuarios.AutoSize = true;
            lblStartuTela2Usuarios.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblStartuTela2Usuarios.ForeColor = Color.Black;
            lblStartuTela2Usuarios.Location = new Point(45, 0);
            lblStartuTela2Usuarios.Name = "lblStartuTela2Usuarios";
            lblStartuTela2Usuarios.Size = new Size(149, 32);
            lblStartuTela2Usuarios.TabIndex = 0;
            lblStartuTela2Usuarios.Text = "STARTUPYX";
            lblStartuTela2Usuarios.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Tela2_Usuarios
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(panTela2Usuarios);
            Controls.Add(panAcessTela2Usuarios);
            Controls.Add(ptbFundoTela2Usuarios);
            Name = "Tela2_Usuarios";
            Text = "Login";
            Load += Tela2_Usuarios_Load;
            ((System.ComponentModel.ISupportInitialize)ptbFundoTela2Usuarios).EndInit();
            panAcessTela2Usuarios.ResumeLayout(false);
            panAcessTela2Usuarios.PerformLayout();
            panTela2Usuarios.ResumeLayout(false);
            flowLayoutPanel13.ResumeLayout(false);
            flowLayoutPanel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)ptbStartuTela2Usuarios).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.PictureBox ptbFundoTela2Usuarios;
        private System.Windows.Forms.Panel panAcessTela2Usuarios;
        private System.Windows.Forms.Label lblAcessTela2Usuarios;
        private System.Windows.Forms.TextBox txtbSenhaTela2Usuarios;
        private System.Windows.Forms.TextBox txtbEmailTela2Usuarios;
        private System.Windows.Forms.Button btnCriarContaTela2Usuarios;
        private System.Windows.Forms.Label lblSenhaTela2Usuarios;
        private System.Windows.Forms.Label lblEmailTela2Usuarios;
        private Panel panTela2Usuarios;
        private FlowLayoutPanel flowLayoutPanel13;
        private PictureBox ptbStartuTela2Usuarios;
        private Label lblStartuTela2Usuarios;
        private Button btnEsqSenhaTela2Usuarios;
        private Button btnAcessTela2Usuarios;
        private Button btnVoltarTela2Usuarios;
    }
}