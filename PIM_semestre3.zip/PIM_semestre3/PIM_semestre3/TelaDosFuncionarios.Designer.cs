﻿namespace PIMTESTE_
{
    partial class TelaDosFuncionarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaDosFuncionarios));
            panMenuTelaFuncio = new Panel();
            flowLayoutPanel5 = new FlowLayoutPanel();
            ptbVisuaPlantTelaFuncio = new PictureBox();
            btnVisuaPlantTelaFuncio = new Button();
            flowLayoutPanel6 = new FlowLayoutPanel();
            pictureBox7 = new PictureBox();
            button6 = new Button();
            flowLayoutPanel7 = new FlowLayoutPanel();
            pictureBox8 = new PictureBox();
            button7 = new Button();
            flowLayoutPanel8 = new FlowLayoutPanel();
            pictureBox9 = new PictureBox();
            button8 = new Button();
            flowLayoutPanel2 = new FlowLayoutPanel();
            ptbFazerRelatTelaFuncio = new PictureBox();
            btnFazerRelatTelaFuncio = new Button();
            flowLayoutPanel3 = new FlowLayoutPanel();
            pictureBox4 = new PictureBox();
            button3 = new Button();
            flowLayoutPanel9 = new FlowLayoutPanel();
            ptbAlterarPlantTelaFuncio = new PictureBox();
            btnAlterarPlantTelaFuncio = new Button();
            flowLayoutPanel10 = new FlowLayoutPanel();
            pictureBox11 = new PictureBox();
            button10 = new Button();
            flowLayoutPanel4 = new FlowLayoutPanel();
            ptbCriarPlantTelaFuncio = new PictureBox();
            btnCriarPlantTelaFuncio = new Button();
            flowLayoutPanel1 = new FlowLayoutPanel();
            pictureBox2 = new PictureBox();
            button1 = new Button();
            ptbMenuTelaFuncio = new PictureBox();
            panTelaFuncio = new Panel();
            panStartuTelaFuncio = new Panel();
            flowLayoutPanel13 = new FlowLayoutPanel();
            ptbStartuTelaFuncio = new PictureBox();
            lblStartuTelaFuncio = new Label();
            panMenuTelaFuncio.SuspendLayout();
            flowLayoutPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbVisuaPlantTelaFuncio).BeginInit();
            flowLayoutPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            flowLayoutPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            flowLayoutPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            flowLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbFazerRelatTelaFuncio).BeginInit();
            flowLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            flowLayoutPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbAlterarPlantTelaFuncio).BeginInit();
            flowLayoutPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            flowLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbCriarPlantTelaFuncio).BeginInit();
            flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ptbMenuTelaFuncio).BeginInit();
            panStartuTelaFuncio.SuspendLayout();
            flowLayoutPanel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbStartuTelaFuncio).BeginInit();
            SuspendLayout();
            // 
            // panMenuTelaFuncio
            // 
            panMenuTelaFuncio.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            panMenuTelaFuncio.BackColor = Color.FromArgb(99, 120, 55);
            panMenuTelaFuncio.Controls.Add(flowLayoutPanel5);
            panMenuTelaFuncio.Controls.Add(flowLayoutPanel2);
            panMenuTelaFuncio.Controls.Add(flowLayoutPanel9);
            panMenuTelaFuncio.Controls.Add(flowLayoutPanel4);
            panMenuTelaFuncio.Controls.Add(ptbMenuTelaFuncio);
            panMenuTelaFuncio.Location = new Point(-2, 0);
            panMenuTelaFuncio.Name = "panMenuTelaFuncio";
            panMenuTelaFuncio.Size = new Size(217, 450);
            panMenuTelaFuncio.TabIndex = 0;
            // 
            // flowLayoutPanel5
            // 
            flowLayoutPanel5.Controls.Add(ptbVisuaPlantTelaFuncio);
            flowLayoutPanel5.Controls.Add(btnVisuaPlantTelaFuncio);
            flowLayoutPanel5.Controls.Add(flowLayoutPanel6);
            flowLayoutPanel5.Controls.Add(flowLayoutPanel7);
            flowLayoutPanel5.Location = new Point(2, 350);
            flowLayoutPanel5.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel5.Name = "flowLayoutPanel5";
            flowLayoutPanel5.Size = new Size(214, 50);
            flowLayoutPanel5.TabIndex = 7;
            // 
            // ptbVisuaPlantTelaFuncio
            // 
            ptbVisuaPlantTelaFuncio.Image = (Image)resources.GetObject("ptbVisuaPlantTelaFuncio.Image");
            ptbVisuaPlantTelaFuncio.Location = new Point(3, 2);
            ptbVisuaPlantTelaFuncio.Margin = new Padding(3, 2, 3, 2);
            ptbVisuaPlantTelaFuncio.Name = "ptbVisuaPlantTelaFuncio";
            ptbVisuaPlantTelaFuncio.Size = new Size(44, 44);
            ptbVisuaPlantTelaFuncio.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbVisuaPlantTelaFuncio.TabIndex = 3;
            ptbVisuaPlantTelaFuncio.TabStop = false;
            // 
            // btnVisuaPlantTelaFuncio
            // 
            btnVisuaPlantTelaFuncio.BackColor = Color.FromArgb(99, 120, 55);
            btnVisuaPlantTelaFuncio.FlatAppearance.BorderSize = 0;
            btnVisuaPlantTelaFuncio.FlatAppearance.MouseDownBackColor = Color.YellowGreen;
            btnVisuaPlantTelaFuncio.FlatStyle = FlatStyle.Flat;
            btnVisuaPlantTelaFuncio.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnVisuaPlantTelaFuncio.ForeColor = Color.FromArgb(238, 241, 212);
            btnVisuaPlantTelaFuncio.Location = new Point(53, 3);
            btnVisuaPlantTelaFuncio.Name = "btnVisuaPlantTelaFuncio";
            btnVisuaPlantTelaFuncio.Size = new Size(158, 43);
            btnVisuaPlantTelaFuncio.TabIndex = 4;
            btnVisuaPlantTelaFuncio.Text = "Visualizar Plantações";
            btnVisuaPlantTelaFuncio.UseVisualStyleBackColor = false;
            btnVisuaPlantTelaFuncio.Click += btnVisualizarPlant_Click;
            // 
            // flowLayoutPanel6
            // 
            flowLayoutPanel6.Controls.Add(pictureBox7);
            flowLayoutPanel6.Controls.Add(button6);
            flowLayoutPanel6.Location = new Point(3, 51);
            flowLayoutPanel6.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel6.Name = "flowLayoutPanel6";
            flowLayoutPanel6.Size = new Size(214, 50);
            flowLayoutPanel6.TabIndex = 6;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(3, 2);
            pictureBox7.Margin = new Padding(3, 2, 3, 2);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(44, 44);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 3;
            pictureBox7.TabStop = false;
            // 
            // button6
            // 
            button6.BackColor = Color.FromArgb(99, 120, 55);
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatAppearance.MouseDownBackColor = Color.YellowGreen;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Location = new Point(53, 3);
            button6.Name = "button6";
            button6.RightToLeft = RightToLeft.No;
            button6.Size = new Size(158, 43);
            button6.TabIndex = 1;
            button6.Text = "Criar Plantação";
            button6.UseVisualStyleBackColor = false;
            // 
            // flowLayoutPanel7
            // 
            flowLayoutPanel7.Controls.Add(pictureBox8);
            flowLayoutPanel7.Controls.Add(button7);
            flowLayoutPanel7.Controls.Add(flowLayoutPanel8);
            flowLayoutPanel7.Location = new Point(3, 105);
            flowLayoutPanel7.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel7.Name = "flowLayoutPanel7";
            flowLayoutPanel7.Size = new Size(214, 50);
            flowLayoutPanel7.TabIndex = 7;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(3, 2);
            pictureBox8.Margin = new Padding(3, 2, 3, 2);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(44, 44);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 3;
            pictureBox8.TabStop = false;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(99, 120, 55);
            button7.FlatAppearance.BorderSize = 0;
            button7.FlatAppearance.MouseDownBackColor = Color.YellowGreen;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Location = new Point(53, 3);
            button7.Name = "button7";
            button7.RightToLeft = RightToLeft.No;
            button7.Size = new Size(158, 43);
            button7.TabIndex = 1;
            button7.Text = "Criar Plantação";
            button7.UseVisualStyleBackColor = false;
            // 
            // flowLayoutPanel8
            // 
            flowLayoutPanel8.Controls.Add(pictureBox9);
            flowLayoutPanel8.Controls.Add(button8);
            flowLayoutPanel8.Location = new Point(3, 51);
            flowLayoutPanel8.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel8.Name = "flowLayoutPanel8";
            flowLayoutPanel8.Size = new Size(214, 50);
            flowLayoutPanel8.TabIndex = 6;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(3, 2);
            pictureBox9.Margin = new Padding(3, 2, 3, 2);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(44, 44);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 3;
            pictureBox9.TabStop = false;
            // 
            // button8
            // 
            button8.BackColor = Color.FromArgb(99, 120, 55);
            button8.FlatAppearance.BorderSize = 0;
            button8.FlatAppearance.MouseDownBackColor = Color.YellowGreen;
            button8.FlatStyle = FlatStyle.Flat;
            button8.Location = new Point(53, 3);
            button8.Name = "button8";
            button8.RightToLeft = RightToLeft.No;
            button8.Size = new Size(158, 43);
            button8.TabIndex = 1;
            button8.Text = "Criar Plantação";
            button8.UseVisualStyleBackColor = false;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.Controls.Add(ptbFazerRelatTelaFuncio);
            flowLayoutPanel2.Controls.Add(btnFazerRelatTelaFuncio);
            flowLayoutPanel2.Controls.Add(flowLayoutPanel3);
            flowLayoutPanel2.Location = new Point(2, 296);
            flowLayoutPanel2.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(214, 50);
            flowLayoutPanel2.TabIndex = 7;
            // 
            // ptbFazerRelatTelaFuncio
            // 
            ptbFazerRelatTelaFuncio.Image = (Image)resources.GetObject("ptbFazerRelatTelaFuncio.Image");
            ptbFazerRelatTelaFuncio.Location = new Point(3, 2);
            ptbFazerRelatTelaFuncio.Margin = new Padding(3, 2, 3, 2);
            ptbFazerRelatTelaFuncio.Name = "ptbFazerRelatTelaFuncio";
            ptbFazerRelatTelaFuncio.Size = new Size(44, 44);
            ptbFazerRelatTelaFuncio.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbFazerRelatTelaFuncio.TabIndex = 3;
            ptbFazerRelatTelaFuncio.TabStop = false;
            // 
            // btnFazerRelatTelaFuncio
            // 
            btnFazerRelatTelaFuncio.BackColor = Color.FromArgb(99, 120, 55);
            btnFazerRelatTelaFuncio.FlatAppearance.BorderSize = 0;
            btnFazerRelatTelaFuncio.FlatAppearance.MouseDownBackColor = Color.YellowGreen;
            btnFazerRelatTelaFuncio.FlatStyle = FlatStyle.Flat;
            btnFazerRelatTelaFuncio.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnFazerRelatTelaFuncio.ForeColor = Color.FromArgb(238, 241, 212);
            btnFazerRelatTelaFuncio.Location = new Point(53, 3);
            btnFazerRelatTelaFuncio.Name = "btnFazerRelatTelaFuncio";
            btnFazerRelatTelaFuncio.Size = new Size(158, 43);
            btnFazerRelatTelaFuncio.TabIndex = 3;
            btnFazerRelatTelaFuncio.Text = "Fazer Relatório";
            btnFazerRelatTelaFuncio.UseVisualStyleBackColor = false;
            btnFazerRelatTelaFuncio.Click += btnFazerRelatorio_Click;
            // 
            // flowLayoutPanel3
            // 
            flowLayoutPanel3.Controls.Add(pictureBox4);
            flowLayoutPanel3.Controls.Add(button3);
            flowLayoutPanel3.Location = new Point(3, 51);
            flowLayoutPanel3.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel3.Name = "flowLayoutPanel3";
            flowLayoutPanel3.Size = new Size(214, 50);
            flowLayoutPanel3.TabIndex = 6;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(3, 2);
            pictureBox4.Margin = new Padding(3, 2, 3, 2);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(44, 44);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 3;
            pictureBox4.TabStop = false;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(99, 120, 55);
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.MouseDownBackColor = Color.YellowGreen;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Location = new Point(53, 3);
            button3.Name = "button3";
            button3.RightToLeft = RightToLeft.No;
            button3.Size = new Size(158, 43);
            button3.TabIndex = 1;
            button3.Text = "Criar Plantação";
            button3.UseVisualStyleBackColor = false;
            // 
            // flowLayoutPanel9
            // 
            flowLayoutPanel9.Controls.Add(ptbAlterarPlantTelaFuncio);
            flowLayoutPanel9.Controls.Add(btnAlterarPlantTelaFuncio);
            flowLayoutPanel9.Controls.Add(flowLayoutPanel10);
            flowLayoutPanel9.Location = new Point(3, 242);
            flowLayoutPanel9.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel9.Name = "flowLayoutPanel9";
            flowLayoutPanel9.Size = new Size(214, 50);
            flowLayoutPanel9.TabIndex = 8;
            // 
            // ptbAlterarPlantTelaFuncio
            // 
            ptbAlterarPlantTelaFuncio.Image = (Image)resources.GetObject("ptbAlterarPlantTelaFuncio.Image");
            ptbAlterarPlantTelaFuncio.Location = new Point(3, 2);
            ptbAlterarPlantTelaFuncio.Margin = new Padding(3, 2, 3, 2);
            ptbAlterarPlantTelaFuncio.Name = "ptbAlterarPlantTelaFuncio";
            ptbAlterarPlantTelaFuncio.Size = new Size(44, 44);
            ptbAlterarPlantTelaFuncio.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbAlterarPlantTelaFuncio.TabIndex = 3;
            ptbAlterarPlantTelaFuncio.TabStop = false;
            // 
            // btnAlterarPlantTelaFuncio
            // 
            btnAlterarPlantTelaFuncio.BackColor = Color.FromArgb(99, 120, 55);
            btnAlterarPlantTelaFuncio.FlatAppearance.BorderSize = 0;
            btnAlterarPlantTelaFuncio.FlatAppearance.MouseDownBackColor = Color.YellowGreen;
            btnAlterarPlantTelaFuncio.FlatStyle = FlatStyle.Flat;
            btnAlterarPlantTelaFuncio.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAlterarPlantTelaFuncio.ForeColor = Color.FromArgb(238, 241, 212);
            btnAlterarPlantTelaFuncio.Location = new Point(53, 3);
            btnAlterarPlantTelaFuncio.Name = "btnAlterarPlantTelaFuncio";
            btnAlterarPlantTelaFuncio.Size = new Size(158, 43);
            btnAlterarPlantTelaFuncio.TabIndex = 2;
            btnAlterarPlantTelaFuncio.Text = "Alterar Plantação";
            btnAlterarPlantTelaFuncio.UseVisualStyleBackColor = false;
            btnAlterarPlantTelaFuncio.Click += btnAltPlant_Click;
            // 
            // flowLayoutPanel10
            // 
            flowLayoutPanel10.Controls.Add(pictureBox11);
            flowLayoutPanel10.Controls.Add(button10);
            flowLayoutPanel10.Location = new Point(3, 51);
            flowLayoutPanel10.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel10.Name = "flowLayoutPanel10";
            flowLayoutPanel10.Size = new Size(214, 50);
            flowLayoutPanel10.TabIndex = 6;
            // 
            // pictureBox11
            // 
            pictureBox11.Image = (Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new Point(3, 2);
            pictureBox11.Margin = new Padding(3, 2, 3, 2);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(44, 44);
            pictureBox11.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox11.TabIndex = 3;
            pictureBox11.TabStop = false;
            // 
            // button10
            // 
            button10.BackColor = Color.FromArgb(99, 120, 55);
            button10.FlatAppearance.BorderSize = 0;
            button10.FlatAppearance.MouseDownBackColor = Color.YellowGreen;
            button10.FlatStyle = FlatStyle.Flat;
            button10.Location = new Point(53, 3);
            button10.Name = "button10";
            button10.RightToLeft = RightToLeft.No;
            button10.Size = new Size(158, 43);
            button10.TabIndex = 1;
            button10.Text = "Criar Plantação";
            button10.UseVisualStyleBackColor = false;
            // 
            // flowLayoutPanel4
            // 
            flowLayoutPanel4.Controls.Add(ptbCriarPlantTelaFuncio);
            flowLayoutPanel4.Controls.Add(btnCriarPlantTelaFuncio);
            flowLayoutPanel4.Controls.Add(flowLayoutPanel1);
            flowLayoutPanel4.Location = new Point(3, 188);
            flowLayoutPanel4.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel4.Name = "flowLayoutPanel4";
            flowLayoutPanel4.Size = new Size(214, 50);
            flowLayoutPanel4.TabIndex = 5;
            // 
            // ptbCriarPlantTelaFuncio
            // 
            ptbCriarPlantTelaFuncio.Image = (Image)resources.GetObject("ptbCriarPlantTelaFuncio.Image");
            ptbCriarPlantTelaFuncio.Location = new Point(3, 2);
            ptbCriarPlantTelaFuncio.Margin = new Padding(3, 2, 3, 2);
            ptbCriarPlantTelaFuncio.Name = "ptbCriarPlantTelaFuncio";
            ptbCriarPlantTelaFuncio.Size = new Size(44, 44);
            ptbCriarPlantTelaFuncio.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbCriarPlantTelaFuncio.TabIndex = 3;
            ptbCriarPlantTelaFuncio.TabStop = false;
            // 
            // btnCriarPlantTelaFuncio
            // 
            btnCriarPlantTelaFuncio.BackColor = Color.FromArgb(99, 120, 55);
            btnCriarPlantTelaFuncio.FlatAppearance.BorderSize = 0;
            btnCriarPlantTelaFuncio.FlatAppearance.MouseDownBackColor = Color.YellowGreen;
            btnCriarPlantTelaFuncio.FlatStyle = FlatStyle.Flat;
            btnCriarPlantTelaFuncio.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCriarPlantTelaFuncio.ForeColor = Color.FromArgb(238, 241, 212);
            btnCriarPlantTelaFuncio.Location = new Point(53, 3);
            btnCriarPlantTelaFuncio.Name = "btnCriarPlantTelaFuncio";
            btnCriarPlantTelaFuncio.RightToLeft = RightToLeft.No;
            btnCriarPlantTelaFuncio.Size = new Size(158, 43);
            btnCriarPlantTelaFuncio.TabIndex = 1;
            btnCriarPlantTelaFuncio.Text = "Criar Plantação";
            btnCriarPlantTelaFuncio.UseVisualStyleBackColor = false;
            btnCriarPlantTelaFuncio.Click += btnCriarPlant_Click;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Controls.Add(pictureBox2);
            flowLayoutPanel1.Controls.Add(button1);
            flowLayoutPanel1.Location = new Point(3, 51);
            flowLayoutPanel1.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(214, 50);
            flowLayoutPanel1.TabIndex = 6;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(3, 2);
            pictureBox2.Margin = new Padding(3, 2, 3, 2);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(44, 44);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(99, 120, 55);
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatAppearance.MouseDownBackColor = Color.YellowGreen;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Location = new Point(53, 3);
            button1.Name = "button1";
            button1.RightToLeft = RightToLeft.No;
            button1.Size = new Size(158, 43);
            button1.TabIndex = 1;
            button1.Text = "Criar Plantação";
            button1.UseVisualStyleBackColor = false;
            // 
            // ptbMenuTelaFuncio
            // 
            ptbMenuTelaFuncio.Image = (Image)resources.GetObject("ptbMenuTelaFuncio.Image");
            ptbMenuTelaFuncio.Location = new Point(31, 64);
            ptbMenuTelaFuncio.Name = "ptbMenuTelaFuncio";
            ptbMenuTelaFuncio.Size = new Size(142, 105);
            ptbMenuTelaFuncio.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbMenuTelaFuncio.TabIndex = 0;
            ptbMenuTelaFuncio.TabStop = false;
            // 
            // panTelaFuncio
            // 
            panTelaFuncio.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panTelaFuncio.BackColor = Color.FromArgb(238, 241, 212);
            panTelaFuncio.Location = new Point(215, 44);
            panTelaFuncio.Name = "panTelaFuncio";
            panTelaFuncio.Size = new Size(584, 406);
            panTelaFuncio.TabIndex = 2;
            panTelaFuncio.Paint += Content_Paint;
            // 
            // panStartuTelaFuncio
            // 
            panStartuTelaFuncio.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panStartuTelaFuncio.BackColor = Color.FromArgb(75, 82, 51);
            panStartuTelaFuncio.Controls.Add(flowLayoutPanel13);
            panStartuTelaFuncio.Location = new Point(0, 0);
            panStartuTelaFuncio.Name = "panStartuTelaFuncio";
            panStartuTelaFuncio.Size = new Size(799, 43);
            panStartuTelaFuncio.TabIndex = 1;
            // 
            // flowLayoutPanel13
            // 
            flowLayoutPanel13.Controls.Add(ptbStartuTelaFuncio);
            flowLayoutPanel13.Controls.Add(lblStartuTelaFuncio);
            flowLayoutPanel13.Location = new Point(296, 4);
            flowLayoutPanel13.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel13.Name = "flowLayoutPanel13";
            flowLayoutPanel13.Size = new Size(214, 38);
            flowLayoutPanel13.TabIndex = 6;
            // 
            // ptbStartuTelaFuncio
            // 
            ptbStartuTelaFuncio.Image = (Image)resources.GetObject("ptbStartuTelaFuncio.Image");
            ptbStartuTelaFuncio.Location = new Point(3, 2);
            ptbStartuTelaFuncio.Margin = new Padding(3, 2, 3, 2);
            ptbStartuTelaFuncio.Name = "ptbStartuTelaFuncio";
            ptbStartuTelaFuncio.Size = new Size(36, 32);
            ptbStartuTelaFuncio.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbStartuTelaFuncio.TabIndex = 3;
            ptbStartuTelaFuncio.TabStop = false;
            // 
            // lblStartuTelaFuncio
            // 
            lblStartuTelaFuncio.Anchor = AnchorStyles.Top;
            lblStartuTelaFuncio.AutoSize = true;
            lblStartuTelaFuncio.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblStartuTelaFuncio.ForeColor = Color.White;
            lblStartuTelaFuncio.Location = new Point(45, 0);
            lblStartuTelaFuncio.Name = "lblStartuTelaFuncio";
            lblStartuTelaFuncio.Size = new Size(149, 32);
            lblStartuTelaFuncio.TabIndex = 0;
            lblStartuTelaFuncio.Text = "STARTUPYX";
            lblStartuTelaFuncio.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TelaDosFuncionarios
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(238, 241, 212);
            ClientSize = new Size(800, 450);
            Controls.Add(panStartuTelaFuncio);
            Controls.Add(panMenuTelaFuncio);
            Controls.Add(panTelaFuncio);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "TelaDosFuncionarios";
            Text = "TelaDosFuncionarios";
            Load += TelaDosFuncionarios_Load;
            panMenuTelaFuncio.ResumeLayout(false);
            flowLayoutPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)ptbVisuaPlantTelaFuncio).EndInit();
            flowLayoutPanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            flowLayoutPanel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            flowLayoutPanel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            flowLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)ptbFazerRelatTelaFuncio).EndInit();
            flowLayoutPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            flowLayoutPanel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)ptbAlterarPlantTelaFuncio).EndInit();
            flowLayoutPanel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            flowLayoutPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)ptbCriarPlantTelaFuncio).EndInit();
            flowLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)ptbMenuTelaFuncio).EndInit();
            panStartuTelaFuncio.ResumeLayout(false);
            flowLayoutPanel13.ResumeLayout(false);
            flowLayoutPanel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)ptbStartuTelaFuncio).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panMenuTelaFuncio;
        private Panel panTelaFuncio;
        private PictureBox ptbMenuTelaFuncio;
        private Button btnVisuaPlantTelaFuncio;
        private Button btnFazerRelatTelaFuncio;
        private Button btnAlterarPlantTelaFuncio;
        private Button btnCriarPlantTelaFuncio;
        private Panel panStartuTelaFuncio;
        private FlowLayoutPanel flowLayoutPanel13;
        private PictureBox ptbStartuTelaFuncio;
        private Label lblStartuTelaFuncio;
        private FlowLayoutPanel flowLayoutPanel4;
        private PictureBox ptbCriarPlantTelaFuncio;
        private FlowLayoutPanel flowLayoutPanel9;
        private PictureBox ptbAlterarPlantTelaFuncio;
        private FlowLayoutPanel flowLayoutPanel10;
        private PictureBox pictureBox11;
        private Button button10;
        private FlowLayoutPanel flowLayoutPanel1;
        private PictureBox pictureBox2;
        private Button button1;
        private FlowLayoutPanel flowLayoutPanel2;
        private PictureBox ptbFazerRelatTelaFuncio;
        private FlowLayoutPanel flowLayoutPanel3;
        private PictureBox pictureBox4;
        private Button button3;
        private FlowLayoutPanel flowLayoutPanel5;
        private PictureBox ptbVisuaPlantTelaFuncio;
        private FlowLayoutPanel flowLayoutPanel6;
        private PictureBox pictureBox7;
        private Button button6;
        private FlowLayoutPanel flowLayoutPanel7;
        private PictureBox pictureBox8;
        private Button button7;
        private FlowLayoutPanel flowLayoutPanel8;
        private PictureBox pictureBox9;
        private Button button8;
    }
}