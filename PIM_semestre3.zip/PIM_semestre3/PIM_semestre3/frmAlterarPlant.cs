﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMTESTE_
{
    public partial class frmAlterarPlant : Form
    {
        protected int index = 0;
        public frmAlterarPlant()
        {
            InitializeComponent();

            //conexao com o bd
            BdPlantacaoSelect db = new BdPlantacaoSelect();

            // Seleção
            string[] resultados = db.Select();
            if (resultados.Length > 0)
            {
                index = int.Parse(resultados[0]);
                this.txtbTipoPlantAlterarPlant.Text = resultados[4];
                this.txtbSacoSemenAlterarPlant.Text = resultados[2];
                this.txtbSacoAduboAlterarPlant.Text = resultados[3];
                this.txtbTipoCultAlterarPlant.Text = resultados[1];
            }
            else
            {
                //caso não tenha dados na tabela
                MessageBox.Show("Infelismente não foi possivel se conectar ao banco de dados \n ou o mesmo não possui plantações ativas no momento\ntente novamente mais tarde");
            }
        }

        private void frmAlterarPlant_Load(object sender, EventArgs e)
        {

        }

        private void lblAlterarPlant_Click(object sender, EventArgs e)
        {

        }

        private void btnAlterarAlterarPlant_Click(object sender, EventArgs e)
        {
            //verifica se os campos estao vasios
            if (this.txtbSacoAduboAlterarPlant.Text == string.Empty || this.txtbSacoSemenAlterarPlant.Text == string.Empty ||
                this.txtbTipoCultAlterarPlant.Text == string.Empty || this.txtbTipoPlantAlterarPlant.Text == string.Empty)
            {
                //caso algum campo esteja vazio ele mostra essa mensasagem
                MessageBox.Show("Um dos campos não foi preenchido, por favor os preencha com os dados corretos");
            }
            else
            {



                //conexao com o bd
                BdPlantacaoSelect bd = new BdPlantacaoSelect();
                //string[] valores = bd.Select();
                bool success = bd.Update(index, "2025-01-01",
                    this.txtbTipoPlantAlterarPlant.Text,
                    this.txtbTipoCultAlterarPlant.Text,
                    this.txtbSacoSemenAlterarPlant.Text,
                    this.txtbSacoAduboAlterarPlant.Text);
                if (success)
                {
                    MessageBox.Show("Plantação alterada");
                }

                //esvazia os campos
                this.txtbSacoAduboAlterarPlant.Text = string.Empty;
                this.txtbSacoSemenAlterarPlant.Text = string.Empty;
                this.txtbTipoCultAlterarPlant.Text = string.Empty;
                this.txtbTipoPlantAlterarPlant.Text = string.Empty;

            }

        }
    }
}
