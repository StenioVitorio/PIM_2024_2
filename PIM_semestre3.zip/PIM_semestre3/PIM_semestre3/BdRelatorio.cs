﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIMTESTE_
{
    internal class BdRelatorio
    {
        
        private string stringconexao = $"server=localhost;uid=root;pwd=BDADIMIN123?;database=db_fazenda_urbana";
        
        
        public string[] Select()
        {
            List<string> valores = new List<string>();
            using (MySqlConnection conn = new MySqlConnection(stringconexao))
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand("SELECT Tipo_cultivo FROM plantacao",conn);
                    
                    MySqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        valores.Add(reader.GetString(0));
                    }
                    
                    conn.Close();
                    
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    
                }
            }
            return valores.ToArray();

        }
        public bool Insert( string nome_produto, string unidade_medida)
        {
            int success=0;
            using (MySqlConnection conn = new MySqlConnection(stringconexao))
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand("INSERT INTO produto (Tipo_armazenagem, Preco_produto, Nome_produto, Unidade_medida, ID_fazenda_PK) VALUES ('Refrigerado', 5.00, @Nome_produto, @Unidade_medida, 4)", conn);
                    
                    cmd.Parameters.AddWithValue("@Nome_produto", nome_produto);
                    cmd.Parameters.AddWithValue("@Unidade_medida", int.Parse(unidade_medida));
                    
                    success = cmd.ExecuteNonQuery();
                    conn.Close();
                    return success > 0;
                    

                }
                catch (Exception ex)
                {
                    return false;
                    Console.WriteLine(ex.Message);

                }

            }
            

        }



    }
}
