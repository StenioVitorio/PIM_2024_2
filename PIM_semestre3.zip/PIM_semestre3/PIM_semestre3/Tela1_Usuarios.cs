﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMTESTE_
{
    public partial class Tela1_Usuarios : Form
    {
        public Tela1_Usuarios()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Tela2_Usuarios lgtela = new Tela2_Usuarios();
            this.Hide();
            lgtela.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Formulario_Cliente rgtela = new Formulario_Cliente();
            this.Hide();
            rgtela.Show();
        }

        private void btnAcessTela1Usuarios_Click(object sender, EventArgs e)
        {
            Tela2_Usuarios tela2Usuarios = new Tela2_Usuarios();
            tela2Usuarios.Show();
            this.Hide();
        }
    }
}
