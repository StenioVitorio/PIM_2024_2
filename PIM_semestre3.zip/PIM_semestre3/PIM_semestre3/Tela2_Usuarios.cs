﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace PIMTESTE_
{
    public partial class Tela2_Usuarios : Form
    {
        public Tela2_Usuarios()
        {
            InitializeComponent();
        }

        private void btnAcessTela2Usuarios_Click(object sender, EventArgs e)
        {
            if (this.txtbEmailTela2Usuarios.Text == string.Empty || this.txtbSenhaTela2Usuarios.Text == string.Empty)
            {
                MessageBox.Show("Um ou mais campos estão vazios!");
            }
            else
            {
                var strConexao = "server=localhost;uid=root;pwd=Stark@24;database=db_fazenda_urbana";
                var email = txtbEmailTela2Usuarios.Text;
                var senha = txtbSenhaTela2Usuarios.Text;

                try
                {

                    using (MySqlConnection conn = new MySqlConnection(strConexao))
                    {
                        conn.Open();

                        string query = @"
        SELECT COUNT(*) 
        FROM (
            SELECT E_mail, Senha FROM cliente WHERE BINARY E_mail = @Email AND BINARY Senha = @Senha
            UNION ALL
            SELECT E_mail, Senha FROM funcionario WHERE BINARY E_mail = @Email AND BINARY Senha = @Senha
        ) AS combined";

                        using (MySqlCommand cmd = new MySqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@Email", email);
                            cmd.Parameters.AddWithValue("@Senha", senha);

                            int result = Convert.ToInt32(cmd.ExecuteScalar());

                            if (result > 0)
                            {
                                MessageBox.Show("Login realizado com sucesso!");
                                TelaDosClientes telaDosClientes = new TelaDosClientes();
                                telaDosClientes.Show();
                                this.Hide();
                            }
                            else
                            {
                                MessageBox.Show("E-mail ou senha incorretos!");
                            }
                        }

                        conn.Close();
                    }


                    //using (MySqlConnection conn = new MySqlConnection(strConexao))
                    //{
                    //    conn.Open();

                    //    string query = "SELECT COUNT(*) FROM cliente WHERE BINARY E_mail = @Email AND BINARY Senha = @Senha";
                    //    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    //    {
                    //        cmd.Parameters.AddWithValue("@Email", email);
                    //        cmd.Parameters.AddWithValue("@Senha", senha);

                    //        int result = Convert.ToInt32(cmd.ExecuteScalar());

                    //        if (result > 0)
                    //        {
                    //            MessageBox.Show("Login realizado com sucesso!");
                    //            TelaDosClientes telaDosClientes = new TelaDosClientes();
                    //            telaDosClientes.Show();
                    //            this.Hide();
                    //        }
                    //        else
                    //        {
                    //            MessageBox.Show("E-mail ou senha incorretos!");
                    //        }
                    //    }
                    //    conn.Close();
                    //}

                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Erro de MySQL: " + ex.Message + "\n" + ex.StackTrace);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message + "\n" + ex.StackTrace);
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnCriarContaTela2Usuarios_Click(object sender, EventArgs e)
        {
            Formulario_Cliente formularioCliente = new Formulario_Cliente();
            formularioCliente.Show();
            this.Hide();
        }

        private void btnVoltarTela2Usuarios_Click(object sender, EventArgs e)
        {
            Tela1_Usuarios tela1Usuarios = new Tela1_Usuarios();
            tela1Usuarios.Show();
            this.Hide();
        }

        private void Tela2_Usuarios_Load(object sender, EventArgs e)
        {

        }

        private void btnAcessTela2Usuarios_Click_1(object sender, EventArgs e)
        {
            if (this.txtbEmailTela2Usuarios.Text == string.Empty || this.txtbSenhaTela2Usuarios.Text == string.Empty)
            {
                MessageBox.Show("Um ou mais campos estão vazios!");
            }
            else
            {
                var strConexao = "server=localhost;uid=root;pwd=439360;database=db_fazenda_urbana";
                var email = txtbEmailTela2Usuarios.Text;
                var senha = txtbSenhaTela2Usuarios.Text;

                try
                {

                    using (MySqlConnection conn = new MySqlConnection(strConexao))
                    {
                        conn.Open();

                        string query = @"
        SELECT COUNT(*) 
        FROM (
            SELECT E_mail, Senha FROM cliente WHERE BINARY E_mail = @Email AND BINARY Senha = @Senha
            UNION ALL
            SELECT E_mail, Senha FROM funcionario WHERE BINARY E_mail = @Email AND BINARY Senha = @Senha
        ) AS combined";

                        using (MySqlCommand cmd = new MySqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@Email", email);
                            cmd.Parameters.AddWithValue("@Senha", senha);

                            int result = Convert.ToInt32(cmd.ExecuteScalar());

                            if (result > 0)
                            {
                                MessageBox.Show("Login realizado com sucesso!");
                                TelaDosClientes telaDosClientes = new TelaDosClientes();
                                telaDosClientes.Show();
                                this.Hide();
                            }
                            else
                            {
                                MessageBox.Show("E-mail ou senha incorretos!");
                            }
                        }

                        conn.Close();
                    }


                    //using (MySqlConnection conn = new MySqlConnection(strConexao))
                    //{
                    //    conn.Open();

                    //    string query = "SELECT COUNT(*) FROM cliente WHERE BINARY E_mail = @Email AND BINARY Senha = @Senha";
                    //    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    //    {
                    //        cmd.Parameters.AddWithValue("@Email", email);
                    //        cmd.Parameters.AddWithValue("@Senha", senha);

                    //        int result = Convert.ToInt32(cmd.ExecuteScalar());

                    //        if (result > 0)
                    //        {
                    //            MessageBox.Show("Login realizado com sucesso!");
                    //            TelaDosClientes telaDosClientes = new TelaDosClientes();
                    //            telaDosClientes.Show();
                    //            this.Hide();
                    //        }
                    //        else
                    //        {
                    //            MessageBox.Show("E-mail ou senha incorretos!");
                    //        }
                    //    }
                    //    conn.Close();
                    //}

                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Erro de MySQL: " + ex.Message + "\n" + ex.StackTrace);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message + "\n" + ex.StackTrace);
                }
            }
        }

        private void btnVoltarTela2Usuarios_Click_1(object sender, EventArgs e)
        {
            Tela1_Usuarios tela1Usuarios = new Tela1_Usuarios();
            tela1Usuarios.Show();
            this.Hide();
        }

        private void btnCriarContaTela2Usuarios_Click_1(object sender, EventArgs e)
        {
            Formulario_Cliente formularioCliente = new Formulario_Cliente();
            formularioCliente.Show();
            this.Hide();
        }
    }
}
