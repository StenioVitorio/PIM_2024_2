﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMTESTE_
{
    public partial class frmTelaCompras : Form
    {
        public frmTelaCompras()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Tela1_Usuarios maintela = new Tela1_Usuarios();
            this.Hide();
            maintela.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void cmbSelecPlantFuncio_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbQtdProdTelaCompras_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtbArmazenTelaCompras_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtbPrecoProdTelaCompras_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void btnProximoTelaCompras_Click(object sender, EventArgs e)
        {
            var qnt = int.Parse(txtbQuantProdTelaCompras.Text);
            if (cmbNomeProdTelaCompras.Text == "Tomate")//Tomate
            {
                var preco = qnt * 1.5;
                txtbPrecoProdTelaCompras.Text = $"{preco} Reais.";
            } else if (cmbNomeProdTelaCompras.Text == "Salsa")// Salsa
            {
                var preco = qnt * 1;
                txtbPrecoProdTelaCompras.Text = $"{preco} Reais.";
            } else if (cmbNomeProdTelaCompras.Text == "Cebolinha")//Cebolinha
            {
                var preco = qnt * 0.8;
                txtbPrecoProdTelaCompras.Text = $"{preco} Reais.";
            }

        }
    }
}
