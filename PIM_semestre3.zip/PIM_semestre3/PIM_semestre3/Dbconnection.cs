﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32.SafeHandles;
using MySql.Data.MySqlClient;
using System.Windows.Forms;
using System.Configuration;
using MySqlX.XDevAPI.Relational;

namespace PIMTESTE_
{
    internal class Dbconnection
    {
        protected MySqlConnection bdconn = new MySqlConnection("server=localhost;uid=root;pwd=123456;database=db_fazenda_urbana");


        virtual public string[] bdSelect(string campos, string table, string extra)
        {

            string[] valores = { };
            using (bdconn)
            {
                try
                {
                    bdconn.Open();
                    string query = "SELECT (" + campos + ") FROM " + table + " " + extra;

                    MySqlCommand comando = new MySqlCommand(query, bdconn);
                    MySqlDataReader reader = comando.ExecuteReader();
                    int i = 0;
                    while (reader.Read())
                    {
                        i++;
                        valores[i] = reader.GetString(i);
                    }

                    bdconn.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("error: " + ex);
                }
            }
            return valores;

        }

        public string[] bdSelectWhere(string campos, string table, string where, string extra)
        {
            string[] valores = { };
            using (bdconn)
            {
                try
                {
                    bdconn.Open();
                    string query = "SELECT " + campos + " FROM " + table + "WHERE " + where + " " + extra;

                    MySqlCommand comando = new MySqlCommand(query, bdconn);
                    MySqlDataReader reader = comando.ExecuteReader();
                    int i = 0;
                    while (reader.Read())
                    {
                        i++;
                        valores[i] = reader.GetString(i);
                    }

                    bdconn.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("error: " + ex);
                }
            }
            return valores;
        }

    }

}