﻿namespace PIMTESTE_
{
    partial class frmFazerRelat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblFazerRelat = new Label();
            cmbSelecPlantFazerRelat = new ComboBox();
            flowLayoutPanel2 = new FlowLayoutPanel();
            txtbQtdMudasProntas = new TextBox();
            txtbMudasNProntas = new TextBox();
            txtbMudasPerdidas = new TextBox();
            txtbEstacaoFazerRelat = new TextBox();
            lblSelecPlantFazerRelat = new Label();
            btnSalvarFazerRelat = new Button();
            lblPCamposFazerRelat = new Label();
            flowLayoutPanel2.SuspendLayout();
            SuspendLayout();
            // 
            // lblFazerRelat
            // 
            lblFazerRelat.AutoSize = true;
            lblFazerRelat.BackColor = Color.Transparent;
            lblFazerRelat.Dock = DockStyle.Top;
            lblFazerRelat.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblFazerRelat.ForeColor = Color.FromArgb(75, 82, 51);
            lblFazerRelat.Location = new Point(0, 0);
            lblFazerRelat.Name = "lblFazerRelat";
            lblFazerRelat.Size = new Size(288, 51);
            lblFazerRelat.TabIndex = 0;
            lblFazerRelat.Text = "Fazer Relatório";
            lblFazerRelat.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // cmbSelecPlantFazerRelat
            // 
            cmbSelecPlantFazerRelat.BackColor = SystemColors.Window;
            cmbSelecPlantFazerRelat.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cmbSelecPlantFazerRelat.ForeColor = SystemColors.WindowText;
            cmbSelecPlantFazerRelat.FormattingEnabled = true;
            cmbSelecPlantFazerRelat.Location = new Point(53, 102);
            cmbSelecPlantFazerRelat.Margin = new Padding(3, 2, 3, 2);
            cmbSelecPlantFazerRelat.Name = "cmbSelecPlantFazerRelat";
            cmbSelecPlantFazerRelat.Size = new Size(447, 38);
            cmbSelecPlantFazerRelat.TabIndex = 26;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.Controls.Add(txtbQtdMudasProntas);
            flowLayoutPanel2.Controls.Add(txtbMudasNProntas);
            flowLayoutPanel2.Controls.Add(txtbMudasPerdidas);
            flowLayoutPanel2.Controls.Add(txtbEstacaoFazerRelat);
            flowLayoutPanel2.Location = new Point(53, 182);
            flowLayoutPanel2.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(453, 172);
            flowLayoutPanel2.TabIndex = 55;
            // 
            // txtbQtdMudasProntas
            // 
            txtbQtdMudasProntas.BackColor = SystemColors.Window;
            txtbQtdMudasProntas.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbQtdMudasProntas.ForeColor = SystemColors.WindowText;
            txtbQtdMudasProntas.Location = new Point(3, 3);
            txtbQtdMudasProntas.Name = "txtbQtdMudasProntas";
            txtbQtdMudasProntas.PlaceholderText = " Quantidades de mudas prontas*";
            txtbQtdMudasProntas.Size = new Size(447, 36);
            txtbQtdMudasProntas.TabIndex = 13;
            // 
            // txtbMudasNProntas
            // 
            txtbMudasNProntas.BackColor = SystemColors.Window;
            txtbMudasNProntas.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbMudasNProntas.ForeColor = SystemColors.WindowText;
            txtbMudasNProntas.Location = new Point(3, 45);
            txtbMudasNProntas.Name = "txtbMudasNProntas";
            txtbMudasNProntas.PlaceholderText = " Mudas não prontas*";
            txtbMudasNProntas.Size = new Size(447, 36);
            txtbMudasNProntas.TabIndex = 12;
            // 
            // txtbMudasPerdidas
            // 
            txtbMudasPerdidas.BackColor = SystemColors.Window;
            txtbMudasPerdidas.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbMudasPerdidas.ForeColor = SystemColors.WindowText;
            txtbMudasPerdidas.Location = new Point(3, 87);
            txtbMudasPerdidas.Name = "txtbMudasPerdidas";
            txtbMudasPerdidas.PlaceholderText = " Mudas perdidas*";
            txtbMudasPerdidas.Size = new Size(447, 36);
            txtbMudasPerdidas.TabIndex = 11;
            // 
            // txtbEstacaoFazerRelat
            // 
            txtbEstacaoFazerRelat.BackColor = SystemColors.Window;
            txtbEstacaoFazerRelat.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbEstacaoFazerRelat.ForeColor = SystemColors.WindowText;
            txtbEstacaoFazerRelat.Location = new Point(3, 129);
            txtbEstacaoFazerRelat.Name = "txtbEstacaoFazerRelat";
            txtbEstacaoFazerRelat.PlaceholderText = "Estação*";
            txtbEstacaoFazerRelat.Size = new Size(447, 36);
            txtbEstacaoFazerRelat.TabIndex = 27;
            // 
            // lblSelecPlantFazerRelat
            // 
            lblSelecPlantFazerRelat.AutoSize = true;
            lblSelecPlantFazerRelat.BackColor = Color.Transparent;
            lblSelecPlantFazerRelat.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblSelecPlantFazerRelat.ForeColor = SystemColors.WindowText;
            lblSelecPlantFazerRelat.Location = new Point(53, 71);
            lblSelecPlantFazerRelat.Name = "lblSelecPlantFazerRelat";
            lblSelecPlantFazerRelat.Size = new Size(221, 30);
            lblSelecPlantFazerRelat.TabIndex = 31;
            lblSelecPlantFazerRelat.Text = "Selecione a Plantação";
            // 
            // btnSalvarFazerRelat
            // 
            btnSalvarFazerRelat.BackColor = Color.YellowGreen;
            btnSalvarFazerRelat.FlatAppearance.BorderSize = 0;
            btnSalvarFazerRelat.FlatStyle = FlatStyle.Flat;
            btnSalvarFazerRelat.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnSalvarFazerRelat.ForeColor = Color.FromArgb(57, 62, 40);
            btnSalvarFazerRelat.Location = new Point(394, 353);
            btnSalvarFazerRelat.Name = "btnSalvarFazerRelat";
            btnSalvarFazerRelat.Size = new Size(115, 34);
            btnSalvarFazerRelat.TabIndex = 54;
            btnSalvarFazerRelat.Text = "Salvar";
            btnSalvarFazerRelat.UseVisualStyleBackColor = false;
            btnSalvarFazerRelat.Click += btnSalvarFazerRelat_Click;
            // 
            // lblPCamposFazerRelat
            // 
            lblPCamposFazerRelat.AutoSize = true;
            lblPCamposFazerRelat.BackColor = Color.Transparent;
            lblPCamposFazerRelat.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPCamposFazerRelat.ForeColor = SystemColors.WindowText;
            lblPCamposFazerRelat.Location = new Point(53, 152);
            lblPCamposFazerRelat.Name = "lblPCamposFazerRelat";
            lblPCamposFazerRelat.Size = new Size(211, 30);
            lblPCamposFazerRelat.TabIndex = 56;
            lblPCamposFazerRelat.Text = "Preencha os campos";
            // 
            // frmFazerRelat
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(238, 241, 212);
            ClientSize = new Size(584, 406);
            Controls.Add(lblPCamposFazerRelat);
            Controls.Add(cmbSelecPlantFazerRelat);
            Controls.Add(flowLayoutPanel2);
            Controls.Add(lblSelecPlantFazerRelat);
            Controls.Add(lblFazerRelat);
            Controls.Add(btnSalvarFazerRelat);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmFazerRelat";
            Text = "frmFazerRelat";
            Load += frmFazerRelat_Load;
            flowLayoutPanel2.ResumeLayout(false);
            flowLayoutPanel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblFazerRelat;
        private ComboBox cmbSelecPlantFazerRelat;
        private FlowLayoutPanel flowLayoutPanel2;
        private TextBox txtbQtdMudasProntas;
        private TextBox txtbMudasNProntas;
        private TextBox txtbMudasPerdidas;
        private TextBox txtbEstacaoFazerRelat;
        private Label lblSelecPlantFazerRelat;
        private Button btnSalvarFazerRelat;
        private Label lblPCamposFazerRelat;
    }
}