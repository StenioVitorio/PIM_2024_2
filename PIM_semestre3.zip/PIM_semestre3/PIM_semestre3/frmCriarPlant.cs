﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMTESTE_
{
    public partial class frmCriarPlant : Form
    {
        public frmCriarPlant()
        {
            InitializeComponent();
        }

        private void btnSalvarCriarPlant_Click(object sender, EventArgs e)
        {
            //verifica se os campos estao vasios
            if (this.txtbTipoCultCriarPlant.Text == string.Empty || this.txtbTipoPlantCriarPlant.Text == string.Empty ||
                this.txtbSacoSemenCriarPlant.Text == string.Empty || this.txtbSacoAduboCriarPlant.Text == string.Empty)
            {
                //caso algum campo esteja vazio ele mostra essa mensasagem
                MessageBox.Show("Um dos campos não foi preenchido, por favor os preencha com os dados corretos");
            }
            else
            {


                //executar a query
                BdPlantacaoSelect bd = new BdPlantacaoSelect();
                bd.Insert("2024-12-12", txtbTipoPlantCriarPlant.Text,
                    this.txtbTipoCultCriarPlant.Text,
                    this.txtbSacoSemenCriarPlant.Text,
                    this.txtbSacoAduboCriarPlant.Text);
                //esvazia os campos
                this.txtbSacoAduboCriarPlant.Text = string.Empty;
                this.txtbSacoSemenCriarPlant.Text = string.Empty;
                this.txtbTipoCultCriarPlant.Text = string.Empty;
                this.txtbTipoPlantCriarPlant.Text = string.Empty;
                //caso tudo esteja certo mostra essa menssagem
                MessageBox.Show("Plantação criada!");

            }
        }
    }
}
