﻿namespace PIMTESTE_
{
    partial class frmRelatPlants
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblRelatorios = new Label();
            dgv2RelatPlants = new DataGridView();
            dataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn2 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn3 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn4 = new DataGridViewTextBoxColumn();
            dgv1RelatPlants = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            btnGerarRelatPlants = new Button();
            ((System.ComponentModel.ISupportInitialize)dgv2RelatPlants).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgv1RelatPlants).BeginInit();
            SuspendLayout();
            // 
            // lblRelatorios
            // 
            lblRelatorios.AutoSize = true;
            lblRelatorios.Dock = DockStyle.Top;
            lblRelatorios.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblRelatorios.Location = new Point(0, 0);
            lblRelatorios.Name = "lblRelatorios";
            lblRelatorios.Size = new Size(418, 51);
            lblRelatorios.TabIndex = 2;
            lblRelatorios.Text = "Relatório de Platações";
            lblRelatorios.TextAlign = ContentAlignment.MiddleCenter;
            lblRelatorios.Click += lblRelatorios_Click;
            // 
            // dgv2RelatPlants
            // 
            dgv2RelatPlants.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv2RelatPlants.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn1, dataGridViewTextBoxColumn2, dataGridViewTextBoxColumn3, dataGridViewTextBoxColumn4 });
            dgv2RelatPlants.Location = new Point(50, 226);
            dgv2RelatPlants.Margin = new Padding(3, 2, 3, 2);
            dgv2RelatPlants.Name = "dgv2RelatPlants";
            dgv2RelatPlants.ReadOnly = true;
            dgv2RelatPlants.RowHeadersWidth = 51;
            dgv2RelatPlants.Size = new Size(484, 58);
            dgv2RelatPlants.TabIndex = 7;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewTextBoxColumn1.HeaderText = "Qtd. Sacos de Semente";
            dataGridViewTextBoxColumn1.MinimumWidth = 6;
            dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            dataGridViewTextBoxColumn1.ReadOnly = true;
            dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewTextBoxColumn2.HeaderText = "Qtd. Sacos de Adubo";
            dataGridViewTextBoxColumn2.MinimumWidth = 6;
            dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            dataGridViewTextBoxColumn2.ReadOnly = true;
            dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewTextBoxColumn3.HeaderText = "Nome do Produto";
            dataGridViewTextBoxColumn3.MinimumWidth = 6;
            dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            dataGridViewTextBoxColumn3.ReadOnly = true;
            dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewTextBoxColumn4.HeaderText = "Data do Plantio";
            dataGridViewTextBoxColumn4.MinimumWidth = 6;
            dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            dataGridViewTextBoxColumn4.ReadOnly = true;
            dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dgv1RelatPlants
            // 
            dgv1RelatPlants.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv1RelatPlants.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4 });
            dgv1RelatPlants.Location = new Point(50, 122);
            dgv1RelatPlants.Margin = new Padding(3, 2, 3, 2);
            dgv1RelatPlants.Name = "dgv1RelatPlants";
            dgv1RelatPlants.ReadOnly = true;
            dgv1RelatPlants.RowHeadersWidth = 51;
            dgv1RelatPlants.Size = new Size(484, 58);
            dgv1RelatPlants.TabIndex = 6;
            // 
            // Column1
            // 
            Column1.HeaderText = "ID_Plantação";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            Column1.Width = 125;
            // 
            // Column2
            // 
            Column2.HeaderText = "Tipo de Plantio";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            Column2.Width = 125;
            // 
            // Column3
            // 
            Column3.HeaderText = "Tipo de Cultivo";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            Column3.Width = 125;
            // 
            // Column4
            // 
            Column4.HeaderText = "Nome do Produto";
            Column4.MinimumWidth = 6;
            Column4.Name = "Column4";
            Column4.ReadOnly = true;
            Column4.Width = 125;
            // 
            // btnGerarRelatPlants
            // 
            btnGerarRelatPlants.BackColor = Color.YellowGreen;
            btnGerarRelatPlants.FlatAppearance.BorderSize = 0;
            btnGerarRelatPlants.FlatStyle = FlatStyle.Flat;
            btnGerarRelatPlants.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnGerarRelatPlants.ForeColor = Color.FromArgb(57, 62, 40);
            btnGerarRelatPlants.Location = new Point(419, 347);
            btnGerarRelatPlants.Name = "btnGerarRelatPlants";
            btnGerarRelatPlants.Size = new Size(115, 34);
            btnGerarRelatPlants.TabIndex = 64;
            btnGerarRelatPlants.Text = "Gerar";
            btnGerarRelatPlants.UseVisualStyleBackColor = false;
            btnGerarRelatPlants.Click += btnGerarRelatPlants_Click;
            // 
            // frmRelatPlants
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(238, 241, 212);
            ClientSize = new Size(584, 406);
            Controls.Add(btnGerarRelatPlants);
            Controls.Add(dgv2RelatPlants);
            Controls.Add(dgv1RelatPlants);
            Controls.Add(lblRelatorios);
            ForeColor = Color.FromArgb(57, 62, 40);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmRelatPlants";
            Text = "Relatório de Plantações";
            ((System.ComponentModel.ISupportInitialize)dgv2RelatPlants).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgv1RelatPlants).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblRelatorios;
        private DataGridView dgv2RelatPlants;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private DataGridView dgv1RelatPlants;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private Button btnGerarRelatPlants;
    }
}