﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMTESTE_
{
    public partial class TelaDosGerentes : Form
    {
        public TelaDosGerentes()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnFuturosPlant_Click(object sender, EventArgs e)
        {
            this.panTelaGerente.Controls.Clear();
            frmOpcoesFuturas frmOpcoesFuturasView = new frmOpcoesFuturas() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frmOpcoesFuturasView.FormBorderStyle = FormBorderStyle.None;
            this.panTelaGerente.Controls.Add(frmOpcoesFuturasView);
            frmOpcoesFuturasView.Show();
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void lblStartupyx_Click(object sender, EventArgs e)
        {

        }

        private void button20_Click(object sender, EventArgs e)
        {
            this.panTelaGerente.Controls.Clear();
            frmRelatVendas frmRelatVendasView = new frmRelatVendas() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frmRelatVendasView.FormBorderStyle = FormBorderStyle.None;
            this.panTelaGerente.Controls.Add(frmRelatVendasView);
            frmRelatVendasView.Show();
        }

        private void TelaDosGerentes_Load(object sender, EventArgs e)
        {

        }

        private void btnCadastFunc_Click(object sender, EventArgs e)
        {
            this.panTelaGerente.Controls.Clear();
            frmCadastrarFunc frmCadastrarFuncView = new frmCadastrarFunc() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frmCadastrarFuncView.FormBorderStyle = FormBorderStyle.None;
            this.panTelaGerente.Controls.Add(frmCadastrarFuncView);
            frmCadastrarFuncView.Show();
        }

        private void btnRelatoriosPlants_Click_1(object sender, EventArgs e)
        {
            this.panTelaGerente.Controls.Clear();
            frmRelatPlants frmRelatPlantsView = new frmRelatPlants() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frmRelatPlantsView.FormBorderStyle = FormBorderStyle.None;
            this.panTelaGerente.Controls.Add(frmRelatPlantsView);
            frmRelatPlantsView.Show();
        }

        private void btnRelatEstoq_Click_1(object sender, EventArgs e)
        {
            this.panTelaGerente.Controls.Clear();
            frmRelatEstoqs frmRelatEstoqsView = new frmRelatEstoqs() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frmRelatEstoqsView.FormBorderStyle = FormBorderStyle.None;
            this.panTelaGerente.Controls.Add(frmRelatEstoqsView);
            frmRelatEstoqsView.Show();
        }
    }
}
