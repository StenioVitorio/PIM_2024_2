﻿namespace PIMTESTE_
{
    partial class frmRelatEstoqs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblRelatEstoqs = new Label();
            dgvProdutoRelatEstoqs = new DataGridView();
            dgvInsumoRelatEstoqs = new DataGridView();
            lblProdutoRelatEstoqs = new Label();
            lblInsumoRelatEstoqs = new Label();
            btnGerarRelatEstoqs = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvProdutoRelatEstoqs).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvInsumoRelatEstoqs).BeginInit();
            SuspendLayout();
            // 
            // lblRelatEstoqs
            // 
            lblRelatEstoqs.AutoSize = true;
            lblRelatEstoqs.Dock = DockStyle.Top;
            lblRelatEstoqs.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblRelatEstoqs.ForeColor = Color.FromArgb(57, 62, 40);
            lblRelatEstoqs.Location = new Point(0, 0);
            lblRelatEstoqs.Name = "lblRelatEstoqs";
            lblRelatEstoqs.Size = new Size(393, 51);
            lblRelatEstoqs.TabIndex = 2;
            lblRelatEstoqs.Text = "Relatório de Estoque";
            lblRelatEstoqs.TextAlign = ContentAlignment.MiddleCenter;
            lblRelatEstoqs.Click += lblOpcoesFuturosPlantios_Click;
            // 
            // dgvProdutoRelatEstoqs
            // 
            dgvProdutoRelatEstoqs.AllowUserToAddRows = false;
            dgvProdutoRelatEstoqs.AllowUserToDeleteRows = false;
            dgvProdutoRelatEstoqs.AllowUserToOrderColumns = true;
            dgvProdutoRelatEstoqs.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProdutoRelatEstoqs.Location = new Point(93, 137);
            dgvProdutoRelatEstoqs.Margin = new Padding(3, 2, 3, 2);
            dgvProdutoRelatEstoqs.Name = "dgvProdutoRelatEstoqs";
            dgvProdutoRelatEstoqs.ReadOnly = true;
            dgvProdutoRelatEstoqs.RowHeadersWidth = 51;
            dgvProdutoRelatEstoqs.RowTemplate.ReadOnly = true;
            dgvProdutoRelatEstoqs.Size = new Size(427, 69);
            dgvProdutoRelatEstoqs.TabIndex = 3;
            dgvProdutoRelatEstoqs.CellContentClick += dataGridView1_CellContentClick;
            // 
            // dgvInsumoRelatEstoqs
            // 
            dgvInsumoRelatEstoqs.AllowUserToAddRows = false;
            dgvInsumoRelatEstoqs.AllowUserToDeleteRows = false;
            dgvInsumoRelatEstoqs.AllowUserToOrderColumns = true;
            dgvInsumoRelatEstoqs.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvInsumoRelatEstoqs.Location = new Point(93, 240);
            dgvInsumoRelatEstoqs.Margin = new Padding(3, 2, 3, 2);
            dgvInsumoRelatEstoqs.Name = "dgvInsumoRelatEstoqs";
            dgvInsumoRelatEstoqs.ReadOnly = true;
            dgvInsumoRelatEstoqs.RowHeadersWidth = 51;
            dgvInsumoRelatEstoqs.Size = new Size(427, 69);
            dgvInsumoRelatEstoqs.TabIndex = 4;
            // 
            // lblProdutoRelatEstoqs
            // 
            lblProdutoRelatEstoqs.AutoSize = true;
            lblProdutoRelatEstoqs.BackColor = Color.Transparent;
            lblProdutoRelatEstoqs.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblProdutoRelatEstoqs.ForeColor = SystemColors.WindowText;
            lblProdutoRelatEstoqs.Location = new Point(93, 105);
            lblProdutoRelatEstoqs.Name = "lblProdutoRelatEstoqs";
            lblProdutoRelatEstoqs.Size = new Size(91, 30);
            lblProdutoRelatEstoqs.TabIndex = 61;
            lblProdutoRelatEstoqs.Text = "Produto";
            // 
            // lblInsumoRelatEstoqs
            // 
            lblInsumoRelatEstoqs.AutoSize = true;
            lblInsumoRelatEstoqs.BackColor = Color.Transparent;
            lblInsumoRelatEstoqs.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblInsumoRelatEstoqs.ForeColor = SystemColors.WindowText;
            lblInsumoRelatEstoqs.Location = new Point(93, 208);
            lblInsumoRelatEstoqs.Name = "lblInsumoRelatEstoqs";
            lblInsumoRelatEstoqs.Size = new Size(84, 30);
            lblInsumoRelatEstoqs.TabIndex = 62;
            lblInsumoRelatEstoqs.Text = "Insumo";
            // 
            // btnGerarRelatEstoqs
            // 
            btnGerarRelatEstoqs.BackColor = Color.YellowGreen;
            btnGerarRelatEstoqs.FlatAppearance.BorderSize = 0;
            btnGerarRelatEstoqs.FlatStyle = FlatStyle.Flat;
            btnGerarRelatEstoqs.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnGerarRelatEstoqs.ForeColor = Color.FromArgb(57, 62, 40);
            btnGerarRelatEstoqs.Location = new Point(373, 348);
            btnGerarRelatEstoqs.Name = "btnGerarRelatEstoqs";
            btnGerarRelatEstoqs.Size = new Size(115, 34);
            btnGerarRelatEstoqs.TabIndex = 63;
            btnGerarRelatEstoqs.Text = "Gerar";
            btnGerarRelatEstoqs.UseVisualStyleBackColor = false;
            btnGerarRelatEstoqs.Click += btnGerarRelatEstoqs_Click;
            // 
            // frmRelatEstoqs
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(238, 241, 212);
            ClientSize = new Size(584, 406);
            Controls.Add(btnGerarRelatEstoqs);
            Controls.Add(lblInsumoRelatEstoqs);
            Controls.Add(lblProdutoRelatEstoqs);
            Controls.Add(dgvInsumoRelatEstoqs);
            Controls.Add(dgvProdutoRelatEstoqs);
            Controls.Add(lblRelatEstoqs);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmRelatEstoqs";
            Text = "frmRelatEstoqs";
            ((System.ComponentModel.ISupportInitialize)dgvProdutoRelatEstoqs).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvInsumoRelatEstoqs).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblRelatEstoqs;
        private DataGridView dgvProdutoRelatEstoqs;
        private DataGridView dgvInsumoRelatEstoqs;
        private Label lblProdutoRelatEstoqs;
        private Label lblInsumoRelatEstoqs;
        private Button btnGerarRelatEstoqs;
    }
}