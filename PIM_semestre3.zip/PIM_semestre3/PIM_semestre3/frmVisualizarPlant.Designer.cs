﻿namespace PIMTESTE_
{
    partial class frmVisualizarPlant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblVisuaPlant = new Label();
            flowLayoutPanel1 = new FlowLayoutPanel();
            txtbTipoCultVisuaPlant = new TextBox();
            txtbSacoSemenVisuaPlant = new TextBox();
            txtbSacoAduboVisuaPlant = new TextBox();
            txtbTipoPlantVisuaPlant = new TextBox();
            flowLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // lblVisuaPlant
            // 
            lblVisuaPlant.AutoSize = true;
            lblVisuaPlant.Dock = DockStyle.Top;
            lblVisuaPlant.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblVisuaPlant.ForeColor = Color.FromArgb(75, 82, 51);
            lblVisuaPlant.Location = new Point(0, 0);
            lblVisuaPlant.Name = "lblVisuaPlant";
            lblVisuaPlant.Size = new Size(376, 51);
            lblVisuaPlant.TabIndex = 1;
            lblVisuaPlant.Text = "Visualizar Plantação";
            lblVisuaPlant.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Controls.Add(txtbTipoCultVisuaPlant);
            flowLayoutPanel1.Controls.Add(txtbSacoSemenVisuaPlant);
            flowLayoutPanel1.Controls.Add(txtbSacoAduboVisuaPlant);
            flowLayoutPanel1.Controls.Add(txtbTipoPlantVisuaPlant);
            flowLayoutPanel1.Location = new Point(62, 137);
            flowLayoutPanel1.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(453, 172);
            flowLayoutPanel1.TabIndex = 57;
            // 
            // txtbTipoCultVisuaPlant
            // 
            txtbTipoCultVisuaPlant.BackColor = SystemColors.Window;
            txtbTipoCultVisuaPlant.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbTipoCultVisuaPlant.ForeColor = SystemColors.WindowText;
            txtbTipoCultVisuaPlant.Location = new Point(3, 3);
            txtbTipoCultVisuaPlant.Name = "txtbTipoCultVisuaPlant";
            txtbTipoCultVisuaPlant.PlaceholderText = " Tipo de cultivo*";
            txtbTipoCultVisuaPlant.ReadOnly = true;
            txtbTipoCultVisuaPlant.Size = new Size(447, 36);
            txtbTipoCultVisuaPlant.TabIndex = 10;
            // 
            // txtbSacoSemenVisuaPlant
            // 
            txtbSacoSemenVisuaPlant.BackColor = SystemColors.Window;
            txtbSacoSemenVisuaPlant.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbSacoSemenVisuaPlant.ForeColor = SystemColors.WindowText;
            txtbSacoSemenVisuaPlant.Location = new Point(3, 45);
            txtbSacoSemenVisuaPlant.Name = "txtbSacoSemenVisuaPlant";
            txtbSacoSemenVisuaPlant.PlaceholderText = " Saco de sementes*";
            txtbSacoSemenVisuaPlant.ReadOnly = true;
            txtbSacoSemenVisuaPlant.Size = new Size(447, 36);
            txtbSacoSemenVisuaPlant.TabIndex = 11;
            // 
            // txtbSacoAduboVisuaPlant
            // 
            txtbSacoAduboVisuaPlant.BackColor = SystemColors.Window;
            txtbSacoAduboVisuaPlant.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbSacoAduboVisuaPlant.ForeColor = SystemColors.WindowText;
            txtbSacoAduboVisuaPlant.Location = new Point(3, 87);
            txtbSacoAduboVisuaPlant.Name = "txtbSacoAduboVisuaPlant";
            txtbSacoAduboVisuaPlant.PlaceholderText = " Saco de adubo*";
            txtbSacoAduboVisuaPlant.ReadOnly = true;
            txtbSacoAduboVisuaPlant.Size = new Size(447, 36);
            txtbSacoAduboVisuaPlant.TabIndex = 12;
            // 
            // txtbTipoPlantVisuaPlant
            // 
            txtbTipoPlantVisuaPlant.BackColor = SystemColors.Window;
            txtbTipoPlantVisuaPlant.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtbTipoPlantVisuaPlant.ForeColor = SystemColors.WindowText;
            txtbTipoPlantVisuaPlant.Location = new Point(3, 129);
            txtbTipoPlantVisuaPlant.Name = "txtbTipoPlantVisuaPlant";
            txtbTipoPlantVisuaPlant.PlaceholderText = " Tipo de plantio*";
            txtbTipoPlantVisuaPlant.ReadOnly = true;
            txtbTipoPlantVisuaPlant.Size = new Size(447, 36);
            txtbTipoPlantVisuaPlant.TabIndex = 13;
            // 
            // frmVisualizarPlant
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(238, 241, 212);
            ClientSize = new Size(584, 406);
            Controls.Add(flowLayoutPanel1);
            Controls.Add(lblVisuaPlant);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmVisualizarPlant";
            Text = "frmVisualizarPlant";
            Load += frmVisualizarPlant_Load;
            flowLayoutPanel1.ResumeLayout(false);
            flowLayoutPanel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblVisuaPlant;
        private FlowLayoutPanel flowLayoutPanel1;
        private TextBox txtbTipoCultVisuaPlant;
        private TextBox txtbSacoSemenVisuaPlant;
        private TextBox txtbSacoAduboVisuaPlant;
        private TextBox txtbTipoPlantVisuaPlant;
    }
}