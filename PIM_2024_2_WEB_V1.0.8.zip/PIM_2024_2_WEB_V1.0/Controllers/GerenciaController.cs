﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using PIM_2024_2_WEB_V1._0.Data;
using PIM_2024_2_WEB_V1._0.Models.Entities;
using Newtonsoft.Json;
using PIM_2024_2_WEB_V1._0.Models;
using System.Threading.Tasks.Dataflow;
using Microsoft.AspNetCore.Mvc.Rendering;
namespace PIM_2024_2_WEB_V1._0.Controllers
{
    public class GerenciaController : Controller
    {
        private readonly AppDbContext dbContext;

        public GerenciaController(AppDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<IActionResult> PlantationRelatory()
        {
            if (TempData["UserModel"] != null)
            {
                Console.WriteLine("user has data");
                var userModel = JsonConvert.DeserializeObject<AllModel>(TempData["UserModel"].ToString());
                userModel.plantacaoModelList = await dbContext.Plantacao.ToListAsync();
                userModel.vendaModelList = await dbContext.Venda.ToListAsync();
                return View(userModel);
            }

            return View(new AllModel());
        }

        public async Task<IActionResult> StockRelatory()
        {
            if (TempData["UserModel"] != null)
            {
                Console.WriteLine("user has data");
                var userModel = JsonConvert.DeserializeObject<AllModel>(TempData["UserModel"].ToString());
                userModel.insumoModelList = await dbContext.Insumo.ToListAsync();
                return View(userModel);
            }

            return View(new AllModel());
        }

        [HttpGet]
        public async Task<IActionResult> RegisterFuncionario()
        {
            if (TempData["UserModel"] != null)
            {
                Console.WriteLine("user has data");
                var userModel = JsonConvert.DeserializeObject<AllModel>(TempData["UserModel"].ToString());
                return View(userModel);
            }

            return View(new AllModel());
        }
        [HttpPost]
        public async Task<IActionResult> RegisterFuncionario(AllModel model)
        {
            if (TempData["UserModel"] != null)
            {
                var userModel = JsonConvert.DeserializeObject<AllModel>(TempData["UserModel"].ToString());

                try
                {
                    Console.WriteLine("user has data");
                    userModel.funcionarioModel = model.funcionarioModel;
                    var gerente = await dbContext.Gerencia.SingleOrDefaultAsync(g => g.E_mail == userModel.baseUserModel.E_mail && g.Senha == userModel.baseUserModel.Senha);
                    userModel.funcionarioModel.ID_gerencia_PK = gerente.ID_gerencia_PK;
                    dbContext.Funcionario.Add(model.funcionarioModel);
                    await dbContext.SaveChangesAsync();
                    TempData["UserModel"] = JsonConvert.SerializeObject(userModel);

                    return View(userModel);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    ModelState.AddModelError("funcionarioModel.E_mail", "Email invalido ou repetido");

                    ModelState.AddModelError("funcionarioModel.Usuario", "Usuario invalido ou repetido");

                    ModelState.AddModelError("funcionarioModel.CPF", "CPF invalido ou repetido");

                    ModelState.AddModelError("funcionarioModel.Nome", "nome invalido ou repetido");

                    return View(userModel);
                }
            }

            return View(new AllModel());
        }

    }
}
