﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace PIM_2024_2_WEB_V1._0.Models.Entities
{
    public class Insumo
    {

        [Key]
        public int ID_insumo_PK { get; set; }

        [Required]
        [StringLength(255)]
        public string Tipo_armazenagem { get; set; }

        [Required]
        [StringLength(255)]
        public string Nome_insumo { get; set; }

        [Required]
        public DateTime Data_pedido { get; set; }

        [Required]
        public int Prazo_entrega { get; set; }

        [Required]
        public int Unidade_medida { get; set; }

        [Required]
        [ForeignKey("Fornecedor")]
        public int ID_fornecedor_PK { get; set; } 

        
        public Fornecedor Fornecedor { get; set; }
    }
}
