﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace PIM_2024_2_WEB_V1._0.Models.Entities
{
    public class Venda
    {
        [Key]
        public int ID_venda_PK { get; set; } 

        [Required]
        public int Quantidade_produto { get; set; } = 0;

        [Required]
        [ForeignKey("Produto")]
        public int ID_produto_FK { get; set; }

        [Required]
        [ForeignKey("Cliente")]
        public int ID_cliente_PK { get; set; }

        [Required]
        public DateTime Data_compra { get; set; }

        [Required]
        [Column(TypeName = "decimal(20,2)")]
        public decimal Valor_compra { get; set; }

        
        public Produto Produto { get; set; }
        public Cliente Cliente { get; set; }

    }
}
