﻿using System.ComponentModel.DataAnnotations;

namespace PIM_2024_2_WEB_V1._0.Models.Entities
{
    public class Cliente: BaseUserModel
    {
        [Key]
        public int ID_cliente_PK { get; set; }

        [Required(ErrorMessage = "O campo CNPJ é obrigatório.")]
        [StringLength(18, ErrorMessage = "O CNPJ deve ter 18 caracteres.")]
        public string CNPJ { get; set; }

        [Required(ErrorMessage = "O campo Razão Social é obrigatório.")]
        [StringLength(255, ErrorMessage = "A Razão Social deve ter no máximo 255 caracteres.")]
        public string Razao_social { get; set; }

        [Required(ErrorMessage = "O campo Nome é obrigatório.")]
        [StringLength(255, ErrorMessage = "O Nome deve ter no máximo 255 caracteres.")]
        public string Nome { get; set; }

       
        [Required(ErrorMessage = "O campo Bairro é obrigatório.")]
        [StringLength(255, ErrorMessage = "O Bairro deve ter no máximo 255 caracteres.")]
        public string Bairro { get; set; }

        [Required(ErrorMessage = "O campo Município é obrigatório.")]
        [StringLength(255, ErrorMessage = "O Município deve ter no máximo 255 caracteres.")]
        public string Municipio { get; set; }

        [Required(ErrorMessage = "O campo UF é obrigatório.")]
        [StringLength(2, ErrorMessage = "A UF deve ter 2 caracteres.")]
        public string UF { get; set; }

        [Required(ErrorMessage = "O campo Rua é obrigatório.")]
        [StringLength(255, ErrorMessage = "A Rua deve ter no máximo 255 caracteres.")]
        public string Rua { get; set; }

        public int Numero { get; set; }

        [Required(ErrorMessage = "O campo CEP é obrigatório.")]
        [StringLength(9, ErrorMessage = "O CEP deve ter 9 caracteres.")]
        public string CEP { get; set; }


        [Required(ErrorMessage = "O campo Telefone é obrigatório.")]
        [StringLength(20, ErrorMessage = "O Telefone deve ter no máximo 20 caracteres.")]
        public string Telefone_1 { get; set; }

        [StringLength(20, ErrorMessage = "O Telefone 2 deve ter no máximo 20 caracteres.")]
        public string Telefone_2 { get; set; }

        [Required(ErrorMessage = "O campo Usuário é obrigatório.")]
        [StringLength(255, ErrorMessage = "O Usuário deve ter no máximo 255 caracteres.")]
        public string Usuario { get; set; }

        

        public Cliente()
        {
            CNPJ = "123456789";
            Nome = "DefaultName";
            
            Bairro = "DefaultBairro";
            CEP = "123456789";
            Municipio = "DEfaultMunicipio";
            UF = "UF";
            Rua = "DefaultRua";
            Numero = 123;
            Usuario = "DefaultUser";
            Telefone_1 = "123456789";
            Telefone_2 = "123456789";
        }



    }
}
