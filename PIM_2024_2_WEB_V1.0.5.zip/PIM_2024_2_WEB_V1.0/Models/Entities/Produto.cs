﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class Produto
{
    [Key]
    public int ID_produto_PK { get; set; }

    [Required(ErrorMessage = "O campo Tipo de Armazenagem é obrigatório.")]
    [MaxLength(255)]
    public string Tipo_armazenagem { get; set; }

    [Required(ErrorMessage = "O campo Preço do Produto é obrigatório.")]
    [Column(TypeName = "decimal(20, 2)")]
    public decimal Preco_produto { get; set; }

    [Required(ErrorMessage = "O campo Nome do Produto é obrigatório.")]
    [MaxLength(255)]
    public string Nome_produto { get; set; }

    [Required(ErrorMessage = "O campo Unidade de Medida é obrigatório.")]
    public int Unidade_medida { get; set; }

    [Required(ErrorMessage = "O campo Fazenda é obrigatório.")]
    public int ID_fazenda_PK { get; set; }

   
    [ForeignKey("ID_fazenda_PK")]
    public Fazenda Fazenda { get; set; }
}
