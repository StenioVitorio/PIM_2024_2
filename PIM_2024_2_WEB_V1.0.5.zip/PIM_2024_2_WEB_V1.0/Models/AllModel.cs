﻿using Microsoft.AspNetCore.Mvc.Rendering;
using PIM_2024_2_WEB_V1._0.Models.Entities;

namespace PIM_2024_2_WEB_V1._0.Models
{
    public class AllModel
    {
        public BaseUserModel baseUserModel { get; set; }
        public Plantacao plantacaoModel { get; set; }

        public Produto produtoModel { get; set; }

        public Fazenda fazendaModel { get; set; }

        public List<SelectListItem> fazendaModelListItems { get; set; }

        public List<Plantacao> plantacaoModelList { get; set; }

        public List<Produto> produtoModelList { get; set; }
        public List<SelectListItem> produtoModelListItems { get; set; }
        
        public AllModel()
        {
            fazendaModelListItems = new List<SelectListItem>();
            produtoModelListItems = new List<SelectListItem>();
        }
    }
}
