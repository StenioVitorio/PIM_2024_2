﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace PIM_2024_2_WEB_V1._0.Models.Entities
{
    public class Fornecedor
    {
        [Key]
        public int ID_fornecedor_PK { get; set; } 

        [Required]
        [StringLength(18)]
        public string CNPJ { get; set; } 

        [Required]
        [StringLength(255)]
        public string Nome { get; set; }

        [Required]
        [StringLength(255)]
        public string Razao_social { get; set; }

        [Required]
        [StringLength(255)]
        public string Municipio { get; set; }

        [Required]
        [StringLength(255)]
        public string Bairro { get; set; }

        [Required]
        [StringLength(9)]
        public string CEP { get; set; }

        [Required]
        [StringLength(255)]
        public string Rua { get; set; }

        [Required]
        [StringLength(2)]
        public string UF { get; set; }

        [Required]
        public int Numero { get; set; }

        [Required]
        [StringLength(20)]
        public string Telefone_1 { get; set; }

        [StringLength(20)]
        public string Telefone_2 { get; set; }

        [Required]
        [StringLength(255)]
        public string E_mail { get; set; }

        
        public  ICollection<Insumo> Insumos { get; set; } = new List<Insumo>();

    }
}
