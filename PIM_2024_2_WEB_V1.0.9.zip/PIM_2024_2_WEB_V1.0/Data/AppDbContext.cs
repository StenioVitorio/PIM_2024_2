﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using PIM_2024_2_WEB_V1._0.Models.Entities;

namespace PIM_2024_2_WEB_V1._0.Data
{
    public class AppDbContext: DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options): base(options)
        {
        }
        public DbSet<Cliente> Cliente { get; set; }
        public DbSet<Funcionario> Funcionario { get; set; }
        public DbSet<Gerencia> Gerencia { get; set; }
        public DbSet<Fazenda> Fazenda { get; set; }
        public DbSet<Plantacao> Plantacao { get; set; }
        public DbSet<Produto> Produto { get; set; }

        public DbSet<Venda> Venda { get; set; }
        public DbSet<Insumo> Insumo { get; set; }
        public DbSet<Fornecedor> Fornecedor { get; set; }
    }
}
