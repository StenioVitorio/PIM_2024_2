﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using PIM_2024_2_WEB_V1._0.Data;
using PIM_2024_2_WEB_V1._0.Models.Entities;
using Newtonsoft.Json;
using PIM_2024_2_WEB_V1._0.Models;
using System.Threading.Tasks.Dataflow;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace PIM_2024_2_WEB_V1._0.Controllers
{
    public class ClienteController : Controller
    {
        public readonly AppDbContext dbContext;

        public ClienteController(AppDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

       
        public async  Task<IActionResult> BuyProduct()
        {
            if (TempData["UserModel"] != null)
            {
                Console.WriteLine("user has data");
                var userModel = JsonConvert.DeserializeObject<AllModel>(TempData["UserModel"].ToString());
                
                var produtos = await dbContext.Produto.ToListAsync();
                if (userModel.produtoModelListItems.IsNullOrEmpty())
                {
                    foreach (var produto in produtos)
                    {
                        userModel.produtoModelListItems.Add(new SelectListItem { Value = produto.ID_produto_PK.ToString(), Text = "ID: " + produto.ID_produto_PK.ToString() + " Nome: " + produto.Nome_produto.ToString() }
                       );
                    }
                }
                TempData["UserModel"] = JsonConvert.SerializeObject(userModel);
                return View(userModel);
            }
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> BuyProduct(AllModel model)
        {
           
            var userModel = JsonConvert.DeserializeObject<AllModel>(TempData["UserModel"].ToString());
            var produto = await dbContext.Produto.FindAsync(model.vendaModel.ID_produto_FK);
            userModel.vendaModel = model.vendaModel;
            userModel.vendaModel.ID_cliente_PK = userModel.clienteModel.ID_cliente_PK;
            userModel.vendaModel.Valor_compra = (produto.Preco_produto) * ((decimal)model.vendaModel.Quantidade_produto);
            

            return View(userModel);
        
        }

        }
}
