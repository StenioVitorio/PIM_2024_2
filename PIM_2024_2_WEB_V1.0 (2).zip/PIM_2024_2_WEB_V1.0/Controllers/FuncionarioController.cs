﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using PIM_2024_2_WEB_V1._0.Data;
using PIM_2024_2_WEB_V1._0.Models.Entities;
using Newtonsoft.Json;
using PIM_2024_2_WEB_V1._0.Models;
using System.Threading.Tasks.Dataflow;

namespace PIM_2024_2_WEB_V1._0.Controllers
{
    public class FuncionarioController : Controller
    {
        private readonly AppDbContext dbContext;


        public FuncionarioController(AppDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public IActionResult CreatePlantation()
        {
            if (TempData["UserModel"] != null)
            {
                Console.WriteLine("user has data");
                var userModel = JsonConvert.DeserializeObject<AllModel>(TempData["UserModel"].ToString());
                return View(userModel);
            }
            Console.WriteLine("user has data");
            return View(new AllModel());
        }

        [HttpPost]
        public async Task<IActionResult> CreatePlantation(AllModel model)
        {
             dbContext.Add(model.plantacaoModel);
            await dbContext.SaveChangesAsync();
            var userModel = JsonConvert.DeserializeObject<AllModel>(TempData["UserModel"].ToString());
            return View(userModel);
        }



            public IActionResult AlterPlantation()
        {
            
            
            return View();
        }

        

        public IActionResult GenerateRelatory()
        {
            return View();
        }

        

        public IActionResult ViewPlantation()
        {
            return View();
        }

        


    }
}
