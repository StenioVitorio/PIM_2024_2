﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using PIM_2024_2_WEB_V1._0.Data;
using PIM_2024_2_WEB_V1._0.Models.Entities;
using Newtonsoft.Json;
using PIM_2024_2_WEB_V1._0.Models;
using System.Threading.Tasks.Dataflow;

namespace PIM_2024_2_WEB_V1._0.Controllers

{
    public class LoggonController : Controller
    {
        private readonly AppDbContext dbContext;


        public LoggonController(AppDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        // GET: LoggonController
        public ActionResult Index()
        {
            return View();
        }


        // Display the login form
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        //gerencia o form
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(AllModel model)
        {
            



            
            Console.WriteLine("chegou");
           
                if(string.IsNullOrEmpty(model.baseUserModel.E_mail)|| string.IsNullOrEmpty(model.baseUserModel.Senha))
            {
                Console.WriteLine("Usuario invalido");
                return View();
            }
           
                Console.WriteLine("user valido");
                var userCliente = await dbContext.Cliente.SingleOrDefaultAsync(u => u.E_mail == model.baseUserModel.E_mail && u.Senha == model.baseUserModel.Senha);

                if (userCliente != null)
                {
                Console.WriteLine("Cliente");
                    //redireciona pra are do cliente
                }
                var userFuncionario = await dbContext.Funcionario.SingleOrDefaultAsync(f => f.E_mail == model.baseUserModel.E_mail && f.Senha == model.baseUserModel.Senha);

                if (userFuncionario != null)
                {
                if (userFuncionario.Tipo_Conta == "Funcionario") { model.baseUserModel.Tipo_Conta = "Funcionario"; Console.WriteLine("titulo de funcionario"); }

                TempData["UserModel"] = JsonConvert.SerializeObject(model);
                Console.WriteLine("Funcionario");
                //redireciona pra are do funcionario
                return RedirectToAction("CreatePlantation", "Funcionario");

                }
                var userGerencia = await dbContext.Gerencia.SingleOrDefaultAsync(g => g.E_mail == model.baseUserModel.E_mail && g.Senha == model.baseUserModel.Senha);

            if (userGerencia != null)
            {
                if (userGerencia.Tipo_Conta == "Gerente") { model.baseUserModel.Tipo_Conta = "Gerente"; Console.WriteLine("titulo de gerente"); }
                if (userGerencia.Tipo_Conta == "ADM") { model.baseUserModel.Tipo_Conta = "ADM"; Console.WriteLine("titulo de adm"); } 
                TempData["UserModel"] = JsonConvert.SerializeObject(model);
                Console.WriteLine("Gerente");
                //redireciona pra are do gerente
                return RedirectToAction("CreatePlantation", "Funcionario") ;
                }
                //faz a verificação no bd

                
                    //se deu errado mostra esse erro
                 ModelState.AddModelError("E_mail", "usuario invalido");
            ModelState.AddModelError("Senha", "usuario invalido");

            Console.WriteLine("deu tudo errado");

            //se deu tudo errado faz isso
            return View();
        }
    }

   
}
