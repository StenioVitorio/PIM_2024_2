﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class Fazenda
{
    [Key]
    public int ID_fazenda_PK { get; set; }

    [Required(ErrorMessage = "O campo Nome é obrigatório.")]
    [MaxLength(255)]
    public string Nome { get; set; }

    [Required(ErrorMessage = "O campo CNPJ é obrigatório.")]
    [StringLength(18, MinimumLength = 18, ErrorMessage = "O campo CNPJ deve ter exatamente 18 caracteres.")]
    public string CNPJ { get; set; }

    [Required(ErrorMessage = "O campo Razão Social é obrigatório.")]
    [MaxLength(255)]
    public string Razao_Social { get; set; }

    [Required(ErrorMessage = "O campo CEP é obrigatório.")]
    [StringLength(9, MinimumLength = 9, ErrorMessage = "O campo CEP deve ter exatamente 9 caracteres.")]
    public string CEP { get; set; }

    [StringLength(2, ErrorMessage = "O campo UF deve ter no máximo 2 caracteres.")]
    public string UF { get; set; }

    [Required(ErrorMessage = "O campo Rua é obrigatório.")]
    [MaxLength(255)]
    public string Rua { get; set; }

    [Required(ErrorMessage = "O campo Município é obrigatório.")]
    [MaxLength(255)]
    public string Municipio { get; set; }

    [Required(ErrorMessage = "O campo Bairro é obrigatório.")]
    [MaxLength(255)]
    public string Bairro { get; set; }

    [Required(ErrorMessage = "O campo Número é obrigatório.")]
    public int Numero { get; set; }

    [Required(ErrorMessage = "O campo Telefone 1 é obrigatório.")]
    [MaxLength(20)]
    public string Telefone_1 { get; set; }

    [MaxLength(20)]
    public string Telefone_2 { get; set; }

    [Required(ErrorMessage = "O campo E-mail é obrigatório.")]
    [EmailAddress(ErrorMessage = "O campo E-mail não está em um formato válido.")]
    [MaxLength(255)]
    public string E_mail { get; set; }
}
