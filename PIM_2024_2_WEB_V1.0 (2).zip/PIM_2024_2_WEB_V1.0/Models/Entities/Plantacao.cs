﻿using Microsoft.EntityFrameworkCore.Infrastructure.Internal;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PIM_2024_2_WEB_V1._0.Models.Entities
{
    public class Plantacao
    {
        [Key]
        public int ID_plantacao_PK { get; set; }

        [Required(ErrorMessage = "Data Necessario")]
        [RegularExpression(@"[0-9]{1,2}-[0-9]{1,2}-[0-9]{4}$", ErrorMessage = "Precisa ser no formato (dd-mm-yyyy)")]
        public String Data_plantio { get; set; }

        [Required(ErrorMessage = "Tipo necessario")]
        [StringLength(255, ErrorMessage = "Precisa ter no maximo 255 caracteres")]
        public String Tipo_plantio { get; set; }

        [Required(ErrorMessage = "Tipo necessario")]
        [StringLength(255, ErrorMessage = "Precisa ter no maximo 255 caracteres")]
        public String Tipo_cultivo { get; set; }

        [Required]
        [RegularExpression(@"^[0-9]{1,5}$")]
        public int Qtd_sacos_semente { get; set; }

        [Required]
        [RegularExpression(@"^[0-9]{1,5}$")]
        public int Qtd_sacos_adubo { get; set; }
        [Required]
        [ForeignKey("Produto")]

        public int ID_produto_FK { get; set; }

        public Produto Produto;


        public Plantacao()
        {
            this.Data_plantio = DateTime.Now.ToString("dd-MM-yyyy");
            this.ID_produto_FK = 1;
        }


    }
}
