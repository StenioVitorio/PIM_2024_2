﻿using PIM_2024_2_WEB_V1._0.Models.Entities;

namespace PIM_2024_2_WEB_V1._0.Models
{
    public class AllModel
    {
        public BaseUserModel baseUserModel { get; set; }
        public Plantacao plantacaoModel { get; set; }

        public Plantacao[] plantacaoMoodelList { get; set; }

    }
}
