﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using PIM_2024_2_WEB_V1._0.Data;
using PIM_2024_2_WEB_V1._0.Models.Entities;
using Newtonsoft.Json;
using PIM_2024_2_WEB_V1._0.Models;
using System.Threading.Tasks.Dataflow;
using Microsoft.AspNetCore.Mvc.Rendering;


namespace PIM_2024_2_WEB_V1._0.Controllers
{
    public class AdmController : Controller
    {

        private readonly AppDbContext dbContext;

        public AdmController(AppDbContext dbContext)
        {
            this.dbContext = dbContext;
        }


        [HttpGet]
        public IActionResult RegisterGerencia()
        {
            if (TempData["UserModel"] != null)
            {
                var userModel = JsonConvert.DeserializeObject<AllModel>(TempData["UserModel"].ToString());
                return View(userModel);
            }
                return View();
        }


        [HttpPost]
        public async Task<IActionResult> RegisterGerencia(AllModel model)
        {

            if (TempData["UserModel"] != null)
            {
                var userModel = JsonConvert.DeserializeObject<AllModel>(TempData["UserModel"].ToString());

                var userCliente = await dbContext.Cliente.AnyAsync(u => u.E_mail == model.gerenciaModel.E_mail);


                var userGerencia = await dbContext.Gerencia.AnyAsync(u => u.E_mail == model.gerenciaModel.E_mail);

                var userFuncionario = await dbContext.Funcionario.AnyAsync(u => u.E_mail == model.gerenciaModel.E_mail);



                if (userGerencia != false || userCliente != false || userFuncionario != false)
                {
                    ModelState.AddModelError("gerenciaModel.E_mail", "Usuario ja existe");

                    return View(userModel);
                }
                else
                {
                    try
                    {
                        Console.WriteLine("user has data");
                        userModel.gerenciaModel = model.gerenciaModel;
                        model.gerenciaModel.ID_gerencia_PK = (await dbContext.Gerencia
        .OrderByDescending(g => g.ID_gerencia_PK)
        .Select(g => g.ID_gerencia_PK)
        .FirstOrDefaultAsync())+1;
                        dbContext.Gerencia.Add(model.gerenciaModel);
                        await dbContext.SaveChangesAsync();
                        TempData["UserModel"] = JsonConvert.SerializeObject(userModel);

                        return View(userModel);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                        ModelState.AddModelError("gerenciaModel.E_mail", "Email invalido ou repetido");

                        ModelState.AddModelError("gerenciaModel.Usuario", "Usuario invalido ou repetido");

                        
                        return View(userModel);
                    }
                }

            }

            return View(new AllModel());



        }
    }
}
