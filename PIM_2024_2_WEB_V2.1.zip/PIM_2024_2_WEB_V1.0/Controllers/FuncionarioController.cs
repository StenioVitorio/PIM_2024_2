﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using PIM_2024_2_WEB_V1._0.Data;
using PIM_2024_2_WEB_V1._0.Models.Entities;
using Newtonsoft.Json;
using PIM_2024_2_WEB_V1._0.Models;
using System.Threading.Tasks.Dataflow;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace PIM_2024_2_WEB_V1._0.Controllers
{
    public class FuncionarioController : Controller
    {
        private readonly AppDbContext dbContext;


        public FuncionarioController(AppDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<IActionResult> CreatePlantation()
        {
            if (TempData["UserModel"] != null)
            {
                Console.WriteLine("user has data");
                var userModel = JsonConvert.DeserializeObject<AllModel>(TempData["UserModel"].ToString());
                var produtos = await dbContext.Produto.ToListAsync();
                if (userModel.produtoModelListItems.IsNullOrEmpty())
                {
                    foreach (var produto in produtos)
                    {
                        userModel.produtoModelListItems.Add(new SelectListItem { Value = produto.ID_produto_PK.ToString(), Text = "ID: " + produto.ID_produto_PK.ToString() + " Nome: " + produto.Nome_produto.ToString() }
                       );
                    }
                }
                TempData["UserModel"] = JsonConvert.SerializeObject(userModel);

                return View(userModel);
            }
            Console.WriteLine("user has data");
            return View(new AllModel());
        }

        [HttpPost]
        public async Task<IActionResult> CreatePlantation(AllModel model)
        {
            try
            {
                dbContext.Add(model.plantacaoModel);
                await dbContext.SaveChangesAsync();
            }
            catch
            {
                ModelState.AddModelError("plantacaoModel.Tipo_cultivo", "preencha os dados");
                ModelState.AddModelError("plantacaoModel.Qtd_sacos_semente", "preencha os dados");
                ModelState.AddModelError("plantacaoModel.Qtd_sacos_adubo", "preencha os dados");
                ModelState.AddModelError("plantacaoModel.Tipo_plantio", "preencha os dados");
                ModelState.AddModelError("plantacaoModel.ID_produto_FK", "preencha os dados");
            }
             
            var userModel = JsonConvert.DeserializeObject<AllModel>(TempData["UserModel"].ToString());

            return View(userModel);
        }



            public async Task<IActionResult> AlterPlantation()
        {
            if (TempData["UserModel"] != null)
            {
                Console.WriteLine("user has data");
                var userModel = JsonConvert.DeserializeObject<AllModel>(TempData["UserModel"].ToString());
                userModel.plantacaoModelList = await dbContext.Plantacao.ToListAsync();
                return View(userModel);
            }

            return View(new AllModel());
        }

        

       

        [HttpGet]
        public async Task<IActionResult> EditPlantation([FromQuery]int? ID_plantacao_PK )
        {
            if (TempData["UserModel"] != null)
            {
                Console.WriteLine("user has data");
                var userModel = JsonConvert.DeserializeObject<AllModel>(TempData["UserModel"].ToString());
                var produtos = await dbContext.Produto.ToListAsync();
                if (userModel.produtoModelListItems.IsNullOrEmpty()) {
                    foreach (var produto in produtos)
                    {
                        userModel.produtoModelListItems.Add(new SelectListItem { Value = produto.ID_produto_PK.ToString(), Text = "ID: " + produto.ID_produto_PK.ToString() + " Nome: " + produto.Nome_produto.ToString() }
                       );
                    }
                }
                
                var plantacao = await dbContext.Plantacao.FindAsync(ID_plantacao_PK);
                userModel.plantacaoModel = plantacao;
                TempData["UserModel"] = JsonConvert.SerializeObject(userModel);

                return View(userModel);
            }
                
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> EditPlantation(AllModel model)
        {
            var userModel = JsonConvert.DeserializeObject<AllModel>(TempData["UserModel"].ToString());

            dbContext.Plantacao.Update(model.plantacaoModel);
            await dbContext.SaveChangesAsync();
            return RedirectToAction("AlterPlantation", "Funcionario");

        }
        [HttpPost]
        public async Task<IActionResult> DeletePlantation( int? ID_plantacao_PK)
        {
            var plantacao = await dbContext.Plantacao.FindAsync(ID_plantacao_PK);
            if (plantacao != null) { dbContext.Plantacao.Remove(plantacao); };
            await dbContext.SaveChangesAsync();


            return RedirectToAction("AlterPlantation", "Funcionario");
        }

        [HttpGet]
        public async Task<IActionResult> GenerateRelatory()
        {
            var userModel = JsonConvert.DeserializeObject<AllModel>(TempData["UserModel"].ToString());
            var fazendas = await dbContext.Fazenda.ToListAsync();
            if (userModel.fazendaModelListItems.IsNullOrEmpty())
            {
                foreach(var fazenda in fazendas)
                {
                    userModel.fazendaModelListItems.Add(new SelectListItem { Value = fazenda.ID_fazenda_PK.ToString(), Text = "ID: " + fazenda.ID_fazenda_PK.ToString() + " Nome: " + fazenda.Nome.ToString() });
                }
            }

            return View(userModel);
        }
        [HttpPost]
        public async Task<IActionResult> GenerateRelatory(AllModel model)
        {

            dbContext.Add(model.produtoModel);
            await dbContext.SaveChangesAsync();
            var userModel = JsonConvert.DeserializeObject<AllModel>(TempData["UserModel"].ToString());
            userModel.produtoModelListItems.Add(new SelectListItem { Value = model.produtoModel.ID_produto_PK.ToString(), Text = "ID: " + model.produtoModel.ID_produto_PK.ToString() + " Nome: " + model.produtoModel.Nome_produto.ToString() });
            userModel.produtoModel = model.produtoModel;
            TempData["UserModel"] = JsonConvert.SerializeObject(userModel);

            return View(userModel);
        }

        }
}
