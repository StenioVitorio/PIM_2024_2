﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace PIM_2024_2_WEB_V1._0.Models.Entities
{
    public class BaseUserModel
    {
        

        
        [Required(ErrorMessage = "Email necessario")]
        [EmailAddress(ErrorMessage = "Email invalido")]
        public string E_mail { get; set; }
       
        [Required(ErrorMessage = "senha necessaria")]
        [StringLength(25, ErrorMessage = "Senha precisa ter no minimo 8 caracteres", MinimumLength = 8)]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,20}$",
            ErrorMessage = "Senha precisa ter uma letra maiuscula, uma minuscula, um numero e um simbolo")]
        public string Senha { get; set; }

        [Required(ErrorMessage ="Tipo_conta neecessario")]
        [StringLength(20, ErrorMessage ="precisa ter no maximo 20 caracteres")]

        [RegularExpression(@"^[a-zA-z0-9]{2,20}$", ErrorMessage="Precisa ter entre 2 e 20 caracteres, ser numeros e letras")]

        public string Tipo_Conta { get; set; }
    }
}
