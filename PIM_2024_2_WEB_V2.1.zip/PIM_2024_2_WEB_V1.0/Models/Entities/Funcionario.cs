﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PIM_2024_2_WEB_V1._0.Models.Entities
{
    public class Funcionario: BaseUserModel
    {
        [Key]
        public int ID_funcionario_PK { get; set; }

        [Required(ErrorMessage = "O campo CPF é obrigatório.")]
        [StringLength(14, ErrorMessage = "O CPF deve ter 14 caracteres.")]
        [RegularExpression(@"^[0-9]{3}.[0-9]{3}.[0-9]{3}-[0-9]{2}$", ErrorMessage ="Formato 000.000.000-00")]
        public string CPF { get; set; }

        [Required(ErrorMessage = "O campo Nome é obrigatório.")]
        [StringLength(255, ErrorMessage = "O Nome deve ter no máximo 255 caracteres.")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "O campo Cargo é obrigatório.")]
        [StringLength(255, ErrorMessage = "O Cargo deve ter no máximo 255 caracteres.")]
        public string Cargo { get; set; }

        [Required(ErrorMessage = "O campo Bairro é obrigatório.")]
        [StringLength(255, ErrorMessage = "O Bairro deve ter no máximo 255 caracteres.")]
        public string Bairro { get; set; }

        [Required(ErrorMessage = "O campo Município é obrigatório.")]
        [StringLength(255, ErrorMessage = "O Município deve ter no máximo 255 caracteres.")]
        public string Municipio { get; set; }

        [Required(ErrorMessage = "O campo UF é obrigatório.")]
        [StringLength(2, ErrorMessage = "A UF deve ter 2 caracteres.")]
        public string UF { get; set; }

        [Required(ErrorMessage = "O campo Rua é obrigatório.")]
        [StringLength(255, ErrorMessage = "A Rua deve ter no máximo 255 caracteres.")]
        public string Rua { get; set; }

        [Required(ErrorMessage ="numero necessario")]
        public int Numero { get; set; }

        [Required(ErrorMessage = "O campo CEP é obrigatório.")]
        [StringLength(9, ErrorMessage = "O CEP deve ter 9 caracteres.")]
        public string CEP { get; set; }


        [Required(ErrorMessage = "O campo Telefone é obrigatório.")]
        [StringLength(20, ErrorMessage = "O Telefone deve ter no máximo 20 caracteres.")]
        public string Telefone { get; set; }

        [StringLength(20, ErrorMessage = "O Telefone Emergencial deve ter no máximo 20 caracteres.")]
        public string Tel_emergencial { get; set; }

        [Required(ErrorMessage = "O campo Usuário é obrigatório.")]
        [StringLength(255, ErrorMessage = "O Usuário deve ter no máximo 255 caracteres.")]
        public string Usuario { get; set; }

        [ForeignKey("Gerencia")]
        public int ID_gerencia_PK { get; set; }

        public Gerencia Gerencia { get; set; }

        public Funcionario()
        {
            Cargo = "Funcionario";
            Bairro = "DefaultBairro";
            CEP = "123456789";
            Municipio = "DEfaultMunicipio";
            UF = "UF";
            Rua = "DefaultRua";
            Numero = 123;
            
            Telefone = "123456789";
            Tel_emergencial = "123456789";
            Tipo_Conta = "Funcionario";
        }


    }
}
