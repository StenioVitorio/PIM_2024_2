﻿using System.ComponentModel.DataAnnotations;

namespace PIM_2024_2_WEB_V1._0.Models.Entities
{
    public class Gerencia: BaseUserModel
    {
        [Key]
        public int ID_gerencia_PK { get; set; }

        [Required(ErrorMessage = "O campo Usuário é obrigatório.")]
        [StringLength(255, ErrorMessage = "O Usuário deve ter no máximo 255 caracteres.")]
        public string Usuario { get; set; }

        public ICollection<Funcionario> Funcionarios { get; set; }
        

    }
}
