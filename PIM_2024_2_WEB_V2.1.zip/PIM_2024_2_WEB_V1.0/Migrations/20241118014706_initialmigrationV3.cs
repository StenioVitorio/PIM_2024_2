﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PIM_2024_2_WEB_V1._0.Migrations
{
    /// <inheritdoc />
    public partial class initialmigrationV3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<DateTime>(
                name: "Data_plantio",
                table: "Plantacao",
                type: "datetime2",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.CreateTable(
                name: "Fornecedor",
                columns: table => new
                {
                    ID_fornecedor_PK = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CNPJ = table.Column<string>(type: "nvarchar(18)", maxLength: 18, nullable: false),
                    Nome = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Razao_social = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Municipio = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Bairro = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    CEP = table.Column<string>(type: "nvarchar(9)", maxLength: 9, nullable: false),
                    Rua = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    UF = table.Column<string>(type: "nvarchar(2)", maxLength: 2, nullable: false),
                    Numero = table.Column<int>(type: "int", nullable: false),
                    Telefone_1 = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Telefone_2 = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    E_mail = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Fornecedor", x => x.ID_fornecedor_PK);
                });

            migrationBuilder.CreateTable(
                name: "Venda",
                columns: table => new
                {
                    ID_venda_PK = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Quantidade_produto = table.Column<int>(type: "int", nullable: false),
                    ID_produto_FK = table.Column<int>(type: "int", nullable: false),
                    ID_cliente_PK = table.Column<int>(type: "int", nullable: false),
                    Data_compra = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Valor_compra = table.Column<decimal>(type: "decimal(20,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Venda", x => x.ID_venda_PK);
                    table.ForeignKey(
                        name: "FK_Venda_Cliente_ID_cliente_PK",
                        column: x => x.ID_cliente_PK,
                        principalTable: "Cliente",
                        principalColumn: "ID_cliente_PK",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Venda_Produto_ID_produto_FK",
                        column: x => x.ID_produto_FK,
                        principalTable: "Produto",
                        principalColumn: "ID_produto_PK",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Insumo",
                columns: table => new
                {
                    ID_insumo_PK = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Tipo_armazenagem = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Nome_insumo = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Data_pedido = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Prazo_entrega = table.Column<int>(type: "int", nullable: false),
                    Unidade_medida = table.Column<int>(type: "int", nullable: false),
                    ID_fornecedor_PK = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Insumo", x => x.ID_insumo_PK);
                    table.ForeignKey(
                        name: "FK_Insumo_Fornecedor_ID_fornecedor_PK",
                        column: x => x.ID_fornecedor_PK,
                        principalTable: "Fornecedor",
                        principalColumn: "ID_fornecedor_PK",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Insumo_ID_fornecedor_PK",
                table: "Insumo",
                column: "ID_fornecedor_PK");

            migrationBuilder.CreateIndex(
                name: "IX_Venda_ID_cliente_PK",
                table: "Venda",
                column: "ID_cliente_PK");

            migrationBuilder.CreateIndex(
                name: "IX_Venda_ID_produto_FK",
                table: "Venda",
                column: "ID_produto_FK");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Insumo");

            migrationBuilder.DropTable(
                name: "Venda");

            migrationBuilder.DropTable(
                name: "Fornecedor");

            migrationBuilder.AlterColumn<string>(
                name: "Data_plantio",
                table: "Plantacao",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(DateTime),
                oldType: "datetime2");
        }
    }
}
