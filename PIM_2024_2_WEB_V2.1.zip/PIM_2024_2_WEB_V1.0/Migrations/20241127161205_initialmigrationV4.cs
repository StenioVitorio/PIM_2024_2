﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PIM_2024_2_WEB_V1._0.Migrations
{
    /// <inheritdoc />
    public partial class initialmigrationV4 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
